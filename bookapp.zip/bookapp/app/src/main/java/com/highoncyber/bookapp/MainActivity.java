package com.highoncyber.bookapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    DrawerLayout drawerlayout;
    NavigationView navigationview;
    ImageView menu;
    EditText chap_search;
    Cursor cursor;


    RecyclerView recyclerView;
    databasehelper mydb;
    private ArrayList<chapter_model> Chapter_array=new ArrayList<>();
    private CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chap_search=findViewById(R.id.search_box_sec);


        drawerlayout=findViewById(R.id.drawer_layout);
        navigationview=findViewById(R.id.nav_view);
        //toolbar=findViewById(R.id.toolbar);

        menu=findViewById(R.id.menu);
        recyclerView = findViewById(R.id.recyclerview);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerlayout.openDrawer(Gravity.LEFT);
            }
        });
        navigationview.bringToFront();
        ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this,drawerlayout,R.string.open_drawer,R.string.close_drawer);
        drawerlayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationview.setNavigationItemSelectedListener(this);

        mydb= new databasehelper(MainActivity.this);


        chap_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });
        DisplayStoreddataInArray();

        customAdapter = new CustomAdapter(MainActivity.this,Chapter_array);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

    }

    private void filter(String text) {
        ArrayList<chapter_model> filteredList = new ArrayList<>();
        for (chapter_model item : Chapter_array) {
            if (item.getBook_title().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        customAdapter.filterList(filteredList);
    }
    void DisplayStoreddataInArray(){

            cursor = mydb.read_all_chapters_data();
            if(cursor.getCount() == 0){
                databasehelper mydb2= new databasehelper(MainActivity.this);

                //chapter 1
                mydb2.addchapters("INTRODUCTION ","5","CHAPTER - I");
                //sections of ch 1
                mydb2.addsection("1 Title and extent of operation of the Code","INTRODUCTION",1,"This Act shall be called the Pakistan Penal Code, and shall take effect throughout Pakistan. ");
                mydb2.addsection("2 Punishment of offences committed within Pakistan","INTRODUCTION",1,": Every person shall be liable to punishment under this Code and not otherwise for every act or omission contrary to the provisions thereof, of which he shall be guilty within Pakistan. ");
                mydb2.addsection("3 Punishment of offences committed beyond, but which by law may be tried within Pakistan","INTRODUCTION",1,"Any person liable, by any Pakistani Law, to be tried for an offence committed beyond Pakistan shall be dealt with according to the provision of this Code for any act committed beyond Pakistan in the same manner as if such act had been committed within Pakistan. ");
                mydb2.addsection("4 Extension of Code for extra-territorial offences","INTRODUCTION",1,"The provisions of this Code apply also to any offence committed by\"\n" +
                        "[(1) any citizen of Pakistan or any person in the service of Pakistan in any place without\n" +
                        "and beyond Pakistan];\n" +
                        "Sub-sec. (1) subs. by the Federal Laws (Revision and Declaration) Ordinance, XXVII of 1981.\n" +
                        "(2)[As amended byA.0. 1949 Sch. has been omitted by AO.1961, Art. 2 and Sch. (w.e.f.\n" +
                        "23rd March, 1956)];\n" +
                        "(3) [Omitted by the Federal Laws (revision and Declaration) Ordinance, XXVII of 1981];\n" +
                        "(4) any person on any ship or aircraft registered in Pakistan wherever it may be.\n" +
                        "Explanation: In this section the word \"offence\" includes every act committed outside\n" +
                        "Pakistan which, if committed in Pakistan, would be punishable under this Code.\n" +
                        "\n\n \b Illustrations\n" +
                        "(a) A a Pakistani subject, commits a murder in Uganda. He can be tried and convicted of\n" +
                        "murder in any place in Pakistan in which he may be found.\n" +
                        "(b) [Omitted by Federal Laws (Revision & Declaration) Ordinance, XXVII of 1981].\n" +
                        "[(c) C, a foreigner who is in the service of Pakistan commits a murder in London. He can be tried and convicted of murder at any place in Pakistan in which he may be found.] Clause (c) subs. by the Federal Laws (Revision & Declaration) Ordinance, XXVII of 1981.\n" +
                        "(d) D, a British subject living in Junagadh, instigates E to commit a murder in Lahore. D is guilty of abetting murder.  ");
                mydb2.addsection("5 Certain laws not to be affected by this Act","INTRODUCTION",1,"Nothing in this Act is intended to repeal, vary, suspend or affect any of the provisions of any Act for punishing mutiny and desertion of officers, soldiers, sailors or airmen in the service of the State or of any special or local law].\n" +
                        "Sec. 5 subs. by the Federal Laws (Revision & Declaration) Ordinance, XXVII of 1981");

                //chapter 2
                mydb2.addchapters("GENERAL EXPLANATIONS","47","CHAPTER II");
                //sections 47
                //1
                mydb2.addsection("6 Definitions in the Code to be understood subject to exception","GENERAL EXPLANATIONS",2,"Throughout this Code every definition of an offence, every penal provision and every illustration of every such definition or penal provision, shall be understood subject to the exceptions contained in the chapter entitled \"General Exceptions,\" though those exceptions are not repeated in such definition, penal provision or illustration. \n\n Illustrations\n" +
                        "(a) The section in this Code, which contain definitions of offences, , do not express that a\n" +
                        "child under seven years of age cannot commit such offence; but the definitions are to be\n" +
                        "understood subject to the general exception which provides that nothing shall be an\n" +
                        "offence which is done by a child under seven years of age.\n" +
                        "(b) A, a police officer, without warrant, apprehends Z who has committed murder. Here A\n" +
                        "is not guilty of the offence of wrongful confinement; for he was bound by law to apprehend\n" +
                        "Z, and, therefore, the case falls within the genera) exception ' which provides that \"nothing\n" +
                        "is an offence which is done by a person who is bound by law to do it.\" ");
                //2
                mydb2.addsection("7 Sense of expression once explained","GENERAL EXPLANATIONS",2,"Every expression which is explained in any part of this Code is used in every part of this Code in conformity with the explanation. ");
                //3
                mydb2.addsection("8 Gender","GENERAL EXPLANATIONS",2,"The pronoun \"he\" and its derivatives are used of any person, whether male or female.");
                //4
                mydb2.addsection("9 Number","GENERAL EXPLANATIONS",2,"Unless the contrary appears from the context, words importing the singular number include the plural number, and words importing the plural number include the singular number.");
                //5
                mydb2.addsection("10 \"Man\"; \"Woman\"","GENERAL EXPLANATIONS",2,"The word \"man\" denotes a male human being of any age; the words \"woman\" denotes a female human being of any age. ");
                //6
                mydb2.addsection("11 \"Person\"","GENERAL EXPLANATIONS",2,"The word \"person\" includes any Company or Association, or body of " +
                        "persons, whether incorporated or not. ");
                //7
                mydb2.addsection("12 \"Public\"","GENERAL EXPLANATIONS",2,"The word \"Public\" includes any class of the public or any community. ");
                //8
                mydb2.addsection("13 Definition of \"Queen\"","GENERAL EXPLANATIONS",2," [Omitted by A. 0., 1961, Art. 2 and Sched. (w.e.f. the 23rd " +
                        "March, 1965)].");
                //9
                mydb2.addsection("14 \"Servant of the State\"","GENERAL EXPLANATIONS",2,"The words \"servant of the State\" denote all officers or " +
                        "servants continued/appointed or employed in Pakistan, by or under the authority of theFederal Government or any Provincial Government. ");
                //10
                mydb2.addsection("15 Definition of British-India ","GENERAL EXPLANATIONS",2,".[Rep. byA.0., 1937]. ");
                //3
                mydb2.addsection("16 Definition of \"Government of India\"","GENERAL EXPLANATIONS",2," [Rep. by AO. 1937].");
                //3
                mydb2.addsection("17 \"Government\"","GENERAL EXPLANATIONS",2,"The word \"Government\" denotes the person or persons authorized by " +
                        "law to administer executive Government in Pakistan, or in any part thereof. ");
                //3
                mydb2.addsection("18 Definition of Presidency","GENERAL EXPLANATIONS",2," [Rep. byAO., 1937]. ");
                //3
                mydb2.addsection("19 \"Judge\"","GENERAL EXPLANATIONS",2,"The word \"Judge\" denotes not only every person who is officially designated as a Judge, but also every person,\" Who is empowered by law to give, in any legal\n" +
                        "proceeding, civil or criminal, a definitive judgment or a judgment which, if not appealed " +
                        "against, would be definitive, or a judgment which, if confirmed by some other authority, " +
                        "would be definitive, or \n\n" +
                        "Who is one of a body of persons, which body of persons is empowered by law to give such Judgment. " +
                        "\n\nIllustrations\n" +
                        "(a) [Omitted by the Federal Laws (Revision & Declaration Ordinance, XXV// of 1981].\n" +
                        "(b) A Magistrate exercising jurisdiction in. respect of a charge on which he has power to " +
                        "sentence to fine or imprisonment with or without appeal, is a Judge.\n" +
                        "(c) [Rep. by the Federal Laws (Revision and Declaration) Act 1951 (26 of 1951), Section " +
                        "3 and 11, Schedule].\n" +
                        "(d) [Omitted by the Federal Laws (Revision & Declaration Ordinance, XXVII of 1981], \n");
                //3
                mydb2.addsection("20 \"Court of Justice\"","GENERAL EXPLANATIONS",2,"The words \"Court of Justice denote a Judge who is empowered " +
                        "by law to act judicially alone, or a body of Judges which is empowered by law to act " +
                        "judicially as a body, when such Judge or body of Judges is acting judicially. ");
                //3
                mydb2.addsection("21 \"Public servant\"","GENERAL EXPLANATIONS",2,"The words \"public servant\" denotes a person falling under any of " +
                        "the descriptions herein after following, namely:- \n" +
                        "First: [Omitted by the Federal Laws (Revision and Declaration) Ordinance, XXV// of 1981].\n" +
                        "Second: Every Commissioned Officer in the Military, Naval or Air Forces of Pakistan while " +
                        "serving under the Federal Government or any Provincial Government;\n" +
                        "Third: Every Judge;\n" +
                        "Fourth: Every officer of a Court of Justice whose duty it is, as such officer, to investigate or " +
                        "report on any matter of law or fact, or to make, authenticate, or keep any document, or to " +
                        "take charge or dispose of any property, or to execute any judicial process, or to administer " +
                        "any oath, or to interpret, or to preserve order in the Court; and every person specially " +
                        "authorized by a Court of Justice to perform any of such duties; \n" +
                        "Fifth: Every juryman, assessor, or member of a panchayat assisting a Court of Justice or " +
                        "public servant;\n" +
                        "Sixth: Every arbitrator or other person to whom any cause or matter has been referred for " +
                        "decision or report by any Court of Justice, or by any other competent public authority;\n" +
                        "Seventh ; Every person who holds any office by virtue of which he is empowered to place " +
                        "or keep any person in confinement;\n" +
                        "Eighth: Every officer of the Government whose duty it is, as such officer, to prevent " +
                        "offences, to give information of offences, to bring offenders to justice, or to protect the " +
                        "public health, safety or convenience;\n" +
                        "Ninth: Every officer whose duty it is, as such officer, to take, receive, keep or expend any " +
                        "property on behalf of the Government, or to make any survey, assessment or contract " +
                        "on behalf of the Government, or to execute any revenue process, or to investigate, or to " +
                        "report, or any matter affecting the pecuniary interests of the Government, or to make/ " +
                        "authenticate or keep any document relating to the pecuniary interests of the Government, " +
                        "or to prevent the infraction of any law for the protection of the pecuniary interests of the " +
                        "Government, and every officer in the service or. pay of the Government or remunerated by " +
                        "fees or commission for the performance of any public duty;\n" +
                        "Tenth : Every officer whose duty it is, as such officer, to take, receive, keep or expend any\n" +
                        "property, to make any survey or assessment or to levy any rate or tax for any secular " +
                        "common purpose of any village, town or district, or to make, authenticate or keep any " +
                        "document for the ascertaining of the rights of the people of any village, town or district; . \n" +
                        "Eleventh : Every person who holds any office in virtue of which he is empowered to\n" +
                        "prepare, publish, maintain or revise an electoral roll or to conduct an election or part of an " +
                        "elections\n" +
                        "\nIllustration\n" +
                        "A Municipal Commissioner is a public servant. \n" +
                        "Explanation 1 : Persons falling under any of the above descriptions are public servants, " +
                        "whether appointed by the Government or not.\n" +
                        "Explanation 2: Wherever the words \"public servant” occur, they shall be understood of " +
                        "every person who is in actual possession of the situation of a public servant, whatever " +
                        "legal defect there may be in his right to hold that situation.\n" +
                        "Explanation 3: The word \"election\" denotes an election for the purpose of selecting " +
                        "members of any legislative, municipal or other public authority, of whatever character, the " +
                        "method of selection to which is by, or under, any law prescribed as by election. ");
                //3
                mydb2.addsection("22 Movable property","GENERAL EXPLANATIONS",2," The words \"movable property\" are intended to include corporeal " +
                        "property of every description, except land and thing attached to the earth, or permanently " +
                        "fastened to anything which is attached to the earth.  ");
                //3
                mydb2.addsection("23 Wrongful gain","GENERAL EXPLANATIONS",2,"\"Wrongful gain\" is gain by unlawful means of property to which the " +
                        "person gaining is not legally entitled. \n\n\"Wrongful loss\": Wrongful loss\" is the loss by unlawful means of property to which the " +
                        "person losing it is legally entitled.\n\n" +
                        "Gaining wrongfully, Losing wrongfully: A person is said to gain wrongfully when such " +
                        "person retains wrongfully, as well as when such person acquires wrongfully. A person is " +
                        "said to lose wrongfully when such person is wrongfully kept out of any property, as well as " +
                        "when such person is wrongfully deprived of property. ");
                //3
                mydb2.addsection("24 \"Dishonestly\"","GENERAL EXPLANATIONS",2,"Whoever does anything with the intention of causing wrongful gain to " +
                        "one person or wrongful loss to another person, is said to do that thing \"dishonestly\". \n");
                //3
                mydb2.addsection("25 \"Fraudulently\"","GENERAL EXPLANATIONS",2,"A person is said to do ,a thing fraudulently if he does that thing with " +
                        "intent to defraud but not otherwise.");
                //3
                mydb2.addsection("26 \"Reason to believe\"","GENERAL EXPLANATIONS",2,"A person is said to have “reason to believe\" a thing if he has\n" +
                        "sufficient cause to believe that thing but not otherwise. ");

                mydb2.addsection("27 Property in possession of wife, clerk or servant","GENERAL EXPLANATIONS",2,"When property is in the " +
                        "possession of a person's Wife, clerk or servant, on account of that person, it is in that " +
                        "person's possession within the meaning of this Code.\n\n Explaination: A person employed temporarily on a particular occasion in the capacity of a " +
                        "clerk, or servant, is a clerk or servant within the meaning of this section. ");

                mydb2.addsection("28 \"Counterfeit\"","GENERAL EXPLANATIONS",2,"A person is said to \"counterfeit\" who causes one thing to resemble " +
                        "another thing, intending by means of that resemblance to practice deception, or knowing " +
                        "it to be likely that deception will thereby be practiced. \n\n" +
                        "Explanation 1: It is not essential to counterfeiting that the imitation should be exact. \n" +
                        "Explanation 2: When a person causes one thing to resemble another thing, and the " +
                        "resemblance is such that a person might be deceived thereby, it shall be presumed, until " +
                        "the contrary is proved, that the person so causing the one thing to resemble the other " +
                        "thing intended\" by means of that resemblance to practice deception or knew it to be likely " +
                        "that deception would thereby be practiced. ");

                mydb2.addsection("29 Document","GENERAL EXPLANATIONS",2,"The word \"document\" denotes any matter expressed or described upon " +
                        "any substance by means of letters, figures or marks, or by more than one of those means, " +
                        "intended to be used, or which may be used, as evidence of that matter.\n\n" +
                        "Explanation 1 : It is immaterial by what means or upon what substance, the letters, figures " +
                        "or marks are formed, or whether the evidence is intended for, or may be used in, a Court " +
                        "of Justice, or not.\n\n" +
                        "Illustrations\n" +
                        "A writing expressing the terms of a contract, which may be used as evidence of the " +
                        "contract, is a document.\n" +
                        "A cheque upon a banker is a document.\n" +
                        "A Power-of-Attorney is a document.\n" +
                        "A map or plan which is intended to be used or which may be used as evidence, is a " +
                        "document.\n" +
                        "A writing containing directions or instructions is a document.\n" +
                        "Explanation 2: Whatever is expressed by means of letters, figures or marks as explained " +
                        "by mercantile or other usage, shall be deemed to be expressed by such letter, figure " +
                        "or marks within the meaning of this section, although the same may not be actually " +
                        "expressed.\n\n" +
                        "Illustration\n" +
                        "A writes his name on the back of a bill of exchange payable to his order. The meaning of " +
                        "the endorsement, as explained by mercantile usage is that the bill is to be paid to the " +
                        "holder. The endorsement is a document and must be construed in the same manner as if " +
                        "the words \"pay to the holder\" or words to that effect had been written over the signature. ");
                mydb2.addsection("30 \"Valuable security\" ","GENERAL EXPLANATIONS",2,"The words \"valuable security denote a document which is, or " +
                        "purports to be a document whereby any legal right is created, extended, transferred " +
                        "restricted, extinguished or released, or whereby, any person acknowledges that he lies " +
                        "under legal liability, or has not certain legal right. \n" +
                        "Illustration A writes his name on the back of a bill of exchange. As the effect of this endorsement is to " +
                        "transfer the right to the bill to any person who may become the lawful holder of it, the " +
                        "endorsement is a \"valuable security\".");

                mydb2.addsection("31 \"A will\"","GENERAL EXPLANATIONS",2,"The words \"a will\" denote any testamentary document");

                mydb2.addsection("32 Words referring to acts include illegal omissions","GENERAL EXPLANATIONS",2,"In every part of this Code, " +
                        "except where contrary intention appears from the context, words which refer to acts done extend also to illegal omission. ");

                mydb2.addsection("33\"Act\", \"Omission\"","GENERAL EXPLANATIONS",2,"The word \"act\" denotes as well a series of acts as a single act; " +
                        "the word \"omission\" denotes as well a series of omissions as a single omission. ");

                mydb2.addsection("34 Acts done by several persons In furtherance of common intention","GENERAL EXPLANATIONS",2,"When a " +
                        "criminal act is done by several persons, in furtherance of the common intention of all, each " +
                        "such person is liable for that act in the same manner as if it were done by him alone. ");

                mydb2.addsection("35 When such an act is criminal by reason of its being done with a criminal " +
                        "knowledge or intention","GENERAL EXPLANATIONS",2,"Whenever an act, which is criminal only by reason of its being " +
                        "with a criminal knowledge or intention, is done by several persons, each of such persons " +
                        "who joins in the act with such knowledge or intention is liable for the act in the same " +
                        "manner as if the act were done by him alone with the knowledge or intention.");

                mydb2.addsection("36 Effects caused partly by act and partly by omission","GENERAL EXPLANATIONS",2,"Whoever the causing of a " +
                        "certain effect, or an attempt to cause that effect, by an act or by an omission, is an " +
                        "offence, it is to be understood that the causing of that effect partly by an act and pertly by " +
                        "an omission is the same offence.\n" +
                        "\nIllustration\n" +
                        "A intentionally causes Z's death, partly by illegally omitting to give Z food and partly by " +
                        "beating Z.A has committed murder. ");

                mydb2.addsection("37 Co-operation by doing one of several acts constituting an offence","GENERAL EXPLANATIONS",2,"When an " +
                        "offence is committed by means of several acts, whoever intentionally co-operates in the " +
                        "commission of that offence by doing any one of those acts, either singly or jointly with any " +
                        "other person, commits that offence.\n" +
                        "\nIllustrations\n" +
                        " (a) A and B agree to murder Z by severally and at different times giving him small " +
                        "dose of poison. A and B administer the poison according to the agreement with intent to " +
                        "murder Z. Z dies from the effects of the several doses of poison so administered to him." +
                        "Here A and B intentionally co-operate in the commission of murder and as each of them " +
                        "dose an act by which the death is caused, they are both guilty of the offence though their " +
                        "acts are separate. \n" +
                        " (B) A and B are joint jailors, and as such, have the charge of Z, a prisoner, alternately " +
                        "for six hours at a time. A and B, intending to cause Z's death, knowingly co-operate in " +
                        "causing that effect by illegally omitting, each during the time of his attendance, to furnish Z " +
                        "with food supplied to them for that purpose. Z dies of hunger. Both A and B are guilty of " +
                        "the murder of Z.\n" +
                        " (c) A, a jailor, has the charge of Z, a prisoner. A intending to cause Z's death, illegally " +
                        "omits to supply Z with food; in consequence of which Z is much reduced in strength, but " +
                        "the starvation is not sufficient to cause his death. A is dismissed from his office, and B " +
                        "succeeds him. B, without collusion or co-operation with A, illegally omits to supply Z with " +
                        "food, knowing that he is likely thereby to cause Z's death, Z dies of hunger. B is " +
                        "guilty of murder, but as A did not co-operate with B, A is guilty only of an attempt to " +
                        "commit murder.");

                mydb2.addsection("38 Persons concerned in criminal act may be guilty of different offences","GENERAL EXPLANATIONS",2,"Where " +
                        "several persons are engaged or concerned in the commission of a criminal act, they may " +
                        "be guilty of different offences by means of that act.\n" +
                        "\nIllustration\n" +
                        "A attacks Z under such circumstances of grave provocation that his killing of Z would be " +
                        "only culpable homicide not amounting to murder. B having ill-will towards Z and intending " +
                        "to kill him, and not having been subject to the provocation, assist A in killing Z. Here, " +
                        "though A and B are both engaged in causing Z's death, B is guilty of murder, and A is " +
                        "guilty only of culpable homicide. ");

                mydb2.addsection("39 \"Voluntarily\"","GENERAL EXPLANATIONS",2,"A person is said to cause an effect \"voluntarily\" when he causes it by" +
                        "means whereby he intended to cause it, or by means which, at the time of employing " +
                        "those means, he knew or had reason to believe to be likely to cause it.\n" +
                        "\nIllustrations\n" +
                        "A sets fire, by night, to an inhabited house in a large town, for the purpose of facilitating " +
                        "robbery and thus causes the death of a person. Here, A may not have intended to cause " +
                        "death, and may even be sorry that death has been caused by his act; yet, if he knew that " +
                        "he .was likely to cause death; he has caused death voluntarily. ");

                mydb2.addsection("40 \"Offence\"","GENERAL EXPLANATIONS",2,"Except in the chapters and sections mentioned in clauses 2 and 3 of this " +
                        "section, the word \"offence\" denotes a thing made punishable by this Code. In Chapter IV, " +
                        "Chapter V-A and in the following sections, namely, Sections 64, 65, 66, 67, 71, 109, 110, " +
                        "112. 114, 115, 116, 117, 187, 194, 195, 203, 211, 213, 214. 221, 222, 223. 224, 225, 327, " +
                        "328.329,330.331,347,348, 388, 389 and 445, the word \"offence\" denotes a thing " +
                        "punishable under this Code, or under, any/special or local law as hereinafter defined.\n\n" +
                        " And in Sections 141, 176, 177, 201, 202, 212, 216 and 441 the word \"offence\" has " +
                        "the same meaning when the thing punishable under the special or local law is punishable " +
                        "under such law with imprisonment for a term of six months or upwards, whether with or " +
                        "without fine.");

                mydb2.addsection("41 \"Special law\"","GENERAL EXPLANATIONS",2,"A \"special law\" is a taw applicable to a particular subject. ");

                mydb2.addsection("42 \"Local Law\"","GENERAL EXPLANATIONS",2,"A \"local law\" is a law applicable only to a particular part of the territories " +
                        "comprised in Pakistan. \n");
                mydb2.addsection("43 Illegal--Legally bound to do\"","GENERAL EXPLANATIONS",2,"The word \"illegal\" is applicable to everything which is " +
                        "an offence or which is prohibited by law, or which furnishes ground for a civil action, and a " +
                        "person is said to be \"legally bound to do\" whatever it is illegal in him to omit. ");

                mydb2.addsection("44 \"Injury\"","GENERAL EXPLANATIONS",2," The \"injury\" denotes any harm. Whatever illegally caused to any person, in " +
                        "body, mind, reputation or property. ");

                mydb2.addsection("45 \"Life\"","GENERAL EXPLANATIONS",2,"The word \"life\" denotes the life of a human being, unless the contrary appears " +
                        "from the context. ");
                mydb2.addsection("46 “Death”","GENERAL EXPLANATIONS",2,"The word \"death\" denotes the death of a human being unless the contrary " +
                        "appears from the context. \n");
                mydb2.addsection("47 “Animal\"","GENERAL EXPLANATIONS",2,"The word \"animal\" denotes any living creature other than a human being. ");
                mydb2.addsection("48 \"Vessel\"","GENERAL EXPLANATIONS",2,"The word \"vessel\" denotes anything made for the conveyance by water of " +
                        "human beings or of property. ");
                mydb2.addsection("49 \"Year”; \"Month\"","GENERAL EXPLANATIONS",2,"Wherever the word \"year\" or the word \"month\" is used, it is to be\n" +
                        "understood that the year or the month is to be reckoned according to the British calendar. \n");

                mydb2.addsection("50 \"Section\"","GENERAL EXPLANATIONS",2,"The word \"section\" denotes one of those portions of a chapter of this Code " +
                        "which are distinguished by prefixed numeral figures.");
                mydb2.addsection("51 \"Oath''","GENERAL EXPLANATIONS",2,"The word \"oath\" includes a solemn affirmation substituted by law for an oath, " +
                        "and any declaration required or authorized by law to be made before a public servant or, " +
                        "to be used for the purpose of proof, whether in a Court of Justice or not. ");
                mydb2.addsection("52 \"Good faith\"","GENERAL EXPLANATIONS",2," Nothing is said to be done or believed in \"good faith\" Which is done or " +
                        "believed without due care and attention. \n");
                mydb2.addsection("52-A. \"Harbour\"","GENERAL EXPLANATIONS",2," Except in Section 157, and in Section, 130 in the case in which the " +
                        "harbour is given by the wife or husband of a person harboured, the word \"harbour\" " +
                        "includes the supplying a person with shelter, food, drink, money, clothes, arms; " +
                        "ammunition or means of conveyance, or assisting a person by any means, whether of the " +
                        "same kind as, those enumerated in this section or not, to evade apprehension. \n Section 52-A inst. by the Penal Code (Amendment) Act, VII! of 1942");

                //chapter 3

                mydb2.addchapters("OF PUNISHMENTS.","23","CHAPTER III ");

                //sections
                mydb2.addsection("53 Punishments ","PUNISHMENTS.",3,"The punishments to which offenders are liable under the " +
                        "provisions of this Code are:\n" +
                        "Firstly, . Qisas;\n" +
                        "Secondly, Diyat;\n" +
                        "Thirdly, Arsh;\n" +
                        "Fourthly, Daman;\n" +
                        "Fifthly, Ta'zir;\n" +
                        "Sixthly, Death;-\n" +
                        "Seventhly, Imprisonment for life\n" +
                        "Eighthly, Imprisonment which is of two descriptions, namely:--\n" +
                        ",(i) Rigorous, i.e., with hard labour;\n" +
                        "(ii) Simple;\n" +
                        "Ninthly, Forfeiture of property;\n" +
                        "Tenthly, Fine]\n" +
                        "Section 53 subs. by the Criminal Law (Amendment) Act, II of 1997");
                mydb2.addsection("54 Commutation of sentence of death ","PUNISHMENTS.",3,"In every case in which sentence of death shall " +
                        "have been passed the Federal Government or the Provincial Government of the " +
                        "Province within which the offender shall have been sentenced may, without the consent of " +
                        "the offender, commute the punishment for any other punishment provided by this Code:\n\n" +
                        "[Provided, that, in a case in which sentence of death shall have been passed against an\n" +
                        "offender convicted for an offence of qatl, such sentence shall not be commuted without\n" +
                        "the consent of the heirs of the victim].\n" +
                        "Proviso added by the Criminal Law (Amendment) Act, II of 1997");
                mydb2.addsection("55 Commutation of sentence of imprisonment for life","PUNISHMENTS.",3,"In every case in which " +
                        "sentence of imprisonment for life shall have been passed, the Provincial Government of " +
                        "the Province within which the offender, shall have been sentenced may, without the " +
                        "consent of the offender, commute the punishment for imprisonment of either description " +
                        "for a term not exceeding fourteen years:\n\n" +
                        "Provided that, in a case in which sentence of imprisonment for life shall have been passed " +
                        "against an offender convicted for an offence punishable under Chapter XVI, such " +
                        "punishment shall not be commuted without the consent of the victim or, as the case may " +
                        "be, of his heirs.\n" +
                        "Proviso added by the Criminal Law (Amendment) Act, II of 1997");
                mydb2.addsection("55-A. Saving for President prerogative","PUNISHMENTS.",3,"Nothing in Section fifty-four or Section fifty-five " +
                        "shall derogate from the right of the President to grant pardons, reprieves, respites or " +
                        "remissions of punishment: \n\n" +
                        "Provided that such right shall not without the consent of the victim or, as the case may be. " +
                        "of the heirs of the victim, be exercised for any sentence awarded under Chapter XVI],\n" +
                        "Section 55-A and proviso ins. by A.O., 1937.\n");
                mydb2.addsection("56 Sentence of Europeans and Americans to penal servitude","PUNISHMENTS.",3,"[Rep. by the Criminal Law " +
                        "(Extinction of Discriminatory Privileges) Act, 1949 (II of 1950), Schedule.] ");
                mydb2.addsection("57 Fractions of terms of punishment","PUNISHMENTS.",3,"In calculating fractions of terms of punishment, " +
                        "imprisonment for life shall be reckoned as equivalent to imprisonment for twenty-five " +
                        "years. ");
                mydb2.addsection("58 Offenders sentenced to transportation how dealt with until, transported","PUNISHMENTS.",3,"[Omitted by " +
                        "the Law Reforms Ordinance, XII of 1972, S. 2]. ");
                mydb2.addsection("59 Transportation instead of imprisonment","PUNISHMENTS.",3,"[Omitted by the Law Reforms Ordinance, XII " +
                        "of 1972, S. 2]. ");
                mydb2.addsection("60 Sentence may be (in certain cases of imprisonment) wholly or partly rigorous or " +
                        "simple","PUNISHMENTS.",3," In every case in which an offender is punishable with imprisonment which may be " +
                        "of either description, it shall be competent to the Court which sentences such offender to " +
                        "direct in the sentence that such imprisonment shall be wholly rigorous, or that such " +
                        "imprisonment shall be wholly simple, or that any part of such imprisonment shall be " +
                        "rigorous and the rest simple. ");
                mydb2.addsection("61 Sentence of forfeiture of property","PUNISHMENTS.",3," [Repealed by .the Penal Code (Amendment) Act, " +
                        "XVI of 1921, S. 4].");
                mydb2.addsection("62 Forfeiture of property, in respect of offenders punishable with death, transportation or " +
                        "imprisonment","PUNISHMENTS.",3,"[Repealed by the Penal Code (Amendment) Ad, XVf of 1921, S. 4]. \n");
                mydb2.addsection("63 Amount of fine","PUNISHMENTS.",3,"Where no sum is expressed to which a fine may extend, the amount " +
                        "of fine to which the offender is liable is unlimited, but shall not be excessive. ");
                mydb2.addsection("64 Sentence of imprisonment for non-payment of fine","PUNISHMENTS.",3,"In every case of an offence " +
                        "punishable with imprisonment as well. as fine, in which the offender is sentenced to a fine, " +
                        "whether with or without imprisonment, and in every case of an offence punishable with " +
                        "imprisonment or fine, or with fine only, in which the offender is sentenced to a fine, it shall " +
                        "be competent to the Court which sentences such offender to direct by the sentence that, " +
                        "in default of payment of the fine, the offender, shall suffer imprisonment for a certain term, " +
                        "which imprisonment shall be. in excess of any other imprisonment to which he may have " +
                        "been sentenced or to which he may be liable under a commutation of a sentence. ");
                mydb2.addsection("65 Limit to imprisonment for non-payment of fine when imprisonment and fine " +
                        "awardable","PUNISHMENTS.",3," The term for which the Court directs the offender to be imprisoned in " +
                        "default of payment of a fine shall, not exceed one-fourth of the term of imprisonment, " +
                        "which is the maximum fixed for the offence, if the offence be punishable with " +
                        "imprisonment as well as fine. ");
                mydb2.addsection("66 Description of imprisonment for non-payment of fine","PUNISHMENTS.",3,"The imprisonment which " +
                        "the Court imposes in default of payment of a fine may be of any description to which the " +
                        "offender might have been sentenced for the offence.");
                mydb2.addsection("67 Imprisonment for non-payment of fine When offence punishable with fine only: If " +
                        "the offence be punishable with fine only","PUNISHMENTS.",3,"the imprisonment which the Court " +
                        "imposes in default of payment of the fine shall be simple, and the term for which the Court " +
                        "directs the offender to be imprisoned, in default of payment of fine, shall not exceed the " +
                        "following scale that is to say, for any term not exceeding two months when the amount of " +
                        "the fine shall not exceed fifty rupees, and for any term not exceeding four months when " +
                        "the amount shall not exceed, one hundred rupees, and for any term not exceeding six " +
                        "months in any other case. ");
                mydb2.addsection("68 Imprisonment to terminate on payment of fine","PUNISHMENTS.",3,"The imprisonment which is imposed " +
                        "in default of payment of a fine shall terminate whenever that fine is either paid or levied by " +
                        "process of law. ");
                mydb2.addsection("69 Termination of imprisonment on payment of proportional part of fine","PUNISHMENTS.",3," If, before " +
                        "the expiration of the term of imprisonment fixed in default of payment, such a proportion " +
                        "of the fine be paid or levied that the term of imprisonment suffered in default of payment is " +
                        "not less than proportional to the part of the fine still unpaid, the imprisonment shall " +
                        "terminate.\n\n" +
                        "Illustration\n" +
                        "A is sentenced to fine of one hundred rupees and to four months, imprisonment in default " +
                        "of payment. Here, seventy-five rupees of the fine be paid or levied before the expiration of " +
                        "one month of the imprisonment. A will be discharged as soon as the first month has " +
                        "expired, if seventy-five rupees be paid or levied at the time of the expiration of the first " +
                        "month, or at any later time while .A continues imprisonment. A will be immediately " +
                        "discharged, if fifty rupees of the fine be paid or levied before the expiration of two months " +
                        "of the imprisonment, A will be discharged as soon as the two months are completed, if fifty " +
                        "rupees be paid or levied at the time of the expiration of those two months, or at any later " +
                        "time while A continues in imprisonment, A will be immediately discharged. ");
                mydb2.addsection("70 Fine leviable within six years, or during imprisonment-Death not to discharge " +
                        "property from liability","PUNISHMENTS.",3," The fine or any part thereof which remains unpaid, may be levied " +
                        "at any time within six years after the passing of the sentence/and if, under the sentence, " +
                        "the offender be liable to imprisonment for a longer period than six years, then at any time " +
                        "previous to the expiration of that period; and the death of the offender dose not discharge " +
                        "from the liability any property which would, after his death, be legally liable for his debts");
                mydb2.addsection("71 Limit of punishment of offence made up of several offences","PUNISHMENTS.",3,"where anything " +
                        "which is an offence is made up of parts, any of which parts is itself an offence, the " +
                        "offender shall not be punished with the punishment of more than one of such his offences, " +
                        "unless it be so expressly provided. \n\n" +
                        "Where anything Is an offence falling within two or more separate definitions of any " +
                        "law in force for the time being by which offences are defined or punished, or \n\n" +
                        "Where several acts, of which one or more than one would by itself or themselves " +
                        "constitute an offence, constitute, when combined, a different offence, the offender shall " +
                        "not be punished with a more severe punishment than the Court which tries him could " +
                        "award for any one of such offence.\n" +
                        "\nIllustrations\n\n" +
                        "(a) A gives Z fifty strokes with a stick. Here A may have committed the offence of " +
                        "voluntarily causing hurt to Z by the whole beating, and also by each of the blows which " +
                        "makes up the whole beating. If were liable to punishment for every blow, they might be " +
                        "imprisoned for fifty years, one for each blow. But he is liable only to one punishment for " +
                        "the whole beating.\n" +
                        "(b) But if, while A is beating Z, Y interferes, and A intentionally strikes Y, here as the blow " +
                        "given to Y is no part of the act whereby A voluntarily cause hurt to Z, A is liable to one " +
                        "punishment, for voluntarily causing hurt to Z, and to another for the blow given to Y.");
                mydb2.addsection("72 Punishment of person guilty of one of several offences, the judgment stating " +
                        "that it is doubtful of which","PUNISHMENTS.",3,": In all cases in which judgment is given that a person is " +
                        "guilty of one of several offences specified in the judgment, but that it is doubtful of which of " +
                        "these offences he is guilty, the offender shall be punished for the offence for which the " +
                        "lowest punishment is provided if the same punishment is not provided, for all. ");
                mydb2.addsection("73 Solitary confinement","PUNISHMENTS.",3,"Whenever any person is convicted of an offence for which " +
                        "under this Code the Court has power to sentence him to rigorous imprisonment, ,the Court " +
                        "may, by its sentence, order that the offender shall be kept in solitary confinement for any " +
                        "portion or portions of the imprisonment to which he is sentenced, not exceeding three " +
                        "months in the whole, according to the following scale, that is to say\"\n\n" +
                        "a time not exceeding one month if the term of imprisonment shall not exceed six months;\n\n" +
                        "a time not exceeding two months if the term of imprisonment shall exceed six months and " +
                        "shall not exceed one year;\n\n" +
                        "a time not exceeding three months if the term of imprisonment shall exceed one year. ");
                mydb2.addsection("74 Limit of solitary confinement","PUNISHMENTS.",3,"in executing a sentence of solitary confinement, such " +
                        "confinement shall in no case exceed fourteen days at a time, with intervals between the " +
                        "period of solitary confinement of not less duration than such periods, and when the " +
                        "imprisonment awarded shall exceed three months, the solitary confinement shall not " +
                        "exceed seven days in any one month of the whole imprisonment awarded, with intervals " +
                        "between the periods of solitary confinement of not less -duration than such periods.");
                mydb2.addsection("75 Enhanced punishment for certain offenders under Chapter XII or Chapter XVII " +
                        "after previous conviction","PUNISHMENTS.",3,"Whoever, having been convicted\"\n\n " +
                        "(a) by a Court in Pakistan of an offence punishable under Chapter XII or Chapter XVII of " +
                        "this Code with imprisonment of either description for a term of three years or upwards, or\n\n" +
                        "(b) [Omitted by thQ Federal Laws (Revision and Declaration), Ordinance, XXV// of 1981].\n\n" +
                        "shall be guilty of any offence punishable under either of those Chapters with the " +
                        "imprisonment for the like term, shall be subject for every such subsequent offence to " +
                        "imprisonment for life, or to imprisonment of either description for a term which may extend " +
                        "to ten years. ");

                //chapter 4
                mydb2.addchapters("GENERAL EXCEPTIONS ","31","CHAPTER IV");
                mydb2.addsection("76 Act done by a person bound, or by mistake of fact believing himself bound, by " +
                        "law","GENERAL EXCEPTIONS",4," Nothing is an offence which Is done by a person who is, or who by reason of a " +
                        "mistake of fact and not reason of a mistake of law in good faith believes himself to be,\n" +
                        "bound by law to do it.\n\n" +
                        "Illustrations\n\n" +
                        "(a) A, a soldier, fires on a mob by the order of his superior officer, in conformity, with the " +
                        "commands of the law. A has committed no offence.\n\n" +
                        "(b) A an officer of a Court of Justice, being ordered by that Court to arrest Y and after due " +
                        "enquiry, believing Z to be Y arrests Z. A has committed no offence. ");
                mydb2.addsection("77 Act of Judge when acting judicially","GENERAL EXCEPTIONS",4," Nothing is an offence which is done by a Judge " +
                        "when acting judicially in the exercise of any power which is, or which in good faith he " +
                        "believes to be,' given to him by law. ");
                mydb2.addsection("78 Act done pursuant to the judgment or order of Court","GENERAL EXCEPTIONS",4,"Nothing which is done in " +
                        "pursuance of, or which is warranted by the judgment or order of, a Court of Justice, if " +
                        "done whilst such judgment or order remains in force, is an offence, notwithstanding the " +
                        "Court may have had no jurisdiction to pass such judgment or order, provided the person " +
                        "doing the act in good faith believes that the Court had such jurisdiction. \n");
                mydb2.addsection("79 Act done by a person justified, or by mistake of fact believing himself justified, " +
                        "by law","GENERAL EXCEPTIONS",4,"Nothing is an offence which is done by any person who is justified by law, or who " +
                        "by reason of a mistake of fact and not by reason of a mistake of law in good faith, believes " +
                        "himself to be justified by law, in doing it.\n\n" +
                        "Illustration \n\n" +
                        "A sees Z commit what appears to A to be a murder. A, in the exercise, to the best of his " +
                        "judgment, exerted in good faith of the power which the law gives to all persons of " +
                        "apprehending murders in the act, seizes Z, in order to bring Z before the proper " +
                        "authorities. A has committed no offence, though it may turn out that Z was acting in selfdefence. ");
                mydb2.addsection("80 Accident in doing a lawful act","GENERAL EXCEPTIONS",4,"Nothing is an offence which is done by accident or " +
                        "misfortune, and without any criminal intention or knowledge in the doing of a lawful act " +
                        "in a lawful manner by lawful means and with proper care and caution. \n\n" +
                        "Illustration\n\n" +
                        "A is at work with a hatchet; the head flies off and kills a man who is standing by. Here if " +
                        "there was no want of proper caution on the part of A, his act is excusable and not an " +
                        "offence. ");
                mydb2.addsection("81 Act likely to cause harm, but done without criminal intent, and to prevent other " +
                        "harm","GENERAL EXCEPTIONS",4,"Nothing is an offence merely by reason of its being done with the knowledge " +
                        "that it is likely to cause harm, if it be done without any criminal intention to cause harm, " +
                        "and in good faith for the purpose of preventing or avoiding other harm to person or " +
                        "property.\n\n" +
                        "Explanation : It is a question of fact in such a case whether the harm to be prevented or " +
                        "avoided was of such a nature and so imminent as to justify or excuse the risk of doing " +
                        "the act with the knowledge that it was likely to cause harm.\n\n" +
                        "Illustrations\n\n" +
                        "(a) A, the captain of a steam vessel, suddenly and without any fault or negligence on his " +
                        "part, finds himself in such a position that, before he can stop his vessel, he must inevitably " +
                        "run down a boat B, with twenty or thirty passengers on board; unless he changes the " +
                        "course of his vessel, and that, by changing his course, he must incur risk of running down " +
                        "a boat C with only two passengers on board, which he may possibly clear Here, if A alters " +
                        "his course without any intention to run down the boat C and in good faith for the purpose " +
                        "of avoiding the danger to the passengers in the boat B, he is not guilty of an offence, " +
                        "though he may run down the boat C by doing an act which he knew was likely to cause " +
                        "that effect, if it be found as a matter of fact that the danger which he intended to avoid was " +
                        "such as to excuse him incurring the risk of running down C.\n\n" +
                        "(b)A, in a great fire, pulls down houses in order to prevent the conflagration from " +
                        "spreading. He does this with the intention in good faith of saving human life or property. " +
                        "Here, if it be found that the harm to be prevented was of such a nature and so imminent " +
                        "as to excuse A's act, A is not guilty of the offence. ");
                mydb2.addsection("82 Act of a child under seven years of age","GENERAL EXCEPTIONS",4,"Nothing is an offence, which is done by a " +
                        "child under seven years of age. ");
                mydb2.addsection("83 Act of a child above seven and under twelve of immature understanding","GENERAL EXCEPTIONS",4,"Nothing " +
                        "is an offence which is done by a child above seven years of age and under twelve, " +
                        "who has not attained sufficient maturity of understanding to judge of the nature and " +
                        "consequences of his conduct on that occasion. ");
                mydb2.addsection("84 Act of a person of unsound mind","GENERAL EXCEPTIONS",4,"Nothing is an offence which is done by a person " +
                        "who, at the time of doing it, by reason of unsoundness of mind, is incapable of knowing " +
                        "the nature of the act, or that he is doing what is either wrong.. or contrary to law. \n");
                mydb2.addsection("85 Act of a person incapable of Judgment by reason of intoxication caused against " +
                        "his will","GENERAL EXCEPTIONS",4,"Nothing is an offence which is done by a person who, at the time of doing it, " +
                        "is, by reason of intoxication, incapable of knowing the nature of the act, or that he is doing " +
                        "what is either wrong, or contrary to law; provided that the thing which intoxicated him was " +
                        "administered to him without his knowledge or against his will. ");
                mydb2.addsection("86 Offence requiring a particular intent or knowledge committed by one who is intoxicated","GENERAL EXCEPTIONS",4," In cases where an act done is not an offence unless done with a particular " +
                        "knowledge or intent, a person who dose the act in a state of intoxication shall be liable to " +
                        "be dealt with as if he had the same knowledge as he would have had if he had not been " +
                        "intoxicated, unless the thing which intoxicated him was administered to him without his " +
                        "knowledge or against his will.");
                mydb2.addsection("87 Act not Intended and not known to be likely to cause death or grievous hurt, " +
                        "done by consent","GENERAL EXCEPTIONS",4,": Nothing which is not intended to cause death, or grievous hurt, and " +
                        "which is not known by doer to be likely to cause death, or grievous hurt, is an offence by " +
                        "reason of any harm which it may cause, or be intended by the doer to cause, to any " +
                        "person, above eighteen years of age, who has given consent, whether express or implied, " +
                        "to suffer that harm; or by reason of any harm which it may be known by the doer to be " +
                        "likely to cause to any such person who has consented to take the risk of that harm.\n\n" +
                        "Illustration\n\n" +
                        "A and Z agree to fence with each other for amusement. This agreement implies the " +
                        "consent of each to suffer any harm which in the course of such fencing, may be caused " +
                        "without foul play; and if A, while playing fairly, hurts Z, A commits no offence. ");
                mydb2.addsection("88 Act not intended to cause death, done by consent in good faith for person's " +
                        "benefit","GENERAL EXCEPTIONS",4,"Nothing, which is not intended to cause death, is an offence by reason of any " +
                        "harm which it may cause, or be intended by the doer to cause, or be known by the doer to " +
                        "be likely to cause, to any person for whose benefit it is done in good faith, and who has " +
                        "given a consent, whether express or implied, to suffer that harm, or to take the risk of that " +
                        "harm.\n\n" +
                        "Illustration\n\n" +
                        "A, a surgeon, knowing that a particular operation is likely to cause of death of Z, who " +
                        "suffers under the painful complaint, but not intending to cause Z's death, and intending, in  " +
                        "good faith for Z's benefit, performs that operation on Z. with Z's consent. A has-committed " +
                        "no offence. ");
                mydb2.addsection("89 Act done In good faith for benefit of child or insane person, by or by consent of " +
                        "guardian","GENERAL EXCEPTIONS",4,": Nothing which is done in good faith for the benefit of a person under twelve " +
                        "years of age, or of unsound mind, by or by consent, either express or implied, of the " +
                        "guardian or other person having lawful charge of that person, is an offence by reason of " +
                        "any harm which it may cause, or be intended by the doer to cause or be known by the " +
                        "doer to be likely to cause to that person:\n\n" +
                        "Provided First: That this exception shall not extend to the intentional causing of death, or " +
                        "to the attempting to cause death;\n\n" +
                        "Secondly: That this exception shall not extend to the doing of anything which the person " +
                        "doing it knows to be likely to cause death, for any purpose other than the preventing of " +
                        "death or grievous hurt; or the curing of any grievous disease or infirmity;\n\n" +
                        "Thirdly: That this exception shall not extend to the voluntary causing of grievous hurt, or to " +
                        "the attempting to cause grievous hurt, unless it be for the purpose of preventing death or " +
                        "grievous hurt, or the curing of any grievous disease or infirmity;\n\n" +
                        "Fourthly: That this exception shall not extend to the abetment of any offence, to the " +
                        "committing of which offence it would not extend.\n\n" +
                        "Illustration\n\n" +
                        "A, in good faith, for his child's benefit without his child's consent, has his child cut for the " +
                        "stone by \"a surgeon, knowing it to be likely that the operation will cause the child's death, " +
                        "but not intending to cause the child's death. A is within the exception, inasmuch as his " +
                        "object was the cure of the child. ");
                mydb2.addsection("90 Consent known to be given under fear or misconception","GENERAL EXCEPTIONS",4," A consent is not such a " +
                        "consent as is intended by any action of this Code, if the consent is given by a person " +
                        "under fear of injury, or under a misconception of fact, and if the person doing the act " +
                        "knows, or has reason to believe, that the consent was given in consequence of such " +
                        "fear or misconception; or\n\n" +
                        "Consent of insane person: If the consent is given by a person who, from unsoundness " +
                        "of mind, or intoxication, is unable to understand the nature and consequence of that to " +
                        "which he gives his consent; or\n\n" +
                        "Consent of child: Unless the contrary appears from the context, if the consent is given by " +
                        "a person who is under twelve years of age.");
                mydb2.addsection("91 Exclusion of acts which are offences independently of harm caused","GENERAL EXCEPTIONS",4,": The " +
                        "exceptions in Sections 87, 88 and 89 do not extend to acts which are offences " +
                        "independently of any harm which they may cause, or be intended to cause, or be known " +
                        "to be likely to cause, to the person giving the consent or on whose behalf the consent is " +
                        "given.\n\n" +
                        "Illustration\n\n" +
                        "Causing miscarriage (unless caused in good faith for the purpose of saving the life of the " +
                        "woman) to an offence independently of any harm which it may cause or be intended, to " +
                        "cause to the woman. Therefore it is not an offence by reason of such harm; and the " +
                        "consent of the woman or of her guardian to the causing of such miscarriage dose not " +
                        "justify the act. ");
                mydb2.addsection("92 Act done in good faith for benefit of a person without consent","GENERAL EXCEPTIONS",4," Nothing an offence " +
                        "by reason of any harm which it may cause to a person by whose benefit it is done in good " +
                        "faith even without that person's consent, if the Circumstances are such that is impossible " +
                        "for that person to signify consent, or if that person is incapable of giving consent, and has " +
                        "no guardian or other person in lawful charge of him from whom it is possible to obtain " +
                        "consent in time for the thing to be done with benefit:\n\n" +
                        "Provided First: That this exception shall not extend to the intentional causing of death, or " +
                        "the attempting to cause death;\n\n" +
                        "Secondly: That this exception shall not extend to the doing of anything which the person " +
                        "doing it knows to be likely to cause death, for any purpose other than the preventing of " +
                        "death or grievous, hurt, or the curing of any grievous disease or infirmity;\n\n" +
                        "Thirdly: That this exception shall not extend to the voluntary causing of hurt, or to the " +
                        "attempting to cause hurt for any purpose other than the preventing of death or hurt; " +
                        "Fourthly: That this exception shall not extend to the abetment of any offence, to the " +
                        "committing of which offence it would not extend.\n\n" +
                        "Illustration\n\n" +
                        "(a) Z is thrown from his horse, and is insensible. A, a surgeon, finds that Z requires to be " +
                        "trepanned. A not Intending Z's death but in good faith for Z's benefit, performs the trepan " +
                        "before Z recovers his power of judging for himself. A has committed no offence.\n\n" +
                        "(b) Z is carried off by a tiger. A fires at the tiger knowing it to be likely that the shot may kill " +
                        "Z, but not intending to kill Z, and in good faith intending Z's benefit A's ball gives Z a " +
                        "mortal wound. A has committed no offence.\n\n" +
                        "(c) A, a surgeon, sees child suffer an accident which is likely to prove fatal unless an " +
                        "operation be immediately performed. There is no time to apply to the child's guardian. A " +
                        "performs the operation in spite of the entreaties of the child, intending, in good faith, the " +
                        "child's benefit. A has committed no offence. \n\n" +
                        "(d) A is in a house which is on fire with Z, a child. People below hold out a blanket. A " +
                        "drops the child from the house-top, knowing it to be likely that the fall may kill the child, but " +
                        "not intending to kill the child and intending, in good faith, the child's benefit. Here even, if " +
                        "the child is killed by the fall, A has committed no offence.\n\n" +
                        "Explanation : Mere pecuniary benefit is not benefit within the meaning of Sections 88,89 " +
                        "and 92. ");
                mydb2.addsection("93 Communication made in good faith","GENERAL EXCEPTIONS",4,"No communication made in good faith is an " +
                        "offence by reason of any harm to the person to whom it is made for the benefit of that " +
                        "person. '\n\n" +
                        "Illustration\n\n" +
                        "A, a surgeon, in good-faith, communicates to a patient his opinion that he cannot live. The " +
                        "patient dies in consequence of the shock. A has committed no offence, though he knew it " +
                        "to be likely that the communication might cause the patient's death. ");
                mydb2.addsection("94 Act to which a person is compelled by threats","GENERAL EXCEPTIONS",4,"Except murder, and offences " +
                        "against the State punishable with death, nothing is an offence which is done by a person " +
                        "who is compelled to do it by threats, which, at the time of doing it, reasonably cause the " +
                        "apprehension that instant death to that person will otherwise be the consequence: " +
                        "Provided the person doing the act did not of his own accord, or from a reasonable " +
                        "apprehension of harm to himself short of instant death, place himself in the situation by " +
                        "which he became subject to such constraint.\n\n" +
                        "Explanation 1: A person who, of his own accord, or by reason of a threat of being beaten, " +
                        "joins a gang of dacoits, knowing their character, is not entitled to the benefit of this " +
                        "exception on the ground\" of his having been compelled by his associates to do anything " +
                        "that is an offence by law.\n\n" +
                        "Explanation 2: A person seized by a gang of dacoits, and forced by threat of instant death, " +
                        "to do a thing, which is an offence by law; for example, a smith compelled to take his " +
                        "tools and to force the door of a house for the dacoits to enter and plunder it, is entitled to " +
                        "the benefit of this exception. ");
                mydb2.addsection("95 Act causing slight harm","GENERAL EXCEPTIONS",4,"Nothing is an offence by reason that it causes, or that it is " +
                        "intended to cause, or that it is known to be likely to cause, any harm, if that harm. is so " +
                        "slight that no person of ordinary sense and temper would complain of such harm.");
                mydb2.addsection("96 Things done in private defence","GENERAL EXCEPTIONS",4,"Nothing is an offence which is done in the exercise " +
                        "of the right of private defence.");
                mydb2.addsection("97 Right of private defence of the body and of property","GENERAL EXCEPTIONS",4,"Every person has a right, " +
                        "subject to the restrictions contained in Section 99, to defend;  \n\n" +
                        "First: His own body, and the body of any other person, against any offence affecting the " +
                        "human body;\n\n" +
                        "Secondly: The property, whether movable or immovable, of himself or of any other " +
                        "person, against any act which is an offence falling under the definition of theft, robbery, " +
                        "mischief or criminal trespass, or which is an attempt to commit theft, robbery, mischief or " +
                        "criminal trespass. ");
                mydb2.addsection("98 Right of private defence against the act of a person of unsound mind, etc.","GENERAL EXCEPTIONS",4,"When " +
                        "an act, which would otherwise be a certain offence, is not that offence, by reason of " +
                        "the youth, the want of maturity of understanding, the unsoundness of mind or the " +
                        "intoxication of the person doing that act, or by reason of any misconception on the part of " +
                        "that person, every person has the same right of private defence against that act which he " +
                        "would have if the act were that offence. \n\n" +
                        "Illustrations\n\n" +
                        "(a) Z, under the influence of madness, attempts to kill A; Z is guilty of no offence, but A " +
                        "has the same right of private defence which he would have if Z were sane.\n\n" +
                        "(b) A enters by night a house which he is legally entitled to enter. Z in good faith, taking A " +
                        "for a house-breaker, attacks A. Here Z by attacking A under this misconception, commits " +
                        "no offence. But A has the same right of private defence against Z, which he would have if " +
                        "Z were not acting under that misconception. ");
                mydb2.addsection("99 Act against which there is no right of private defence","GENERAL EXCEPTIONS",4,"There is no right of private " +
                        "defence against an act which dose not reasonably cause the apprehension of death " +
                        "or of grievous hurt, if done, or attempted to be done by a public servant acting in good " +
                        "faith under colour, of his office, though that act may not be strictly justifiable by law. \n\n" +
                        "\tThere is no right of private defence against an act which dose not reasonably " +
                        "cause the apprehension of death or of grievous hurt, if done, or attempted to be done, by " +
                        "the direction of a public servant acting in good faith under colour of his office though that " +
                        "direction may not be strictly justifiable by law.\n\n" +
                        "\tThere is no right of private defence in cases in which there is time to have recourse to the " +
                        "protection of the public authorities.\n\n" +
                        "\tExtent to which the right may be exercised : The right of private defence in no " +
                        "case extends to the inflicting of more harm than it is necessary to inflict for the purpose of " +
                        "defence.\n\n" +
                        "Explanation 1 :A person is not deprived of the right of private defence against an act done, " +
                        "or attempted to be done, by a public servant, as such, unless he knows, or has reason " +
                        "to believe, that the person doing the act is such public servant. \n\n" +
                        "Explanation 2: A person is not deprived of the right of private defence against an act done, " +
                        "or attempted to be done, by the direction of a public servant, unless he knows, or has " +
                        "reason to believe, that the person doing the act is acting by such direction, or unless such " +
                        "person states the authority under which he acts, or if he has authority in writing, unless he " +
                        "produces such authority, if deemed. ");
                mydb2.addsection("100 When the right of private defence of the body extends to causing death","GENERAL EXCEPTIONS",4,"The " +
                        "right of private defence of the body extends, under the restrictions mentioned in the last " +
                        "preceding section, to the voluntary causing of death or of any other harm to the assailant, " +
                        "if the offence which occasions the exercise of the right be of any of the descriptions " +
                        "hereinafter enumerated, namely:--\n\n" +
                        "First: Such an assault as may reasonably cause the apprehension that death will " +
                        "otherwise be the consequence of such assault;\n\n" +
                        "Secondly : Such an assault as may reasonably cause the apprehension that grievous hurt " +
                        "will otherwise be the consequence of such assault;\n\n" +
                        "Thirdly: An assault with the intention of committing rape;\n\n" +
                        "Fourthly: An assault with the intention of gratifying unnatural lust.\n\n" +
                        "Fifthly: An assault with the intention of kidnapping or abduction.\n\n" +
                        "Sixthly: An assault with the intention of wrongfully confining a person, under " +
                        "circumstances which may reasonably cause him to apprehend that he will be unable to " +
                        "have recourse to the public authorities for his release. ");
                mydb2.addsection("101 When such right extends to causing any harm other than death","GENERAL EXCEPTIONS",4," If the offence " +
                        "be not of any of the descriptions enumerated in the last preceding section, the right of " +
                        "private defence of the body dose not extend to the voluntary causing of death to the " +
                        "assailant, but dose extend, under the restrictions mentioned in Section 99 to the voluntary " +
                        "causing to the assailant of any harm other than death. ");
                mydb2.addsection("102 Commencement and continuance of the right of private defence of the body","GENERAL EXCEPTIONS",4,"The right of private defence of the body commences as soon as a reasonable " +
                        "apprehension .of danger to the body arises from an attempt or threat to commit the " +
                        "offence though the offence may not have been committed; and it continues as long as " +
                        "Such apprehension of danger to the body continues.");
                mydb2.addsection("103 When the right of private defence of property extends to causing death","GENERAL EXCEPTIONS",4,": The " +
                        "right of private defence of property extends, under the restrictions mentioned in Section " +
                        "99, to the voluntary Causing of death or of any other harm to the wrong-doer, if the " +
                        "offence, the committing of which, or the attempting to commit which, occasions the " +
                        "exercise of the right, be an offence of any of the descriptions hereinafter enumerated, " +
                        "namely:- . \n\n" +
                        "First: Robbery;\n\n" +
                        "Secondly : House-breaking by night;\n\n" +
                        "Thirdly : Mischief by fire committed on any building, tent or vessel, which building, tent or " +
                        "vessel is used as a human dwelling or as a place for the custody of property;\n\n" +
                        "Fourthly : Theft, mischief or house-trespass, under such circumstances as may " +
                        "reasonably cause apprehension that death or grievous hurt will be the consequence, if " +
                        "such right of private defence is not exercised. \n");
                mydb2.addsection("104 When such right extends to causing any harm other than death","GENERAL EXCEPTIONS",4,"If the offence, " +
                        "the committing of which, or the attempting to commit which, occasions the exercise of the " +
                        "right of private defence, be theft, mischief or criminal trespass, not of any of the " +
                        "descriptions enumerated in the last preceding section that right dose not extend, to the " +
                        "voluntary causing of death, but dose extend, subject to the restrictions mentioned " +
                        "in Section 99, to the voluntary causing to the wrong-doer of any harm other than death. ");
                mydb2.addsection("105 Commencement and continuance of the right of private defence of property","GENERAL EXCEPTIONS",4,"The right of private defence of property commences when a reasonable apprehension of " +
                        "danger to the property commences.\n\n" +
                        "The right of private defence of property against theft continues tilt the offender has " +
                        "effected his retreat with the property or either the assistance of the public authorities is " +
                        "obtained, or the property has been recovered.\n\n" +
                        "The right of private defence of property against robbery Continues as long as the offender " +
                        "causes or attempts to cause to any person death or hurt or wrongful restraint or as long as " +
                        "the fear of instant death or of instant-hurt or of instant personal restraint continues. \n\n" +
                        "The right of private defence of property against criminal trespass or mischief continues as " +
                        "long as the offender continues in the commission of criminal trespass or mischief.\n\n" +
                        "The right of private defence of property against house breaking by night continues as long " +
                        "as the house-trespass which has been begun by such house-breaking continues. ");
                mydb2.addsection("106 Right of private defence against deadly assault when there is risk of harm to " +
                        "innocent person","GENERAL EXCEPTIONS",4,"If in the exercise of the right of private defence against an assault " +
                        "which reasonably causes the apprehension of death, the defender be so situated that he " +
                        "cannot effectually exercise that right without risk of harm to an innocent person, his right of " +
                        "private defence extends to the running of that risk.\n\n" +
                        "Illustration\n\n" +
                        "A is attacked by a mob who attempt to murder him. He can not effectually exercise his " +
                        "right of private defence with out firing on the mob, and he cannot fire without risk of  " +
                        "harming young children who are mingled with the mob. A commits no offence if by so " +
                        "firing he harms any of the children. ");

                //chapter 5
                mydb2.addchapters("ABETMENT","15","CHAPTER V");

                mydb2.addsection("107 Abetment of a thing","ABETMENT",5,"A person abets the doing of a thing, who:\n\n" +
                        "First: Instigates any person to do that thing; or\n\n" +
                        "Secondly: Engages with one or more other person or, persons in any conspiracy for the " +
                        "doing of that thing, if an act or illegal omission takes place in pursuance of that conspiracy, " +
                        "And in order to the doing of that thing; or\n\n" +
                        "Thirdly : Intentionally aids, by any act or illegal omission, the doing of that thing. .\n\n " +
                        "Explanation 1 : A person who, by wilful misrepresentation, or by wilful concealment of a " +
                        "material fact which he is bound to disclose, voluntarily causes or procures, or attempts to " +
                        "cause or procures a thing to be done, is said to instigate the doing of that thing.\n\n" +
                        "Illustration\n\n" +
                        "A, a public officer, is authorized by a warrant from a Court of Justice to apprehend Z, B, " +
                        "knowing that fact and also that C is not Z, wilfully presents to A that C is Z, and thereby " +
                        "intentionally cause A to apprehend C. Here B abets by instigation the apprehension of C.\n\n " +
                        "Explanation 2 : Whoever, either prior to or at the time of commission of an act, does " +
                        "anything in order to facilitate the commission of that act, and thereby facilitates the' " +
                        "commission thereof, is said to aid the doing of that act. ");
                mydb2.addsection("108 Abettor","ABETMENT",5,"A person abets an offence, who abets either the commission of an offence, " +
                        "or the commission of an act which would be an offence, if committed by a person capable " +
                        "by law of committing an offence with the same Intention or knowledge as that of the " +
                        "abettor.\n\n" +
                        "Explanation 1 : The abetment of the illegal omission-of an act may amount to an offence " +
                        "although the abettor may not himself be bound to do that act. \n\n" +
                        "Explanation 2 : To constitute the offence of abetment it is not necessary that the act " +
                        "abetted should be committed, or that the effect requisite to constitute the offence should " +
                        "be caused.\n\n" +
                        "Illustrations\n\n" +
                        "(a) A instigates 8 to murder C, B refuses to do so. A is guilty of abetting B to commit " +
                        "murder. \n\n" +
                        "(b) A instigates B to murder D. B in pursuance of the instigation stabs D. D recovers from " +
                        "the wound. A is guilty of instigating B to commit murder.\n\n" +
                        "Explanations 3: It is not necessary that the person abetted should be capable by law of " +
                        "committing an offence, or that he should have the same guilty intention or knowledge as " +
                        "that of the abettor or any guilty intention or knowledge.\n\n" +
                        "Illustration\n\n" +
                        "(a) A, with a guilty intention, abets a child or a lunatic to commit an act which would be an " +
                        "offence, if committed by a person capable by law of committing an offence, and having the " +
                        "same intention as A. Here A whether the act be committed or not, is guilty of abetting an " +
                        "offence.\n\n" +
                        "(b) A, with the intention of murdering Z, instigates B, a child under seven years of age, to " +
                        "do an act which causes Z's death. B, in consequence of the abetment, does the act in the " +
                        "absence of A and thereby, cause Z's death. Here, though B was not capable by law of " +
                        "committing an offence, A is liable to be punished in the same manner as if B had been " +
                        "capable by law of committing ah offence, and had committed murder, and he is therefore " +
                        "subject to the punishment of death.\n\n" +
                        "(c) A instigates B to set fire to a dwelling-house, B, in consequence of the unsoundness of " +
                        "his mind, being incapable of knowing the nature of the act, or that he is doing what is " +
                        "wrong or contrary to law, sets fire to the house in consequence of As instigation. B has " +
                        "committed no offence, but A is guilty, of abetting the offence of setting fire to a dwelling " +
                        "house, and is liable to the punishment provided for that offence.\n\n" +
                        "(d) A intending to cause a theft to be committed, instigates B to take property belonging to " +
                        "Z out of Z's possession. A includes B to believe that the property belongs to A. B takes the " +
                        "property out of Z's possession in good faith, believing it to be A's property. B, acting under " +
                        "this misconception, does not take dishonestly, and therefore does not commit theft. But is " +
                        "guilty of abetting theft, and is liable to the same punishment as if B had committed theft.\n\n" +
                        "Explanation 4: The abetment of an offence being an offence, the abetment of such an " +
                        "abetment is also an offence.\n\n" +
                        "Illustration\n\n" +
                        "A instigates B to instigate C to murder Z. B accordingly instigates C to murder Z, and " +
                        "commits that offence in consequence of B's instigation. B is liable to be punished for his " +
                        "offence with the punishment for murder; and as A instigated B to commit the offence, A is " +
                        "also liable to the same punishment. \n\n" +
                        "Explanation 5: It is not necessary to the commission of the offence of abetment by " +
                        "conspiracy that the abettor should concert the offence with the person who commits it. It is " +
                        "sufficient if he engages in the conspiracy in pursuance of which the offence is committed.\n\n" +
                        "Illustration \n\n" +
                        "A concerts with B a plan for poisoning-Z. it is agreed that A shall administer the poison. 6 " +
                        "then explains the plan to C mentioning that a third person to administer the poison, but " +
                        "without mentioning A's name. C agrees to procure the poison and procures and delivers it " +
                        "to B for the purpose of its being used in the manner explained. A administer the poison; " +
                        "Z dies in consequence. Here, though A and C have not conspired together, yet C has " +
                        "been engaged in the conspiracy in pursuance of which Z has been murdered. C has, " +
                        "therefore, committed the offence defined in this section and is liable to the punishment for " +
                        "murder.\n\n" +
                        "[108-A. Abetment in Pakistan of offences outside it: A person abets an offence within " +
                        "the meaning of this Code who, in Pakistan, abets the commission of any act without and " +
                        "beyond Pakistan which would constitute an offence committed in Pakistan.]\n\n" +
                        "Illustration\n\n" +
                        "A, in Pakistan, instigates B, a foreigner in Goa, to commit a murder in Goa, A is guilty of " +
                        "abetting murder.\n\n" +
                        "Sec. 108-A added by the Penal Code Amendment Act IV of 1898");
                mydb2.addsection("109. Punishment of abetment if the Act abetted committed In consequence and " +
                        "where no express provision is made for its punishment","ABETMENT",5,"Whoever abets any offence " +
                        "shall, if the act abetted is committed in consequence of the abetment, and no express " +
                        "provision is made by this Code, for the punishment of such abetment, be punished with " +
                        "the punishment provided for the offence:\n\n" +
                        "[Provided that, except in case of Ikrah-i-Tam, the, abettor of an offence referred to in " +
                        "Chapter XVI shall be liable to punishment of ta'zir specified for such offence including " +
                        "death.]\n\n" +
                        "Explanation : An act or offence is said-to be committed in consequence of abetment, when " +
                        "it is committed in consequence of the instigation, or in pursuance of the conspiracy, or " +
                        "with the aid which constitutes the abetment.\n\n" +
                        "Illustration\n\n" +
                        "(a) A offers a bribe to B, a public servant, as a reward for showing A some favour in the " +
                        "exercise of B's official functions. 6 accepts the bribe. A has abetted the offence defined in " +
                        "Section 161,\n\n" +
                        "(b) A instigates B to give false evidence. B, in consequence of the instigation commits that " +
                        "offence. A is guilty of abetting that offence, and is liable to the same punishment as B. \n\n" +
                        "(c) A and B conspire to poison Z. A, in pursuance of the conspiracy, procures the poison " +
                        "and delivers it to B in order that he may administer it to Z. B. in pursuance of the " +
                        "conspiracy, administers the poison to Z in A's absence and thereby causes Z's death. " +
                        "Here B is guilty of murder. A is guilty, of abetting that offence by conspiracy, and is liable " +
                        "to the punishment for murder. \n\n" +
                        "Proviso added by the Criminal Law (Amendment) Act, II of 1997.");
                mydb2.addsection("110. Punishment of abetment if person abetted does act with different intention " +
                        "from that of abettor","ABETMENT",5," Whoever abets the commission of an offence shall, if the person  " +
                        "abetted does the act with a different intention or knowledge from that of the abettor, be  " +
                        "punished with the punishment provided for the offence which would have been committed  " +
                        "if the act had been done with intention or knowledge of the abettor and with no other. ");
                mydb2.addsection("111. Liability of abettor when one act abetted and different act done ","ABETMENT",5,": When an act is  " +
                        "abetted and a different act is done, the abettor is liable for the act done, in the same " +
                        "manner and to the same extent as if he had directly, abetted it: \n\n" +
                        "Proviso: Provided the act done was a probable consequence of the abetment; and was " +
                        "committed under the influence of the instigation, or with the aid or in pursuance of the " +
                        "conspiracy which constituted the abetment. \n\n" +
                        "Illustrations \n" +
                        "(a) A instigates a child to put poison into the food of Z, and gives him poison for that " +
                        "purpose. The child, in consequence of the instigation, by mistake puts the poison into the " +
                        "food of Y, which is by the side of that of Z. Here if the child was acting under the influence " +
                        "of A's instigation, and the act done was under the circumstances a probable consequence " +
                        "of the abetment, A is liable in the same manner and to the same extent as if he had " +
                        "instigated the child to put the poison into the food of. \n\n" +
                        "(b) A instigates B to burn Z's house. B sets fire to the house and at the same time commits " +
                        "theft of property there. A. though guilty of abetting the burning of the house, is not guilty of " +
                        "abetting the theft; for the theft was a distinct act, and not a probable consequence of the " +
                        "burning. \n\n" +
                        "(c) A instigates B and C to break into an inhabited house at midnight for the purpose of " +
                        "robbery and provides them with arms for that purpose, B and C break into the house, and " +
                        "being resisted by Z, one of the inmates, murder Z. Here, if that murder was the probable " +
                        "consequence of the abetment. A is liable to the punishment provided for murder. \n");
                mydb2.addsection("112. Abettor when liable to cumulative punishment for act abetted and for act done","ABETMENT",5,"If the act for which the abetter is liable under the last preceding section is committed in " +
                        "addition to the act abetted, and constitutes a distinct offence, the abettor is liable to " +
                        "punishment for each of the offences. \n\n" +
                        "Illustration \n" +
                        "A instigates B to resist by force a distress made by a public servant, B in consequence, " +
                        "resists that distress. In offering the resistance, B voluntarily causes grievous hurt to the " +
                        "officer executing the distress. As B has committed both the offence of resisting the " +
                        "distress, and the offence of voluntarily causing grievous hurt, B is liable to punishment for " +
                        "both these offences; and: if A knew that B was likely voluntarily to cause grievous hurt " +
                        "in resisting the distress A will also be liable to punishment for each of the offences." );
                mydb2.addsection("113. Liability of abettor for an effect caused by the act abetted different from that " +
                        "intended by the abettor","ABETMENT",5,"When an act is abetted with the intention on the part " +
                        "of the abettor of causing a particular effect and an act for which the abettor is liable in " +
                        "consequence of the abetment, causes a different effect from that intended by the abettor, " +
                        "the abettor is liable for the effect caused, in the same manner and to the same extent as if " +
                        "he had abetted the act with the intention of causing that effect, provided he knew that the " +
                        "act abetted was likely to cause that effect. \n\n" +
                        "Illustration \n" +
                        "A instigates B to cause grievous hurt to Z B, In consequence of the instigation, causes " +
                        "grievous hurt to Z. 2 dies in consequence. Here, if A knew that the grievous hurt abetted " +
                        "was likely to cause death, A is liable to be punished with the punishment provided for " +
                        "murder. ");
                mydb2.addsection("114. Abettor present when offence is committed","ABETMENT",5,"Whenever any person, who if absent " +
                        "would be liable to be punished as an abettor, is present when the act or offence for which " +
                        "he would be punishable in consequence of the abetment is committed, he shall be " +
                        "deemed to have committed such act or offence. ");
                mydb2.addsection("115. Abetment of offence punishable with death or imprisonment for life If offence " +
                        "not committed","ABETMENT",5,"Whoever abets the commission of an offence punishable with death or " +
                        "imprisonment for life, shall, if that offence be not committed in consequence of the " +
                        "abetment, and no express provision is made by this Code for the punishment of such " +
                        "abetment be punished with imprisonment of either description for a term which may " +
                        "extend to seven years, and shall also be liable to fine. \n\n" +
                        "If act causing harm be done in consequence: And if any act for which the abettor is \n\n" +
                        "liable in consequence of the abetment, and which cause hurt to any person, is done, the " +
                        "abettor shall be liable to imprisonment of either description for a term which may extend to " +
                        "fourteen years, and shall also be liable to fine. \n\n" +
                        "Illustration \n" +
                        "A instigates B to murder Z. The offence is not committed. If B had murdered Z, he would " +
                        "have been subject to the punishment of death or transportation for fife. Therefore A is " +
                        "labile to imprisonment for a term which may extend to seven years and also to a tine; and " +
                        "if any hurt be done to Z in consequence of the abetment, he will be liable to imprisonment " +
                        "for a term which may extend to fourteen years, and to fine. ");
                mydb2.addsection("116. Abetment of offence punishable with imprisonment-if offence be not " +
                        "committed","ABETMENT",5,"Whoever abets an offence punishable with imprisonment shall, if that offence " +
                        "be not committed in consequence of the abetment, and no express provision is made by " +
                        "this Code for the punishment of such abetment, be punished with imprisonment of any " +
                        "description provided for that offence for a term which may extend to one-fourth part of the. " +
                        "longest term provided for that offence; or with such fine as is provided for that offence; or " +
                        "with both. If abettor or person abetted be a public servant whose duty it is to prevent offence:" +
                        "And if the abettor or the person abetted is a public servant, whose duty it is, to prevent " +
                        "the commission of such offence, the abettor shall be punished with imprisonment of any " +
                        "description provided for that offence, for a term which may extend to one-half of the " +
                        "longest term provided for that offence, or with such fine as is provided for the offence, or " +
                        "with both. \n\n" +
                        "Illustrations \n" +
                        "(a) A offers a bribe to B, a public servant, as a reward for showing A some favour in the " +
                        "exercise of B's official functions. B refuses to accept the bribe. A is punishable under this " +
                        "section. \n\n" +
                        "(b) A instigates B to give false evidence. Here, if B does hot give false evidence A has " +
                        "nevertheless committed the offence defined in this section, and is punishable accordingly. " +
                        "(c) A, police officer, whose duty it is. To prevent robbery, abets the commission of robbery. " +
                        "Here, though the robbery be not committed, A is liable to one-half of the longest term of " +
                        "imprisonment proved for that offence, and also to fine. \n\n" +
                        "(d) B abets the commission of a robbery by H, a police officer, whose duty it is to prevent " +
                        "that offence. Here though the robbery be not committed, B is liable to one-half of the " +
                        "longest term of imprisonment provided for the offence of robbery, and also to fine. ");
                mydb2.addsection("117. Abetting commission of offence by the public or by more than ten persons","ABETMENT",5,"Whoever abets the commission of an offence by the public generally or by any number or " +
                        "class of persons exceeding ten, shall be punished with imprisonment of either description "+
                        "for a term which may extend to three years, or with fine, or with both. \n\n" +
                        "Illustration \n" +
                        "A affixes in a public place a placard instigating a sect consisting of more than ten " +
                        "members to meet at a certain time and place, for the purpose of attacking the members of " +
                        "an adverse sect, while engaged in a procession. A has committed the offence defined in " +
                        "this section. ");
                mydb2.addsection("118. Concealing design to commit offence punishable with death or " +
                        "Imprisonment for life if offence be committed","ABETMENT",5,"Whoever intending to facilitate or " +
                        "knowing it to be likely that he will thereby facilitate the commission of an offence " +
                        "punishable with death or imprisonment of life, voluntarily conceals by any act or illegal " +
                        "omission, the existence of design to commit such offence or makes any representation " +
                        "which he knows to be false respecting such design, \n\n" +
                        "if offence be not committed :\n Shall, if that offence be committed, be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, or, if " +
                        "the offence be not committed, with imprisonment of either description for a term which " +
                        "may extend to three years; and in either case shall also be liable to fine.\n\n Illustration \n" +
                        "A, knowing that dacoity is about to be committed at B, falsely inform the Magistrate that a " +
                        "dacoity is about to be committed at C, a place in an opposite direction, and thereby " +
                        "misleads the Magistrate with intent to facilitate the commission of the offence. The dacoity " +
                        "is committed at B in pursuance of the design. A is punishable under this section, ");
                mydb2.addsection("119. Public servant concealing design to commit offence which it is his duty to " +
                        "prevent","ABETMENT",5,"Whoever, being a public servant intending to facilitate or knowing it to be likely " +
                        "that he will thereby facilitate the commission of an offence which it is his duty as such " +
                        "public servant to prevent, voluntarily conceals, by any act or illegal omission, the " +
                        "existence of a design to commit such offence, or makes any representation which he " +
                        "knows to be false respecting such design, if offence be committed: shall, if the offence be " +
                        "committed, be punished with imprisonment of any description provided for the offence, for " +
                        "a term which may extend to one half of the longest term of such imprisonment, or with " +
                        "such fine as is provided for that offence, or with both; \n\n" +
                        "if offence be punishable with death, etc:\n or if the offence be punishable with death or " +
                        "imprisonment for life with imprisonment of either description for a term which may " +
                        "extend to ten years; \n\n" +
                        "if offence be not committed :\n or, if the offence be not committed, shall be punished with " +
                        "imprisonment of any description provided for the offence for a term which may extend to " +
                        "one-fourth part of the longest term of such imprisonment or with such fine as is provided " +
                        "for the offence, or with both. \n\n" +
                        "Illustration \n" +
                        "A, an officer of police, being legally bound to give information of all design as to commit " +
                        "robbery, which may come to his knowledge, and knowing that B designs to commit " +
                        "robbery, omits to give such information, with intent to facilitate the commission of that of " +
                        "that offence. Here A has by an illegal omission concealed the existence of 6's design, and " +
                        "is liable to punishment according to the provisions of this section. ");
                mydb2.addsection("120. Concealing design to commit offence punishable with imprisonment","ABETMENT",5,"Whoever, intending to facilitate or knowing it to be likely that he will thereby facilitate " +
                        "the commission of an offence punishable with imprisonment, voluntarily conceals, by any " +
                        "act or illegal omission, the existence of a design to commit such offence, or makes any " +
                        "representation which he knows to be false respecting such design, \n\n" +
                        "if offence be committed; if offence be not committed : \nShall, if the offence be " +
                        "committed, be punished with imprisonment of the description provided for the offence, " +
                        "for a term which may extend to one-fourth, and, if the offence be not committed, to one-eighth, of the longest term of such imprisonment, or with such fine as is provided for the \n" +
                        "offence, or with both. ");
                //chapter 5-A
                mydb2.addchapters("CRIMINAL CONSPIRACY ","2","CHAPTER V-A");
                mydb2.addsection("120-A. Definition of criminal conspiracy","CRIMINAL CONSPIRACY",6,"When two or more persons agree to do, or " +
                        "cause to be done, \n\n" +
                        "(1) an illegal act, or \n" +
                        "(2) an act which is not illegal by illegal means such an agreement is designated a criminal " +
                        "conspiracy: \n" +
                        "Provided that no agreement except an agreement to commit an offence shall amount to a " +
                        "criminal conspiracy unless some act besides the agreement is done by one or more " +
                        "parties to such agreement in pursuance thereof. \n\n" +
                        "Explanation : It is immaterial whether the illegal act is the ultimate object of such " +
                        "agreement, or is merely incidental to that object. ");
                mydb2.addsection("120-B. Punishment of criminal conspiracy","CRIMINAL CONSPIRACY",6,"(1) Who ever is a party to a criminal " +
                        "conspiracy to commit an offence punishable with death, imprisonment for life or rigorous " +
                        "imprisonment for a term of two years or upwards, shall, where no express provision is " +
                        "made in this Code for the punishment of such a conspiracy, be punished in the same " +
                        "manner as if he had abetted such offence. \n\n" +
                        "(2) Whoever is a party to a criminal conspiracy other than a criminal conspiracy to commit " +
                        "an offence punishable as aforesaid shall be punished with imprisonment of either " +
                        "description for a term not exceeding six months, or with fine or with both. \n\n" +
                        "1. Chapter V-A ins. by the Criminal Law (Amdt.) Act, VIII of 1913. ");

                //chapter 6
                mydb2.addchapters("OFFENCES AGAINST THE STATE ","14","CHAPTER VI ");
                mydb2.addsection("121. Waging or attempting to wage war or abetting waging of war against Pakistan","OFFENCES AGAINST THE STATE",7,"Whoever wages war against Pakistan, or attempts to wage such war, or abets the " +
                        "waging of such war, shall be punished with death, or imprisonment for life and shall also " +
                        "be liable to fine. \n\n" +
                        "Illustration \n" +
                        "A joins an insurrection against Pakistan. A has committed the offence defined in this " +
                        "section. ");
                mydb2.addsection("121-A. Conspiracy to commit offences punishable by Section 121","OFFENCES AGAINST THE STATE",7,"Whoever within or " +
                        "without Pakistan conspires to commit any of the offences punishable by Section 121, or to " +
                        "deprive Pakistan of the sovereignty of her territories or of any part thereof, or conspires to " +
                        "overawe, by means of criminal force or the show of criminal force, the Federal Government or any Provincial Government, shall be punished with imprisonment for life, " +
                        "or with imprisonment of either description which may extend to ten years, and shall also " +
                        "be liable to fine. \n\n" +
                        "Explanation: To constitute a conspiracy under this section, it is not necessary that any act " +
                        "or illegal omission shall take place in pursuance thereof. \n\n" +
                        "Section 121-A ins. by the Penal Code (Amendment) Act, XXVII of 1870");
                mydb2.addsection("122. Collecting arms, etc., with intention of waging war against Pakistan","OFFENCES AGAINST THE STATE",7,"Whoever " +
                        "collects men, arms or ammunition or otherwise prepares to wage war with the intention of " +
                        "either waging or being prepared to wage war against Pakistan, shall be punished with " +
                        "imprisonment for life or imprisonment of either description for a term not exceeding ten " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("123. Concealing with intent to facilitate design to wage war","OFFENCES AGAINST THE STATE",7,"Whoever, by any act, or " +
                        "by any illegal omission, conceals the existence of a design to wage war against Pakistan, " +
                        "intending by such concealment to facilitate or knowing it to be likely that such concealment " +
                        "will facilitate the waging of such war, shall be punished with imprisonment of either " +
                        "description for a term which may extend to ten years, and shall also be liable to fine.");
                mydb2.addsection("123-A. Condemnation of the creation of the State, and advocacy of abolition of its " +
                        "sovereignty","OFFENCES AGAINST THE STATE",7,"(1) Whoever, within or without Pakistan, with intent to influence, or knowing " +
                        "it to be likely that he will influence, any person or the whole or any section of the public, in " +
                        "a manner likely to be prejudicial to the safety 2[or ideology] of Pakistan or to endanger the " +
                        "sovereignty of Pakistan in respect of all or any of the territories lying within its borders, " +
                        "shall by words, spoken or written, or by signs or visible representation abuse Pakistan or, " +
                        "condemn the creation of Pakistan by virtue of the partition of India which was effected on " +
                        "the fifteenth day of August, 1947, or. advocate the curtailment or abolition of the " +
                        "sovereignty of Pakistan in respect of all or any of the territories lying within its borders, " +
                        "whether by amalgamation with the territories of neighbouring States or otherwise, shall be " +
                        "punished with rigorous imprisonment which may extend to ten years and shall also be " +
                        "liable to fine. \n\n" +
                        "(2) Notwithstanding anything contained in any other law for the time being in force, when " +
                        "any person is proceeded against under this section, it shall be lawful for any Court before " +
                        "which he may be produced in the course of the investigation or trial, to make such order " +
                        "as it may think fit in respect of his movements, of his association or communication " +
                        "with other persons, and of his activities in regard to dissemination of news, propagation of " +
                        "opinions, until such time as the case is finally decided. \n\n" +
                        "(3) Any Court which is a Court of appeal or of revision in relation to the Court mentioned in " +
                        "sub-section (2) may also make an order under that sub-section. \n\n" +
                        " Sec. 123-A ins. by the Pakistan Penal Code (Amendment) Act, VI of 1950.");
                mydb2.addsection("123-B. Defiling or unauthorisedly removing the National Flag of Pakistan from " +
                        "Government building, etc.","OFFENCES AGAINST THE STATE",7,"Whoever deliberately defile the National Flag of Pakistan, or unauthorisedly removes if from any building, premises, vehicle or other property of " +
                        "Government, shall be punished with imprisonment of either description for a term which " +
                        "may extend to three years, or with fine, or with both. \n\n" +
                        "Section 123-B ins. by the Criminal Law (Second Amendment) Ordinance. XLIII of 1984");
                mydb2.addsection("124. Assaulting President, Governor, etc., with intention to compel or restrain the " +
                        "exercise of any lawful power","OFFENCES AGAINST THE STATE",7,": Whoever, with the intention of including or compelling " +
                        "the President of Pakistan, or the Governor of any Province, to exercise or refrain from " +
                        "exercise in any manner of the lawful powers of the President, or Governor, assaults, or " +
                        "wrongfully restrains, or attempts wrongfully to restrain or overawes, by means of criminal " +
                        "force or the show of criminal force, or attempts so to overawe, the President, or Governor, " +
                        "shall be punished with imprisonment of either description for a term which may " +
                        "extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("124-A. Sedition","OFFENCES AGAINST THE STATE",7,"Whoever by words, either spoken or written, or by signs, or by visible " +
                        "representation, or otherwise, brings or attempts to bring into hatred or contempt, or excites " +
                        "or attempts to excite disaffection towards, the Federal or Provincial Government " +
                        "established by law shall be punished with imprisonment for life to which fine may be " +
                        "added, or with imprisonment which may extend to three years, to which fine may be " +
                        "added, or with fine. \n\n" +
                        "Explanation 1: The expression \".disaffection includes disloyalty and all feelings of-enmity.' \n\n" +
                        "Explanation 2: Comments expressing disapprobation of the measures of the Government " +
                        "with a view to obtain their alteration by lawful means, without exciting or attempting to " +
                        "excite hatred, contempt or disaffection, do not constitute an offence under this section.\n\n " +
                        "Explanation 3 : Comments expressing disapprobation of the administrative or other action " +
                        "of the Government without exciting or attempting to excite hatred, contempt or " +
                        "disaffection, do not constitute an offence under this section. \n\n" +
                        "Section 124-A ins. by the Penal Code (Amendment) Act. XXVIl of 1870.");
                mydb2.addsection("125. Waging war against any Asiatic Power in alliance with Pakistan","OFFENCES AGAINST THE STATE",7,"Whoever " +
                        "wages war against the Government of any Asiatic Power in alliance or at peace with  " +
                        "Pakistan or attempts to wage such war, or abets the\" waging of such war, shall be " +
                        "punished with imprisonment for life to which fine may be added, or with imprisonment of " +
                        "either description for a term which may extend to seven years, to which fine may be " +
                        "added, or with fine. ");
                mydb2.addsection("126. Committing depredation on territories of Power at peace with Pakistan ","OFFENCES AGAINST THE STATE",7,"Whoever commits depredation, or makes preparations to commit depredation, on the " +
                        "territories of any power, in alliance, at a peace with Pakistan, shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "also be liable to tine and forfeiture of any property used or intended to be used in " +
                        "committing such depredation, or acquired by such depredation. ");
                mydb2.addsection("127. Receiving property taken by war or depredation mentioned in Sections 125 " +
                        "and 126","OFFENCES AGAINST THE STATE",7,": Whoever receives any property knowing the same to have been taken in the " +
                        "commission of any of the offences mentioned in Sections 125 and 126, shall be punished " +
                        "with imprisonment of either description for a term which may extend to seven years, and " +
                        "shall also be liable to fine and forfeiture of the property so received.");
                mydb2.addsection("128. Public servant voluntarily allowing prisoner of State or war to escape","OFFENCES AGAINST THE STATE",7,"Whoever, being a public servant and having the custody of any State prisoner or prisoner " +
                        "of war, voluntarily allows such prisoner to escape from any place in which such prisoner is " +
                        "confined, shall be punished with imprisonment for life or imprisonment of either description " +
                        "for a .term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("129. Public servant negligently suffering such prisoner to escape","OFFENCES AGAINST THE STATE",7,"Whoever, being a " +
                        "public servant and having the custody of any State prisoner or prisoner of war negligently " +
                        "suffers such prisoner to escape from any place of confinement in which such prisoner is " +
                        "confined, shall be punished with simple imprisonment for a term which may extend to " +
                        "three years, and shall also be liable to fine. ");
                mydb2.addsection("130. Aiding escape of, rescuing or harbouring such prisoner","OFFENCES AGAINST THE STATE",7,"Whoever, knowingly " +
                        "aids or assists any State prisoner or prisoner of war in escaping from lawful custody, or " +
                        "rescues or attempts to rescue any such prisoner; or harbours or conceals any such " +
                        "prisoner who has escaped from lawful custody, or offers or attempts to offer any " +
                        "resistance to the recapture of such prisoner shall be punished with imprisonment for life, " +
                        "or with imprisonment of either description for a term which may extend to ten years, and " +
                        "shall also he liable to fine. \n\n" +
                        "Explanation: A State prisoner or prisoner of war, who is permitted to be at large on his " +
                        "parole within certain limits in Pakistan, is said to escape from lawful custody if he goes " +
                        "beyond the limits within which he is allowed to be at large. ");
                //chapter 7
                mydb2.addchapters("OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE","10","CHAPTER VII");
                mydb2.addsection("131. Abetting mutiny, or attempting to seduce a soldier, sailor or airman from his " +
                        "duty","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"Whoever abets the committing of mutiny by an officer, soldier, sailor or airman, in " +
                        "the Army, Navy or Air Force of Pakistan, or attempts to seduce any such officer, soldier, " +
                        "sailor, or airman from his allegiance of his duty, shall be punished with imprisonment for " +
                        "life, or with imprisonment of either description for a term which may extend to ten years, " +
                        "and shall also be liable to fine. \n\n" +
                        "Explanation: In this section, the words \"officer\", \"soldier\", \"sailor\" or \"airman\" include any " +
                        "person subject to the Pakistan Army Act, 1952 (XXXIX of 1952), or the Pakistan Navy " +
                        "Ordinance, 1961 (XXXV of 1961), or the Pakistan Air Force Act. 1953 (VI of 1953), as the " +
                        "case may be.  Explanation subs. by the Federal Laws (Revision and Declaration) Ordinance, XXVII of 1981");
                mydb2.addsection("132. Abetment of mutiny, if mutiny is committed in consequence thereof","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"Whoever " +
                        "abets committing of mutiny by an officer, soldier, sailor or airman in the Army, Navy or Air " +
                        "Force of Pakistan, shall, if mutiny be committed in consequence of that abetment, be " +
                        "punished with death or with imprisonment for life or imprisonment of either description for " +
                        "a term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("133. Abetment of assault by soldier, sailor or airman on his superior officer, when in " +
                        "execution of his office","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"Whoever abets an assault by an officer, soldier, sailor or airman, " +
                        "in the Army, Navy or Air Force of Pakistan, on any superior officer being in the execution " +
                        "of his office, shall be punished with imprisonment of either description for a term which " +
                        "may extend to three years, and shall also be liable to fine. ");
                mydb2.addsection("134. Abetment of such assault, if the assault is committed","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"Whoever abets an assault " +
                        "by an officer, soldier, sailor or airman, in the Army, Navy or Air Force of Pakistan, on " +
                        "any superior officer being in the execution of his office,, shall, if such assault be committed " +
                        "in consequence .of that abetment be punished with imprisonment of either description for " +
                        "a term which may extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("135. Abetment of desertion of soldier, sailor or airman","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"Whoever abets the desertion " +
                        "of any officer, soldier, sailor or airman, in the Army, Navy or Air Force of Pakistan, be " +
                        "punished with imprisonment of either description for a term which may extend to two " +
                        "years, or with fine, or with both. ");
                mydb2.addsection("136. Harbouring deserter","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,": Whoever, except as hereinafter excepted, knowing or " +
                        "having reason to believe that an officer, soldier, sailor or airman, in the Army, Navy or Air " +
                        "Force of Pakistan, has deserted, harbours such officer, soldier, sailor or airman, shall be " +
                        "punished with imprisonment' of either description for a term which may extend to two " +
                        "years, or with fine, or with both. \n\n" +
                        "Exception : This provision does not extend to the case in which the harbour is given by a " +
                        "wife to her husband. ");
                mydb2.addsection("137. Deserter concealed on board merchant vessel through negligence of master","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"The master or person incharge of a merchant vessel, on board of which any deserter " +
                        "from the Army, Navy or Air Force of Pakistan is concealed, shall, though ignorant of such " +
                        "concealment, be liable to a penalty not exceeding five hundred rupees, if he might have " +
                        "known of such concealment but for some neglect of his duty as such master or person in " +
                        "charge, or but for some want of discipline on board of the vessel.");
                mydb2.addsection("138. Abetment of act of insubordination by soldier, sailor or airman","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"Whoever abets " +
                        "what he knows to be an act of insubordination by an officer, soldier, sailor or airman, in the " +
                        "Army, Navy or Air Force of Pakistan, shall, if such act of insubordination be committed in " +
                        "consequence of that abetment, be punished with imprisonment of either description for a " +
                        "term which may extend to six months, or with fine, or with both. \n\n[138-A. Application of foregoing sections to the Indian Marine Service: [Rep. by the " +
                        "Amending Act, 1934 (XXXIX of 1934 Section 2 and Sched]. ");
                mydb2.addsection("139. Persons subject to certain Acts","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"No person subject to the Pakistan Army Act, 1952 " +
                        "(XXXIX of 1952), the Pakistan Air Force Act, 1953 (VI of 1953), or the Pakistan Navy " +
                        "Ordinance. 1961 (XXXV of 1961), is subject to punishment under this Code for any of the " +
                        "offences defined in this Chapter. \n\n" +
                        "Section 139 subs. by the Federal Laws (Revision and Declaration) to '.Ordinance, XXVII of 1981.");
                mydb2.addsection("140. Wearing garb or carrying token used by soldier, sailor or airman","OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",8,"Whoever, not " +
                        "being a soldier, sailor or airman in the Military, Navel or Air Service of Pakistan, wear, any " +
                        "garb or carries any token resembling any garb or token used by such a soldier, sailor or " +
                        "airman with the intention that it may be believed that he is such a soldier, sailor or airman " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three months, or with fine which may extend to five hundred rupees, or with both. ");
                //chapter 8
                mydb2.addchapters("OFFENCES AGAINST THE PUBLIC TRANQUILLITY","21","CHAPTER VIII");
                mydb2.addsection("141. Unlawful assembly","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"An assembly of five or more persons is designated an \"unlawful " +
                        "assembly\" if the common object of the persons composing that assembly is; \n\n" +
                        "First: To overawe by criminal force, or show of criminal force, the Federal or any Provincial " +
                        "Government or Legislature, or any public servant in the exercise of the lawful power of " +
                        "such public servant; or \n\n" +
                        "\"Second: To resist the execution of any law, or of any legal process, or \n\n" +
                        "Third: To commit any mischief or criminal trespass, or other offence; or \n\n" +
                        "Fourth: By means of criminal force, or show of criminal force, to any person to take or " +
                        "obtain possession of any property, or to deprive any person of the enjoyment of a right of " +
                        "way, or of the use of water or other incorporeal right of which he is in possession or " +
                        "enjoyment, or to enforce any right or supposed right; or \n\n" +
                        "Fifth: By means of criminal force, or show of criminal force, to compel any person to do " +
                        "what he is not legally bound to do, or to omit to do what he is legally entitled to do. " +
                        "Explanation : An assembly which was not unlawful when it assembled, may subsequently " +
                        "become an unlawful assembly. ");
                mydb2.addsection("142. Being member of unlawful assembly","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever being aware of facts which render " +
                        "any assembly an unlawful assembly, intentionally joins that assembly, or continues in it, is " +
                        "said to be a member of any unlawful assembly. ");
                mydb2.addsection("143. Punishment","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever is a member of an unlawful assembly, shall be punished with " +
                        "imprisonment of either description for a term which may extend to six months, or with fine, " +
                        "or with both. ");
                mydb2.addsection("144. Joining unlawful assembly armed with deadly weapon","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9," Whoever, being armed " +
                        "with any deadly weapon, or with anything which, used as a weapon of offence, is likely to " +
                        "cause death, is a member of an unlawful assembly/shall be punished with imprisonment of " +
                        "either description for a term which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("145. Joining or continuing in unlawful assembly, knowing it has been commanded " +
                        "to disperse","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever joins or continues in an unlawful assembly, knowing that such " +
                        "unlawful assembly has been commanded in the manner prescribed by law to disperse, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "two years, or with fine, or with both. ");
                mydb2.addsection("146. Rioting","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whenever force or violence is used by an unlawful assembly, or by any " +
                        "member thereof, in prosecution of the common object of such assembly, every member of " +
                        "such assembly is guilty of the offence of rioting.");
                mydb2.addsection("147. Punishment for rioting","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever is guilty of rioting, shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("148. Rioting, armed with deadly weapon","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever is guilty of rioting, being armed with " +
                        "a deadly weapon or with anything which, used as a weapon of offence, is likely to cause " +
                        "death, shall be punished with imprisonment of either description for a term which may " +
                        "extend to three years, or with fine, or with both. ");
                mydb2.addsection("149. Every member of unlawful assembly guilty of offence committed in " +
                        "prosecution of common object","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"If an offence is committed by any member of an " +
                        "unlawful assembly in prosecution of the common object of that assembly, or such as the " +
                        "members of that assembly knew to be likely to be committed in prosecution of that object, " +
                        "every person who, at the time of the committing of that offence, is a member of the same " +
                        "assembly, is guilty of that offence. ");
                mydb2.addsection("150. Hiring, or conniving at hiring, of persons to join unlawful assembly","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever " +
                        "hires or engages, or employs, or promotes, or connives at the hiring engagement or " +
                        "employment of any person to join or become a member of any unlawful assembly, shall be " +
                        "punishable as a member of such Unlawful assembly, and for any offence which may be " +
                        "committed by any such person as a member of such unlawful assembly in pursuance of " +
                        "such hiring, engagement or employment, in the same manner as if he had been a member " +
                        "of such unlawful assembly, or himself had committed such offence. ");
                mydb2.addsection("151. Knowingly joining or continuing in assembly of five or more persons after it " +
                        "has commanded to disperse","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever knowingly joins or continues in any assembly of five or more persons likely to cause a disturbance of the public peace, after such " +
                        "assembly has been lawfully commanded to disperse, shall be punished with imprisonment " +
                        "of either description for a term which may extend to six months or with fine, or with both. " +
                        "Explanation: If the assembly is an unlawful assembly within the meaning ,of Section 141, " +
                        "the offender will be punished under Section 145. ");
                mydb2.addsection("152. Assaulting to obstructing public servant when suppressing riot, etc.","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever " +
                        "assaults or threatens to assault, or obstructs or attempts to obstruct a public servant in the " +
                        "discharge of his duty as such public servant, in endeavouring to disperse an unlawful " +
                        "assembly, or to suppress a riot or affray, or uses, or threatens, or attempts to use criminal " +
                        "force to such public servant, shall be punished with imprisonment of either description for " +
                        "a term which may extend to three years or with fine, or with both. ");
                mydb2.addsection("153. Wantonly giving provocation with intent to cause riot-if rioting be committed; if " +
                        "not committed","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9," Whoever malignantly, or wantonly, by doing anything which is illegal, " +
                        "lives provocation to any person intending or knowing it to be likely that such provocation " +
                        "will cause the offence of rioting be committed, shall, if the offence of rioting be committed " +
                        "in consequence of such provocation, be punished with imprisonment of either description " +
                        "for a term which may extend to one year, or with fine, or with both; and if the offence " +
                        "if rioting be not committed, with imprisonment of either description for a term which may " +
                        "extend to six months, or with fine, or with both. ");
                mydb2.addsection("[153-A. Promoting enmity between different groups, etc.","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever, " +
                        "(a) by words, either spoken or written, or by signs, or by visible representations or " +
                        "otherwise, promotes or incites, or attempts to promote or incite, on grounds of religion, " +
                        "race, place of both, residence. language, caste or community or any other ground " +
                        "whatsoever, disharmony or feelings of enmity, " +
                        "hatred or ill-will between different religious, racial, language or regional groups or castes " +
                        "or communities; or \n\n" +
                        "(b) commits, or incites any other person to commit, any act which is prejudicial to the " +
                        "maintenance of harmony between different religious, racial, language or regional groups " +
                        "or castes or communities or any group of persons identifiable as such on any ground " +
                        "whatsoever and which disturbs or is likely to disturb public tranquillity; or \n\n" +
                        "(c) organizes, or incites any other person to organize, and exercise, movement, drill or " +
                        "other similar activity intending that the participants in any such activity shall use or be " +
                        "trained to use criminal force or violence or knowing it to be likely that the participants in " +
                        "any such activity will use or be trained to use criminal force or violence or participates, or " +
                        "incites any other person to participate, in any such activity intending to use or be trained to " +
                        "use criminal force or violence or knowing it to be likely that the participants in any such " +
                        "activity will use or be trained, to use criminal force or violence, against any religious, " +
                        "racial, language .or regional group or caste of community or any group of persons " +
                        "identifiable as such on any ground .whatsoever and any such activity for any reason whatsoever cause or is likely to cause fear or alarm or a feeling of insecurity amongst " +
                        "members of such religious, racial, language or regional group or caste or community. " +
                        "shall be punished with imprisonment for a term which may extend to five years and with " +
                        "fine. \n\n" +
                        "Explanation: It does not amount to an offence within the meaning of this section to point " +
                        "but, without malicious intention and with an honest view to their removal, matters which " +
                        "are producing, or have a tendency to produce, feelings of enmity or hatred between " +
                        "different religious, racial, language or regional groups or castes or communities]. \n\n" +
                        "Sec. 153-A subs. by Criminal Law (Amendment) Act, VI of 1973, S. 2.");
                mydb2.addsection("[153-B. Inducing students, etc., take part in political activity","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever by words, " +
                        "either spoken or written, or by signs, or by visible representations, or otherwise, induce or " +
                        "attempts to induce any student, or any class of students, or any institution interested in or " +
                        "connected with students, to take part in any political activity which disturbs or undermines, " +
                        "or is likely disturb or undermine, the public order shall be punished with imprisonment " +
                        "which may extend to two years or –with fine or with both]. \n\n" +
                        "Sec. 153-B subs. by Criminal Law. (Amendment) Act, VI of 1973, S. 2. ");
                mydb2.addsection("154. Owner or occupier of land on which an unlawful assembly is held","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whenever " +
                        "any unlawful assembly or riot takes place, the owner or occupier of the land upon which " +
                        "unlawful assembly is held, or such riot is committed, and any person having or claiming an " +
                        "interest in such land, shall be punishable with fine not exceeding one thousand rupees, if " +
                        "he or his agent or manager, knowing that such offence is being or has been committed, or " +
                        "having reason to believe it is likely to be committed, do not give the earliest notice thereof " +
                        "in his or their power to the principal officer at the nearest police station, and do not, in the " +
                        "case of his or their having reason to believe that it was about to be committed, use all " +
                        "lawful means in his or their power to prevent it and, in the event of its taking place, do not " +
                        "use all lawful means in his or their power to disperse or suppress the riot or unlawful " +
                        "assembly. ");
                mydb2.addsection("155. Liability of person for whose benefit riot is committed","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whenever a riot is " +
                        "committed for the benefit or on behalf of any person who is the owner or occupier of any " +
                        "land respecting which such riot takes place or who claims any interest in such land, or in " +
                        "the subject of any dispute which gave rise to the riot, or who has accepted or derived 'any " +
                        "benefit there from, such person shall be punishable with fine, if he or his agent or " +
                        "manager, having reason to believe that such riot was likely to be committed or that the " +
                        "unlawful assembly by which such riot was committed was likely to be held, shall not " +
                        "respectively use all lawful means in his or their power to prevent such assembly or riot " +
                        "from taking place, and for suppressing and dispersing the same.");
                mydb2.addsection("156. Liability of agent of owner or occupier for whose benefit riot is committed","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whenever a riot is committed for the benefit or on behalf of any person who is the owner " +
                        "or occupier of any land respecting which such riot takes place, or who claims any interest " +
                        "in such land, or in the subject of any dispute which give rise to the riot, or who has accepted or derived any benefit there from, the agent or manager of such person shall be " +
                        "punishable with fine, if such agent or manager, having reason to believe that such riot was " +
                        "likely to be committed or that the Unlawful assembly by which such riot was committed " +
                        "was likely to be held, shall not use all lawful means in his power to prevent such riot or " +
                        "assembly from taking place and for suppressing and dispersing the same. ");
                mydb2.addsection("157. Harbouring persons hired for an unlawful assembly","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever harbours, receives " +
                        "or assembles, in any house or premises in his occupation or charge, or under his control " +
                        "any persons knowing that such persons have been hired, engaged or employed, or are " +
                        "about to be hired, engaged or employed, to join or become members of an unlawful " +
                        "assembly, shall be punished with imprisonment of either description for a term which may " +
                        "extend to six months, or with fine, or with both. ");
                mydb2.addsection("158. Being hired to take part in an unlawful assembly or riot","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever is engaged or " +
                        "hired, or offers or attempts to be hired or engaged, to do or assist in doing any of the acts " +
                        "specified in Section 141, shall be punished with imprisonment of either description for a " +
                        "term which may extend to six months, or with fine, or with both, \n\n" +
                        "or to go armed:\n and whoever, being so engaged or aforesaid, goes armed, or engages or " +
                        "offers to go armed, with any deadly weapon or with anything which used as a weapon " +
                        "of offence is likely to cause death, shall be punished with imprisonment of either " +
                        "description for a term which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("159. Affray","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"When two or more persons, by fighting in a public place, disturb the public " +
                        "peace, they are said to \"commit an affray. ");
                mydb2.addsection("160. Punishment for committing affray","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",9,"Whoever commits an affray, shall be punished " +
                        "with imprisonment of either description for a term which may extend to one month, or with " +
                        "fine which may extend to one hundred rupees, or with both. ");

                //chapter 9
                mydb2.addchapters("OFFENCES BY OR RELATING TO PUBLIC SERVANTS","21","CHAPTER IX");
                mydb2.addsection("161. Public servant taking gratification other than legal remuneration in respect to " +
                        "an official act","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, being or expecting to be a public servant, accepts or obtains, " +
                        "agrees to accept, or attempts to obtain from any person, for himself or for any other " +
                        "person, any gratification whatever, other than legal remuneration, as a motive or reward " +
                        "for doing or forbearing to do any official act or for showing or forbearing to show, in the " +
                        "exercise of his official functions, favour or disfavour to any person, or for rendering or " +
                        "attempting to render any service or disservice to any person, with the Federal, or any " +
                        "Provincial Government or Legislature or with any public servant, as such, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years or with fine or with both.\n\n Explanation : \"Expecting to be a public servant\": If a person not expecting to be in " +
                        "office obtains a gratification by deceiving others into a belief that he is about to be in " +
                        "office, and that he will then serve them, he may be guilty of cheating, but he is not guilty of " +
                        "the offence defined in this section. \n\n" +
                        "\"Gratification\": The word \"gratification\" is not restricted to pecuniary gratifications, or to " +
                        "gratifications estimable in money. \n\n" +
                        "\"Legal remuneration\": The words \"legal remuneration\" are not restricted to " +
                        "remuneration, which a public servant can lawfully demand, but include all remuneration " +
                        "which he is permitted by the authority by which he is employed, to accept. \n\n" +
                        "\"A motive or reward for doing\": A person who receives gratification as a motive for " +
                        "doing what he does not intend to do, or as a reward for doing what he has done, comes " +
                        "within these words. \n\n" +
                        "“Public servant”: In this section and in Sections 162, 63, 164, 165, 166, 167, 168, 169 " +
                        "and 409, 'public servant' includes an employee of any corporation or other body or " +
                        "organisation set up, controlled or administered by, or under the authority of, the Federal \n\n" +
                        "Government. \n\nAdded by the Prevention of Corruption Laws (Amendment) Act, XHI of 1977, S. 2 and Sch. \n\n" +
                        "Illustrations (a) A, a munsif, obtains from Z, a banker, a situation in Z's bank for A's " +
                        "brother, as a reward to A for deciding a case in favour of Z. A has committed the offence " +
                        "defined in this section. \n\n" +
                        "(b) A, holding the office of Consul at the Court of a Foreign Power accepts a lakh of " +
                        "rupees from the Minister of that Power. It does not appear, that A accepted this sum as a " +
                        "motive or reward for doing or forbearing to do any particular official act, or for rendering or " +
                        "attempting to render any particular service to that Power, with the Government of " +
                        "Pakistan. But it does appear that A accepted the sum as a motive or reward for generally " +
                        "showing favour in the exercise of his official functions to that Power. A has committed the " +
                        "offence defined in this section. \n\n" +
                        "(c) A, a public servant, induces Z erroneously to believe that A's influence with the " +
                        "Government has obtained a title for Z and thus induces Z to give A money as a reward for " +
                        "this service. A has committed the offence defined in this section. ");
                mydb2.addsection("162. Taking gratification, in order by corrupt or illegal means to influence public " +
                        "servant","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever accepts or obtains, or agrees to accept, or attempts to obtain from any " +
                        "person, for himself or for. any other person, any gratification whatever as a motive or " +
                        "reward for inducing, by corrupt or illegal means, any public servant to do or to forbear to " +
                        "do any official act, or in the exercise of the official functions of such public servant to show " +
                        "favour or disfavour to any person, or to render or attempt to render any service or " +
                        "disservice to any person with the Federal or any Provincial Government or Legislature, or " +
                        "with any public servant, as such, shall be punished with imprisonment of either description " +
                        "for a term which may extend to three years, or with fine, or with both. ");
                mydb2.addsection("163. Taking gratification, for exercise of personal influence with public servant","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever accepts or obtains or agrees to accept or attempts to obtain, from any person, " +
                        "for himself or for any other person, any gratification whatever, as a motive or reward for " +
                        "inducing, by the exercise of personal influence, any public servant to do or to forbear to do " +
                        "any official act, or in the exercise of the official functions of such public servant to show " +
                        "favour or disfavour to any person, or to render or attempt to render any service or " +
                        "disservice to any person with the Federal or any Provincial Government or Legislature, or " +
                        "with any public servant, as such, shall be punished with simple imprisonment for a term " +
                        "which may extend to one year, or with fine, or with both. \n\n" +
                        "Illustration \n" +
                        "An advocate who receives a fee for arguing a case before a Judge; a person who receives " +
                        "pay for arranging and correcting a memorial addressed to Government, setting forth the " +
                        "service and claims of the memorialist, a paid agent for a condemned criminal, who lays " +
                        "before the Government statements tending to show that the condemnation was unjust, " +
                        "are not within this section, inasmuch as they do not exercise or profess to exercise " +
                        "personal influence. ");
                mydb2.addsection("164. Punishment for abetment by public servant of offences defined in Section 162 " +
                        "or 163","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, being a public Servant, in respect of whom either of the offences " +
                        "defined in the last two preceding sections is committed, abets the offence, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years, or with fine or with both. \n\n" +
                        "Illustration \n" +
                        "A is a public servant. B, A's wife receives a present as a motive for soliciting A to give an " +
                        "office to a particular person. A abets her doing so. B is punishable with imprisonment for a " +
                        "term not exceeding one year, or with fine or with both. A is punishable with imprisonment " +
                        "for a term which may extend to three years, or with fine, or with both. ");
                mydb2.addsection("165. Public servant obtaining valuable thing, without consideration from person " +
                        "concerned in proceeding or business transacted by such public servant","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, " +
                        "being a public servant, accepts or obtains, or agrees to accept or attempts to obtain, for " +
                        "himself, or for any other person, any valuable thing without consideration, or for a " +
                        "consideration which he knows to be inadequate. \n\n" +
                        "\tfrom any person whom he knows to have been, or to be, or to be likely to be " +
                        "concerned in any proceeding or business transacted or about to be transacted by such " +
                        "public servant, or having any connection with the official functions of himself or of any " +
                        "public servant to whom he is subordinate, \n\n" +
                        "or from any person whom he knows to be interested in or related to the person so " +
                        "concerned, \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three years, or with fine, or with both.\n\n Illustration\n" +
                        "(a) A, a Collector, 'hires, a house of 2, who has a settlement case pending before, him. It " +
                        "is agreed that A shall pay fifty rupees a month, then house being; such that, if the bargain " +
                        "were made in good faith, A would be required to pay two hundred rupees a month. A has " +
                        "obtained a valuable thing from Z without adequate consideration. \n\n" +
                        "{b)A, a Judge, buys of Z, who has a case pending in A's Court, Government promissory\u0002notes at a discount, when they are selling in the market at a premium. A has obtained a " +
                        "valuable thing from Z without adequate consideration. \n\n" +
                        "(c) Z's brother is apprehended and taken before A a Magistrate, on a charge of perjury. A " +
                        "sells to Z shares in a bank at a premium, when they are selling in the market at a discount. " +
                        "Z pays A for the shares accordingly. The money so obtained by A is a valuable thing " +
                        "obtained by him without adequate consideration,");
                mydb2.addsection("165-A, Punishment for abetment of offences defined in Sections 161 and 165","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever abets any offence punishable under Section 161 or Section 165 shall, whether " +
                        "the offence abetted is or is not committed in consequence of the abetment, be punished " +
                        "with the punishment provided for the offence. \n\n" +
                        "Sec. 165-A ins. by the Criminal Law (Amendment) Act, XXXVII of 1953 ");
                mydb2.addsection("165-B. Certain abettors excepted","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"A person shall be deemed not to abet an offence " +
                        "punishable under Section 161 or Section 165 if he is induced, compelled, coerced, or " +
                        "intimidated to offer or give any such gratification as is referred to in Section 161 for any of " +
                        "the purposes mentioned therein, or any valuable thing without consideration, or for an " +
                        "inadequate consideration, to any such public servant as is referred to in Section 165. \n\n" +
                        "Sec, 165-B inst. by the Pakistan Penal Code (Amendment) Ordinance, LIX of 1962");
                mydb2.addsection("166. Public servant disobeying law, with intent to cause injury to any person","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, being a public servant, knowingly disobeys any direction of the law as to the " +
                        "way in which he is to conduct himself as such public servant, intending to cause, or " +
                        "knowing it to be likely that he will, by such disobedience, cause injury to any person, shall " +
                        "be punished with simple imprisonment for a term which may extend to one year, or with " +
                        "fine, or with both. \n\n" +
                        "Illustration \n" +
                        "A, being an officer directed by law to take property in execution, in order to satisfy a " +
                        "decree pronounced in Z's favour by a Court of Justice, knowingly disobeys that direction of " +
                        "law, with the knowledge that he is likely thereby to cause injury to Z. A has committed the " +
                        "offence defined in this section. ");
                mydb2.addsection("167. Public servant framing an incorrect document with intent to cause injury","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, being a public servant, and being, as such public servant, charged with the " +
                        "preparation or translation of any document, frames or translates that document in a " +
                        "manner which he knows or believes to be incorrect, intending thereby to cause or knowing " +
                        "it to be likely that he may thereby cause injury to any person, shall be punished with imprisonment of either description for a term which may extend to three years, or With " +
                        "fine, or with both. ");
                mydb2.addsection("168. Public servant unlawfully engaging in trade","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, being a public " +
                        "servant, and being legally bound as such public servant not to engage in trade, engages " +
                        "in trade shall be punished with simple imprisonment for a term which may extend to one " +
                        "year, or with fine, or with both. ");
                mydb2.addsection("169. Public servant unlawfully buying or bidding for property","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, being a " +
                        "public servant, and being legally bound as such public servant, not to purchase or bid for " +
                        "certain property, purchases or bids for that property, either in his own name or in the name " +
                        "of another, or jointly, or in shares with other, shall be punished with simple imprisonment " +
                        "for a term which may extend to two years, or with fine, or with both; and the property, if " +
                        "purchased, shall be confiscated. ");
                mydb2.addsection("170. Personating a public servant","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, pretends to hold any particular office as a " +
                        "public servant, knowing that he does not hold such office or falsely personates any other " +
                        "person holding such office, and in such assumed character does or attempts to do any act " +
                        "under colour of such office, shall be punished with imprisonment of either description, for a " +
                        "term which may extend to two years, or with fine, or with both.");
                mydb2.addsection("171. Wearing garb or carrying token used by public servant with fraudulent intent","OFFENCES AGAINST THE PUBLIC TRANQUILLITY",10,"Whoever, not belonging to a certain class of public servants, wears any garb or carries " +
                        "any token resembling any garb or token used by that class of public servants, with the " +
                        "intention that it may be believed, or with the knowledge that it is likely to be believed, that " +
                        "he belongs to that class of public servants, shall be punished with imprisonment of either " +
                        "description, for a term which may extend to three months, or which may extend to two " +
                        "hundred rupees, or with both. ");
                //chapter 9A
                mydb2.addchapters("OFFENCES RELATING TO ELECTIONS","10","CHAPTER IX-A");
                mydb2.addsection("171-A. \"Candidate\", \"Electoral right\" defined","OFFENCES RELATING TO ELECTIONS",11,": For the purposes of this Chapter: \n\n" +
                        "(a) \"candidate\" means a person who has been nominated as a candidate at any election " +
                        "and includes a person who, when an election is in contemplation, holds himself out as a " +
                        "prospective candidate thereat: provided he is subsequently nominated as a candidate at " +
                        "such election; \n\n" +
                        "(b) \"electoral right\" means the right of a person to stand, or not to stand as, or to " +
                        "withdraw from being, a candidate or to vote or refrain from voting at an election. ");
                mydb2.addsection("171-B. Bribery","OFFENCES RELATING TO ELECTIONS",11,"(1) Whoever \n\n (i) gives a gratification to any person with the object of inducing him or any other person " +
                        "to exercise any electoral right or of rewarding any person for having exercised any such " +
                        "right; or \n\n" +
                        "(ii) accepts either for himself or for any other person any gratification as a reward for " +
                        "exercising any such right, or for .inducing or attempting to induce any other person to " +
                        "exercise any such right, commit the offence of bribery; \n\n" +
                        "\tProvided that a declaration of public policy or a promise of public action shall not be " +
                        "an offence under the section. \n\n" +
                        "(2) A person who offers, or agrees to give, or offers or attempts to procure, a gratification " +
                        "shall be deemed to give a gratification. \n\n" +
                        "(3) A person who obtains or agrees to accept or attempts to obtain a gratification shall be " +
                        "deemed to accept a gratification, and a person who accepts a gratification as a motive for " +
                        "doing what he does not intend to do, or as a reward for doing what he has not done, shall " +
                        "be deemed to have accepted the gratification as a reward. ");
                mydb2.addsection("17I-C. Undue influence at election","OFFENCES RELATING TO ELECTIONS",11,"(1) Whoever voluntarily interferes or attempts to " +
                        "interfere with the free exercise of any electoral right commits the offence of undue " +
                        "influence at an election. \n\n" +
                        "(2) Without prejudice to the generality of the provisions of sub-section (1), whoever; " +
                        "(a) threatens any candidate or voter, or\" any person in whom a candidate or voter is " +
                        "interested, with injury of any kind, or \n\n" +
                        "(b) induces or attempts to induce a candidate or voter to believe that he or any person in " +
                        "whom he is interested will become or will be rendered an object of Divine displeasure or of " +
                        "spiritual censure, \n\n" +
                        "shall be deemed to interfere with the free exercise of the electoral right of such candidate " +
                        "or voter, within the meaning of sub-section (1). \n\n" +
                        "(3) A declaration of public policy or a promise of public action, or the mere exercise of a " +
                        "legal right without intent to interfere with an electoral right, shall not be deemed to be " +
                        "interference within the meaning of this section. ");
                mydb2.addsection("171-D. Personation at elections","OFFENCES RELATING TO ELECTIONS",11,"Whoever at an election applies for a voting paper or " +
                        "votes in the nature of any other person, whether living or dead, or in a fictitious name, or " +
                        "who having voted once at such election applies at the same election for a voting paper in " +
                        "his own name, and whoever abets, procures or attempts to procure the voting by any " +
                        "person in any such way, commits the offence of personation at an election. ");
                mydb2.addsection("171-E. Punishment for bribery","OFFENCES RELATING TO ELECTIONS",11,"Whoever commits the offence of bribery shall be " +
                        "punished with imprisonment of either description for a term-which may extend to one year, " +
                        "or with fine or with both; \n\n" +
                        "Provided that bribery by treating shall be punished with fine only. \n\n" +
                        "Explanation : Treating' means that form of bribery where the gratification consist in food, " +
                        "drink, entertainment, or provision.");
                mydb2.addsection("171-F. Punishment for undue influence or personation at an election","OFFENCES RELATING TO ELECTIONS",11,"Whoever " +
                        "commits the offence of undue influence or personation at an election shall be punished " +
                        "with imprisonment of either description for a term which may extend to one year, or with " +
                        "fine, or with both. ");
                mydb2.addsection("171 -G. False statement in connection with an election","OFFENCES RELATING TO ELECTIONS",11,"Whoever with intent to affect " +
                        "the result of an election makes or publishes any statement purporting to be a statement of " +
                        "fact which is false and which he either knows or believes to be false or does not believe to " +
                        "be true, in relation to the persona! character or conduct of any candidate shall be " +
                        "punished with fine. ");
                mydb2.addsection("171-H. Illegal payments in connection with an election","OFFENCES RELATING TO ELECTIONS",11,": Whoever without the general " +
                        "or special authority in writing of a candidate incurs or authorises expenses on account of " +
                        "the holding of any public meeting, or upon any advertisement, circular or publication, or in " +
                        "any other way whatsoever for the purpose of promoting or procuring the election of such " +
                        "candidate, shall be punished with fine which may extend to five hundred rupees: \n\n" +
                        "Provided that if any person having incurred any such expenses not exceeding the amount " +
                        "of ten rupees without authority obtains within ten days from the date on which such " +
                        "expenses where incurred the approval in writing of the candidate, he shall be deemed to " +
                        "have incurred such expenses with the authority of the candidate. ");
                mydb2.addsection("171-I. Failure to keep election accounts","OFFENCES RELATING TO ELECTIONS",11,"Whoever being required by any law for the " +
                        "time being in force or any rule having the force of law to keep accounts of expenses " +
                        "incurred at or in connection with an election fails to keep such accounts shall be punished " +
                        "with fine which may extend to five hundred rupees. ");
                mydb2.addsection("171- J. Inducing any person not to participate in any election or referendum, etc.","OFFENCES RELATING TO ELECTIONS",11,"Whoever by words, either spoken or written, or by visible representations, induces or " +
                        "directly or indirectly, persuades or instigates, any person not to participate in, or to " +
                        "boycott, any election or referendum, or not to exercise his right of vote thereat, shall be " +
                        "punishable with imprisonment of either description for a term which may extend to three " +
                        "years, or with fine which may extend to five lac rupees, or with both. \n\n" +
                        "Sec. 171-J, inst. by the Criminal Law (Third Amendment) Ordinance LIV of 1984.\n" +
                        "Chapter IX-A ins. by the Election Offence and Inquiries Act. XXXIX of 1920");
                //chapters 10
                mydb2.addchapters("CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS","19","CHAPTER X");
                mydb2.addsection("172. Absconding to avoid service of summons or other proceeding","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever " +
                        "absconds in order to avoid being served with a summons, notice or order proceeding from " +
                        "any public servant legally competent, as such public servant, to issue such -summons, " +
                        "notice or order, shall be punished with simple imprisonment for a term which may extend " +
                        "to one month, or with fine which may extend to five hundred rupees, or with both; \n\n" +
                        "or, if the summons or notice or order is to attend in person or by agent, or to produce a " +
                        "document in a Court of Justice, with simple imprisonment for a term which may extend to " +
                        "six months, or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("173. Preventing service of summons or other proceeding, or preventing publication " +
                        "thereof","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever in any manner intentionally prevents the serving on himself, or on other " +
                        "person, of any summons, notice or order proceeding from any public servant legally " +
                        "competent as such public servant, to issue such summons, notice or order, \n\n" +
                        "or intentionally prevents the lawful affixing to any place of any such summons, notice or " +
                        "order, \n\n" +
                        "or intentionally removes any such summons, notice or order, from any place to which it is " +
                        "lawfully affixed, \n\n" +
                        "or intentionally prevents the lawful making of any proclamation, under .the authority of any " +
                        "public servant legally competent, as such public servant, to direct such proclamation to be " +
                        "made, \n\n" +
                        "shall be punished with simple imprisonment for a term which may extend to one month, or " +
                        "with fine which may extend to five hundred rupees, or with both; \n\n" +
                        "or if the summons, notice, order or proclamation is to attend in person or by agent, or to " +
                        "produce a document in a Court of Justice, with simple imprisonment for a term which may " +
                        "extend to six months, or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("174. Non-attendance in obedience to an order from public servant","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, being " +
                        "legally bound to attend in person or by an agent at a certain place and time in obedience " +
                        "to a summons, notice, order or proclamation proceeding from any public servant legally " +
                        "competent, as such public servant to issue the same, \n\n" +
                        "\tintentionally omits to attend at that place or time, departs from the place where he " +
                        "is bound to attend before the time at which it is lawful for him to depart, shall be punished with simple imprisonment for a term which may extend to one month, or " +
                        "with fine which may extend to five hundred rupees, or with both; \n\n" +
                        "or, if the summons, notice, order or proclamation is to attend in person or by agent in a \n" +
                        "Court of Justice, with simple imprisonment for a term which may extend to six months, or \n" +
                        "with fine which may extend to one thousand rupees, or with both; \n\n" +
                        "or, if the proclamation be under Section 87 of the Code of Criminal Procedure, 1898, with " +
                        "imprisonment which may extend to three years, or with fine, or with both. \n\n" +
                        "Illustrations \n" +
                        "(a) A, being legally bound to appear before the High Court of Sind in obedience to a " +
                        "subpoena issuing from that Court, intentionally omits to appear. A has committed the " +
                        "offence defined in this section. \n\n" +
                        "(b) A, being legally bound to appear before a Zila Judge as a witness in obedience to a " +
                        "summons issued by that Zila Judge, intentionally omits to appear. A has committed the " +
                        "offence defined in this section. ");
                mydb2.addsection("175. Omission to produce document to public servant by person legally bound to " +
                        "produce it","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12," Whoever being legally bound to produce or deliver up any document to any " +
                        "public servant, as such, intentionally omits so to produce or deliver up the same, shall be " +
                        "punished with simple imprisonment for a term which may extend to one month, or with fine " +
                        "which may extend to five hundred rupees, or with both; \n\n" +
                        "or, if the document is to be produced or delivered up to Court of Justice, with simple " +
                        "imprisonment for a term which may extend to six months, or with fine which may extend to " +
                        "one thousand rupees, or with both. \n\n" +
                        "Illustration \n" +
                        "A, being legally bound to produce a document before a Zila Court, intentionally omits to " +
                        "produce the same. A has committed the offence defined in this section. ");
                mydb2.addsection("176. Omission to give notice or information to public servant by person legally " +
                        "bound to give it","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, being legally bound to give any notice or to furnish " +
                        "information on any subject to any public servant, as such, intentionally omits to give such " +
                        "notice or to furnish such information in the manner and at the time required by law, shall " +
                        "be punished with simple imprisonment for a term which may extend to one month, or with " +
                        "fine which may extend to five hundred rupees, or with both; \n\n" +
                        "or, if the notice or information required to be given respects the commission of an offence, " +
                        "or is required for the purpose of preventing the commission of an offence, or in order to " +
                        "the apprehension of an offender, with simple imprisonment for a term which may extend to " +
                        "six months, or with fine which may extend to one thousand rupees or with both; or, if the notice or information required to be given is required by an order passed under " +
                        "sub-section (1) of Section 565 of the Code of Criminal Procedure, 1898 (V of 1898) with " +
                        "imprisonment, of either description for a term which may extend to six months, or with fine " +
                        "which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("177. Furnishing false information","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, being legally bound to furnish information " +
                        "on any subject to any public servant, as such, furnishes, as true, information on the " +
                        "subject which he knows or has reason to believe to be false, shall be punished with simple " +
                        "imprisonment for a term which may extend to six months, or with fine which may extend to " +
                        "one thousand rupees, or with both; \n\n" +
                        "or, if the information which he is legally bound to give respects the commission of an " +
                        "offence, or is required for the purpose of preventing the commission of an offence, or in " +
                        "order to the apprehension of an offender, with imprisonment of either description for a " +
                        "term which may extend to two years, or with fine, or with both. \n\n" +
                        "Illustrations \n" +
                        "(a) A, a landholder, knowing of the commission of a murder within the limits of his estate, " +
                        "wilfully misinforms the Magistrate of the district that the death has occurred by accident in " +
                        "consequence of the bite of a snake. A is guilty of the offence defined in this section. \n\n" +
                        "(b) A, a village watchman, knowing that a considerable body of strangers has passed " +
                        "through his village in order to commit a dacoity in the house of Z a wealthy merchant " +
                        "residing in a neighbouring place, and being bound, under Clause 5, Section Vll, " +
                        "Regulation III, 1821, of the Bengal Code to give early and punctual information of the " +
                        "above fact to the officer, of the nearest police station, wilfully misinforms the police-officer " +
                        "that a body of suspicious characters passed through the village with a view to commit " +
                        "dacoity in a certain distinct place in .a different direction. Here A is guilty of the offence " +
                        "defined in the latter part of this section. \n\n" +
                        "Explanation : In Section 176 and in this section the word \"offence\" includes any act " +
                        "committed at any place out of Pakistan, which, if committed in Pakistan, would be " +
                        "punishable under any of the following sections, namely, 302, 304, 382, 392, 393, 394, " +
                        "395; 396, 397, 398, 399, 402, 435, 436, 449, 450. 457, 458, 459 and 460; and the word " +
                        "\"offender\" includes any person who is alleged to have been guilty of any such act. ");
                mydb2.addsection("178. Refusing oath or affirmation when duly required by public servant t make it","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever refuses to bind himself by an oath or affirmation to state the truth, when required " +
                        "so to bind himself by a public servant legally competent to require that he shall so bind " +
                        "himself, shall be punished with simple imprisonment far a term which may extend to six " +
                        "months, or with tine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("179. Refusing to answer public servant authorised to question","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, being " +
                        "legally bound to state the truth on any subject to any public servant, refuses to answer any " +
                        "question demanded of him touching that subject by such public servant in the exercise of " +
                        "the legal, powers of such public servant shall be punished with simple imprisonment for a term which may extend to six months, or with fine which may extend to one thousand " +
                        "rupees, or with both. ");
                mydb2.addsection("180. Refusing to sign statement","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever refuses to sign any statement made by him, " +
                        "when required to sign that statement by a public servant legally competent to require that " +
                        "he shall sign that statement, shall be punished with simple imprisonment for a term which " +
                        "may extend to six months, or with fine which may extend to five thousand rupees, or with " +
                        "both. ");
                mydb2.addsection("181. False statement on oath or affirmation to public servant or person authorised " +
                        "to administer an oath or affirmation","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, being legally bound by an oath or " +
                        "affirmation to state the truth on any subject to any public servant or other person " +
                        "authorized by law to administer such oath or affirmation, makes, to such public servant or " +
                        "other person as aforesaid, touching that subject any statement which is false, and which " +
                        "he either knows or believes to be false or does not believe to be true, shall be punished " +
                        "with imprisonment of either description for a term which may extend to three years, and " +
                        "shall also be liable to fine. ");
                mydb2.addsection("182. False information with intent to cause public servant to use his lawful power to " +
                        "the injury of another person","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever gives to any public servant any information " +
                        "which he knows or believes to be false, intending thereby to cause, or knowing it to be " +
                        "likely that he will thereby cause, such public servant. \n\n" +
                        "(a) - to do or omit anything which such public servant ought not to do or omit if the true " +
                        "state of facts respecting which such information is given were known by him, or \n\n" +
                        "(b) to use the lawful power of such public servant to the injury or annoyance of any " +
                        "person, \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "six months, or with fine which may extend to one thousand rupees, or with both. \n\n" +
                        "Illustrations \n" +
                        "(a) A informs a Magistrate that Z, a police-officer, subordinate to such Magistrate, has " +
                        "been guilty of neglect of duty or misconduct, knowing such information to be false, and " +
                        "knowing it to be likely that the information will cause the Magistrate to dismiss Z. A has " +
                        "committed the offence defined in this section. \n\n" +
                        "(b) A falsely informs a public servant that Z has contraband salt in a secret place, knowing " +
                        "such information to be false, and knowing that it is likely that the consequence of the " +
                        "information will be a search of premises, attended with annoyance to Z. A has committed " +
                        "the offence defined in this section. \n\n" +
                        "© A falsely informs a policeman that he has been assaulted and robbed in the " +
                        "neighbourhood of a particular village. He does not mention the name of any person as one " +
                        "of his assailants, but knows it to be likely that in consequence of their information the police will make enquiries and institute searches in the village to the annoyance of the " +
                        "villagers or some of them. A has committed an offence under this section.");
                mydb2.addsection("183. Resistance to the taking of property by the lawful authority of a public servant","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever offers any resistance to the taking of any property by the lawful authority of any " +
                        "public servant, knowing or having reason to believe that he is such public servant, shall be " +
                        "punished with imprisonment of either description for a term which may extend to six " +
                        "months, or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("184. Obstructing sale of property offered for sale by authority of public servant","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever intentionally obstructs any sale of property offered for sale by the lawful authority " +
                        "of any public servant, as such, shall be punished with imprisonment of either description " +
                        "for a term which may extend to one month, or with fine which may extend to five hundred " +
                        "rupees, or with both. ");
                mydb2.addsection("185. Illegal purchase or bid for property offered for sale by authority of public " +
                        "servant","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, at any sale of property held by the lawful authority of a public servant, " +
                        "as such, purchases or bids for any property on account of any person, whether himself or " +
                        "\"any other, whom he knows to be under a legal incapacity to purchase that property at that " +
                        "sale, or bids for such property not intending to perform the obligations under which he lays " +
                        "himself by such bidding, shall be punished with imprisonment of either description for a " +
                        "term which may extend to one month, or with fine which may extend to two hundred " +
                        "rupees, or with both.");
                mydb2.addsection("186. Obstructing public servant in discharge of public functions","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever voluntarily " +
                        "obstructs any public servant in the discharge of his public functions, shall be punished with " +
                        "imprisonment of either description for a term which may extend to three months, or With " +
                        "fine which may extend to five hundred rupees, or with both. ");
                mydb2.addsection("187. Omission to assist public servant when bound by law to give assistance","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, being bound by law to render or furnish assistance to any public servant in the " +
                        "execution of his public duty, intentionally omits to give such assistance, shall be punished " +
                        "with simple imprisonment for a term which may extend to one month, or with fine which " +
                        "may extend to two hundred rupees, or with both; \n\n" +
                        "\tand if such assistance, be demanded of him by public servant legally competent to " +
                        "make such demand for the purposes of executing any process lawfully issued by a Court " +
                        "of Justice, or of preventing the commission of an offence, or of suppressing a riot, or " +
                        "affray, or of apprehending a person charged with or guilty of an offence, or of having " +
                        "escaped from lawful custody, shall be punished with simple imprisonment for a term which " +
                        "may extend to six months, or with fine which may extend to five hundred rupees, or with " +
                        "both. ");
                mydb2.addsection("188. Disobedience to order duly promulgated by public servant","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever, knowing " +
                        "that, by an order promulgated by a public servant lawfully empowered to promulgate such order, he is directed to abstain from a certain act, or to take certain order with certain " +
                        "property in his possession or under his management, disobeys such direction, \n\n" +
                        "\t shall, if such disobedience causes or tends to cause obstruction, annoyance or " +
                        "injury or risk of obstruction, annoyance or injury, to any persons lawfully employed, be " +
                        "punished with simple imprisonment for a term which may extend to one month or with fine " +
                        "which may extend to two hundred rupees, or with both; \n\n" +
                        "\tand if such disobedience causes or tends to cause danger to human' life, health or " +
                        "safety, or causes or tends to cause a riot or affray, shall be punished with imprisonment of " +
                        "either description for a term which may extend to six months, or with fine which may " +
                        "extend to one thousand rupees, or with both. \n\n" +
                        "Explanation: It is not necessary that the offender should intend to produce harm, or " +
                        "contemplate his disobedience as likely to produce harm. It is sufficient that he knows of " +
                        "the order which he disobeys, and that his disobedience produces, or is likely to produce " +
                        "harm. \n\n" +
                        "Illustration \n" +
                        "An order is promulgated by a public servant lawfully empowered to promulgate such " +
                        "order, directing that a religious procession shall not pass down a certain street. A, " +
                        "knowingly disobeys the order, and thereby causes danger of riot. A has committed the " +
                        "offence defined in the section. ");
                mydb2.addsection("189. Threat of injury to public servant","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever holds out any threat of injury to any " +
                        "public servant, or to any person in whom he believes that public servant to be interested, " +
                        "for the purpose of inducing that public servant to do any act or to forbear or delay to do " +
                        "any act, connected with the exercise of the public functions of such public servant shall be " +
                        "punished with imprisonment of either description for a term which may extend to two " +
                        "years, or with fine, or with both. ");
                mydb2.addsection("190. Threat of injury to induce person to refrain from applying for protection to " +
                        "public servant","CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",12,"Whoever holds out any threat of injury to any person for the purpose of " +
                        "inducing that person to refrain or desist from making a legal application for protection " +
                        "against any injury to any public servant legally empowered as such to give such " +
                        "protection, or to cause such protection to be given, shall be punished with imprisonment of " +
                        "either description for a term which may extend to one year, or with fine, or with both.");

                //chapter 11
                mydb2.addchapters("FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE","40","CHAPTER XI");
                //yhn sy dalo sections 
                mydb2.addsection("191. Giving false evidence","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever being legally bound by an oath or by an express " +
                        "provision of law to state the truth, or being bound by law to make a declaration upon any " +
                        "subject, makes any statement which is false, and which he either knows or believes to be " +
                        "false or does not believe to be true, is said to give false evidence.\n\nExplanation 1: A statement is within the meaning of this section, whether it is made " +
                        "verbally or otherwise. \n\n" +
                        "Explanation 2: A false statement as to the belief of the person attesting is within the " +
                        "meaning of this section, and a person may be guilty of giving false evidence by stating that " +
                        "he believes a thing which he does not believe, as well as by stating that he knows a thing " +
                        "which he does not know. \n\n" +
                        "Illustrations \n" +
                        "(a) A, in support of a just claim which B has against Z for one thousand rupees, falsely " +
                        "swear on a trial that he heard Z admit the justice of B's claim- A has given false evidence. " +
                        "(b) A, being bound by an oath to state the truth, states that he believes a certain signature " +
                        "to be the handwriting of Z, when he does not believe it to be the handwriting of Z. Here A " +
                        "states that which he knows to be false, and therefore gives false evidence. \n\n" +
                        "(c) A, knowing the general character of Z's handwriting, states that he believes a certain " +
                        "signature to be the handwriting of Z. A in good faith believing it to be so. Here A's " +
                        "statement is merely as to his believe, and is true as to his belief, and therefore although " +
                        "the signature may not be handwriting of Z, A has not given false evidence. \n\n" +
                        "(d) A, being bound by an oath to state the truth, states that he knows that Z was at a " +
                        "particular place on a particular day, not knowing anything upon the subject, A gives false " +
                        "evidence whether Z was at that place on the day named or not. \n\n" +
                        "(e) A, an interpreter or translator, gives or certifies, as a true interpretation or translation of " +
                        "a statement, which he is bound by oath to interpret or translate truly, that which is not and " +
                        "which he does not believe to be a true interpretation or translation. A has given false " +
                        "evidence. ");
                mydb2.addsection("192. Fabricating false evidence","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever causes any circumstance to exist or makes " +
                        "any false entry in any book or record, or makes any document containing a false " +
                        "statement, intending that such circumstance, false entry or false statement may appear in " +
                        "evidence in a judicial proceeding, or in a proceeding taken by law before a public servant " +
                        "as such, or before an arbitrator, and that such circumstance, false entry or false " +
                        "statement, so appearing in evidence, may cause any person who in such proceeding is to " +
                        "form an opinion upon the evidence, to entertain an erroneous opinion touching any point " +
                        "material to the result of such proceeding, is said to fabricate false evidence. \n\n" +
                        "Illustrations \n" +
                        "(a) A puts jewels into a box belonging to Z, with the intention that they may be found in " +
                        "that box, and that this circumstance may cause Z to be convicted of theft. A has " +
                        "fabricated.\n\n(b) A makes a false entry in his shop-book for the purpose of using it as corroborative " +
                        "evidence In a Court of Justice. A has fabricated false evidence. \n\n" +
                        "© A, with the intention of causing Z to be convicted of a criminal conspiracy, writes a .letter " +
                        "in imitation of Z's handwriting, purporting to be addressed to an accomplice in such " +
                        "criminal conspiracy, and puts the letter in a place which he knows that the officers of the " +
                        "Police are likely to search A has fabricated false evidence. ");
                mydb2.addsection("193. Punishment for false evidence","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever intentionally gives false evidence in any " +
                        "stage of a judicial proceeding, or fabricates false evidence for the purpose of being used " +
                        "in any stage of a judicial proceeding, shall be punished with imprisonment of either " +
                        "description for a term, which may extend to seven years, and shall also be liable to fine; \n\n" +
                        "\tand whoever, intentionally gives or fabricates false evidence in any other case, " +
                        "shall, be punished with imprisonment of either description\" for a term which may extend to " +
                        "three years, and shall also be liable to fine. \n\n" +
                        "Explanation 1: A trial before a Court-martial is a judicial proceeding. \n\n" +
                        "Explanation 2: An investigation directed by law preliminary to a proceeding before a Court " +
                        "of Justice, is a stage of a judicial proceeding, though that investigation may not take place " +
                        "before a Court of Justice. \n\n" +
                        "Illustration \n" +
                        "[Omitted by the Federal Laws (Revision and Declaration) \n" +
                        "Ordinance, XXVII of 1981]. \n\n" +
                        "Explanation 3: An investigation directed by a Court of Justice according to law, and " +
                        "conducted under the authority of a Court .of Justice, is a stage of a judicial " +
                        "proceeding/though that investigation may not take place before a Court of Justice. \n\n" +
                        "Illustration \n" +
                        "A, in an enquiry before an officer deputed by a Court of Justice to ascertain on the spot " +
                        "the boundaries of land, makes on oath a statement which he knows to be false. As this " +
                        "enquiry is a stage of a judicial proceeding, A has given false evidence. ");
                mydb2.addsection("194. Giving or fabricating false evidence with intent to procure conviction of capital " +
                        "offence","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever gives or fabricates false evidence, intending thereby to cause, or " +
                        "knowing it to be likely that he will thereby cause any person to be convicted on an offence " +
                        "which is capital by any law for the time being in force, shall be punished with imprisonment " +
                        "for life, or with rigorous imprisonment for a term which may extend to ten years, and shall " +
                        "also be liable to fine; \n\n" +
                        "if innocent person be thereby convicted and executed : and if an innocent person be " +
                        "convicted and executed in consequence of such false evidence the person who gives such false evidence shall be punished either with death or the punishment hereinbefore " +
                        "described. ");
                mydb2.addsection("195. Giving or fabricating false evidence with intent to procure conviction of offence " +
                        "punishable with imprisonment for life or for a term of seven years or upwards","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever gives or fabricates false evidence intending thereby to cause, or knowing it to be " +
                        "likely that he will thereby cause any person to be convicted of an offence which by any taw " +
                        "for the time being in force is not capital, but punishable with imprisonment for life, or " +
                        "imprisonment for a term of seven years or upwards, shall be punished as a person " +
                        "convicted of that offence would be liable to be punished. \n\n" +
                        "Illustration \n" +
                        "A gives false evidence before a Court of Justice, intending thereby to cause Z to be " +
                        "convicted of a dacoity. The punishment of dacoity is imprisonment for life or rigorous " +
                        "imprisonment for a term, which may extend to ten years, with or without tine. A, therefore, " +
                        "is liable to such imprisonment for life or imprisonment with or without fine. ");
                mydb2.addsection("196. Using evidence known to be false","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever corruptly uses or attempts to use as " +
                        "true or genuine evidence, any evidence which he knows to be false or fabricated, shall be " +
                        "punished in the same manner as if he gave or fabricated false evidence. ");
                mydb2.addsection("197. Issuing or signing false certificate","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever issues or signs any certificate " +
                        "required by law to be given or signed, or relating to any fact of which such certificate is by " +
                        "law admissible in evidence, knowing or believing that such certificate is false in any " +
                        "material point, shall be punished in the same manner as if he gave false evidence. ");
                mydb2.addsection("198. Using as true a certificate known to be false","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever corruptly uses or attempts " +
                        "to use any such certificate as a true certificate, knowing the same to be false in any " +
                        "material point, shall be punished in the same manner as if he gave false evidence.");
                mydb2.addsection("199. False statement made in declaration which is by law receivable as evidence","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, in any declaration made or subscribed by him, which declaration any Court of " +
                        "Justice, or any public servant or other person, is bound or authorized by law to receive as " +
                        "evidence of any fact, makes any statement which is false, and which he either knows or " +
                        "believes to be false or does not believe to be true, touching any point material to the " +
                        "object-for which the declaration is made or used, shall be punished in the same manner " +
                        "as if he gave false evidence. ");
                mydb2.addsection("200. Using as true such declaration knowing it to be false","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever corruptly uses or " +
                        "attempts to use as true any such declaration, knowing the same to be false in any material " +
                        "point, shall be punished in the same manner as if he gave false evidence. \n\n" +
                        "Explanation: A declaration, which is inadmissible merely upon the ground of some " +
                        "informality, is a declaration within the meaning of Sections 199 and 200.");
                mydb2.addsection("201. Causing disappearance of evidence of offence, or giving false information to " +
                        "screen offender","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, knowing or having reason to believe that an offence has been " +
                        "committed, causes any evidence of the commission of that offence to disappear, with the " +
                        "intention of screening the offender from legal punishment, or with that intention gives any " +
                        "information respecting the offence which he knows or believes to be false; \n\n" +
                        "if a capital offence: shall, if the offence which he knows or believes to have been " +
                        "committed is punishable with death, be punished with imprisonment of either description " +
                        "for a term which may extend to seven years, and shall also be liable to fine; \n\n" +
                        "if punishable with imprisonment for life: and if the offence is punishable with. " +
                        "imprisonment for fife, or with imprisonment which may extend to ten years shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years, and shall also be liable to fine: \n\n" +
                        " if punishable with less than ten years' imprisonment: and if the offence is " +
                        "punishable with imprisonment for any term not extending to ten years, shall be punished " +
                        "with imprisonment of the description provided for the offence, for a term which may extend " +
                        "to one-fourth part of the longer term of the imprisonment provided for the offence, or with " +
                        "tine, or with both, \n\n" +
                        "Illustration \n" +
                        "A, knowing that B has murdered Z, assists B to hide the body with the intention of " +
                        "screening 6 from punishment. A is liable to imprisonment of either description for seven " +
                        "years, and also to fine. ");
                mydb2.addsection("202. Intentional omission to give information of offence by person bound to inform","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, knowing or having reason to believe that an offence has been committed, " +
                        "intentionally omits to give any information respecting that offence which, he is legally " +
                        "bound to give, shall be punished with imprisonment of either description for a term which " +
                        "may extend to six months, or with fine, or with both. ");
                mydb2.addsection("203. Giving false information respecting an offence committed","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, knowing or " +
                        "having reason to believe that an offence has been committed, gives any information " +
                        "respecting that offence which he knows or believes to be false shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both. \n\n" +
                        "Explanation: In Sections 201 and 202 in this section the word \"offence\" includes any act " +
                        "committed at any place out of Pakistan, which, if committed in Pakistan, would be " +
                        "punishable under any of the following sections, namely, 302, 304, 382, 392, 393, 394, " +
                        "395, 396, 397, 398, 399, 402, 435, 436, 449, 450, 457, 458, 459, and 460. ");
                mydb2.addsection("204. Destruction of document to prevent its production as evidence","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever " +
                        "Secrets or destroys any document which he may be lawfully compelled to produce as " +
                        "evidence in a Court of Justice, or in any proceeding lawfully held before a public servant, as such, or obliterates or renders illegible the whole or any part of such document with the " +
                        "intention of preventing the same from being produced or used as evidence before such " +
                        "Court, or public servant as aforesaid, or after he shall have been lawfully summoned or " +
                        "required to produce the same for that purpose, shall be punished with imprisonment of " +
                        "either description for a term which may extend to two years or with fine, or with both. ");
                mydb2.addsection("205. False personation for purpose of act or proceeding in suit or prosecution","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever falsely personates another, and in such assumed character makes any " +
                        "admission or statement, or confesses judgment, or causes any process to be issued or " +
                        "becomes bail or security, or does any other act in any suit or criminal prosecution, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years or with fine, or with both.");
                mydb2.addsection("206. Fraudulent removal or concealment of property to prevent its seizure as " +
                        "forfeited or in execution","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever fraudulently removes, conceals, transfers or delivers " +
                        "to any person any property or any interest therein, intending thereby to prevent that " +
                        "property or interest therein from being taken as a forfeiture or in satisfaction of a fine, " +
                        "under a sentence which has been pronounced, or which he knows to be likely to be " +
                        "pronounced, by a Court of Justice or other competent authority, or from being taken in " +
                        "execution of a decree or order which has been made, or which he knows to be likely to be " +
                        "made by a Court of Justice in a civil suit, shall be punished with imprisonment of either " +
                        "description for a term which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("207. Fraudulent claim to property to prevent its seizure as forfeited or in execution","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever fraudulently accepts, receives or claims any property or any interest therein, " +
                        "knowing that he has no right or rightful claim to such property or interest, or practises any " +
                        "deception touching any right to any property or any interest therein, intending thereby to " +
                        "prevent that property or interest therein from being taken as a forfeiture or in satisfaction " +
                        "of a fine, under a sentence which has been pronounced, or which he knows to be likely to " +
                        "be pronounced by a Court of Justice or other competent authority, or from being taken in " +
                        "execution of a decree or order which has been made, or which he knows to be likely to be " +
                        "made by a Court of Justice in a civil suit, shall be punished with imprisonment of either " +
                        "description for a term which' may extend to two years, or with fine, or with both. ");
                mydb2.addsection("208. Fraudulently suffering decree for sum not due","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever fraudulently causes or " +
                        "suffers a decree or order to be passed against him at the suit of any person for a sum not " +
                        "due, or for a larger sum than is due to such person or for any property or interest in " +
                        "property to which such person is not entitled, or fraudulently causes or suffers a decree or " +
                        "order to be executed against him after it has been satisfied, or for anything in respect of " +
                        "which it has been satisfied, shall be' punished with imprisonment of either description for a " +
                        "term which may extend to two years, or with fine, or with both. \n\n" +
                        "Illustration \n" +
                        "A institutes a suit against Z. Z, knowing that A is likely to obtain a decree against him " +
                        "fraudulently suffers a judgment to pass against him for a larger amount at the Suit of B, " +
                        "who has no just claim against him, in order that B, either on his own account or for the benefit of Z, may share in the proceeds of any sale of Z's property which may be made " +
                        "under A's decree. Z has committed an offence under this section. ");
                mydb2.addsection("209. Dishonestly making false claim in Court","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever fraudulently or " +
                        "dishonestly, or with intent to injure any person, makes in a Court of Justice any claim " +
                        "which he knows to be false, shall be punished with imprisonment of either description for a " +
                        "term which may extend to two years, and shall also be liable to fine. ");
                mydb2.addsection("210. Fraudulently obtaining decree for sum not due","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever fraudulently obtains a " +
                        "decree or order against any person for a sum not due, or for a larger sum than is due, or " +
                        "for any property or interest in property to which he is not entitled, or fraudulently causes a " +
                        "decree or order to be executed against any person after it has been satisfied or for " +
                        "anything in respect of which it has been satisfied, or fraudulently, suffers or permits any " +
                        "such act to be done in his name, shall be punished with imprisonment of either description " +
                        "for a term which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("211. False charge of offence made with intent to injure","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever with intent to cause " +
                        "injury to any person, institutes or causes to be instituted any criminal proceeding against " +
                        "that person, or falsely charges any person with having committed as offence, knowing that " +
                        "there is no just or lawful ground for such proceeding or charge against that person, shall " +
                        "be punished with imprisonment of either description for a term which may extend to two " +
                        "years, or with fine, or with both, \n\n" +
                        "\t\tand if such criminal proceeding be instituted on a false charge of an offence " +
                        "punishable with death, imprisonment for life or imprisonment for seven years or upwards, " +
                        "shall be punishable with imprisonment of either description for a term which may extend to " +
                        "seven years, and shall also be liable to fine. ");
                mydb2.addsection("212. Harbouring offender","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whenever an offence has been committed, whoever " +
                        "harbours or conceals a person whom he knows or has reason to believe to be the " +
                        "offender, with the intention of screening him from legal punishment, \n\n" +
                        "if a capital offence: shall, if the offence is punishable with death, be punished with " +
                        "imprisonment of either description for a term which may extend to five years, and shall " +
                        "also be liable to fine, \n\n" +
                        "If punishable with imprisonment for life, or with imprisonment: and if the offence is " +
                        "punishable with imprisonment for life or with imprisonment which may extend to ten years, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three years, and shall also be liable to fine, \n\n" +
                        "\tand if the offence is punishable with imprisonment which may extend to one year, " +
                        "and not to ten years, shall be punished with imprisonment of the description provided for " +
                        "the offence for a term which may extend to one-fourth part of the longest term of " +
                        "imprisonment provided for the offence, or with fine, or with both.\n\n \"Offence\" in this section includes, any act committed at any place out of Pakistan, " +
                        "which, if committed in Pakistan, would be punishable under any of the following sections, " +
                        "namely 302, 304, 382, 392, 393, 394, 395, 396, 397, 398, 399. 402, 435, 436, 449, 450, " +
                        "457, 458, 459, and 460 and every such act shall, for the purposes of this section, be " +
                        "deemed to be punishable as if the accused person had been guilty of it in Pakistan. \n\n" +
                        "Exception: This provision shall not extend to any case in which the harbour or " +
                        "concealment is by the husband or wife of the offender. \n\n" +
                        "Illustration \n" +
                        "A knowing that B has committed dacoity, knowingly conceals S in order to screen him " +
                        "legal punishment. Here, as S is liable to imprisonment for life, A is liable to imprisonment " +
                        "of either description for a term not exceeding three years, and is liable to fine. ");
                mydb2.addsection("213. Taking gift, etc., to screen an offender from punishment","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever accepts or " +
                        "attempts to obtain, or agrees to accept, any gratification for himself or any other person, or " +
                        "any restitution of property to himself or any other person, in consideration of his " +
                        "concealing an offence or of his screening any person from legal punishment for any " +
                        "offence, or of his not proceeding against any person for the purpose of bringing him to " +
                        "legal punishment; \n\n" +
                        "if a capital offence: shall, if the offence is punishable with death, be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "also be liable to fine; \n\n" +
                        "if punishable with imprisonment for life, or with imprisonment: and if the offence is " +
                        "punishable with imprisonment for life or with imprisonment which may extend to ten years, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three years, and shall also be liable to fine; \n\n" +
                        "\tand if the offence is punishable with imprisonment not extending to ten years, shall " +
                        "be punished with imprisonment of the description provided for the offence for a term which " +
                        "may extend to one-fourth part of the longest term of imprisonment provided for offence, or " +
                        "with fine, or with both. ");
                mydb2.addsection("214. Offering gift or restoration of property in consideration of screening offender","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever gives or causes or offers or agrees to give or cause, any gratification to any " +
                        "person, or to restore or cause the restoration of any property to any person, in " +
                        "consideration of that person's concealing an offence, or of his screening any person from " +
                        "legal punishment for any offence, or of his not proceeding against any person for the " +
                        "purpose of bringing him to legal punishment; \n\n" +
                        "if a capital offence: shall, if the offence is punishable with death, be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "also be liable to fine;\n\n if punishable with imprisonment for life, or with imprisonment: and if the offence is " +
                        "punishable with imprisonment for life, or with imprisonment which may extend to ten " +
                        "years, shall be punished with imprisonment of either description for a term which may " +
                        "extend to three years, and shall also be liable to fine; \n\n" +
                        "\tand if the offence is punishable with imprisonment not extending to fen years, shall " +
                        "be punished with imprisonment of the description provided for the offence for a term which " +
                        "may extend to one-fourth part of the longest term of imprisonment provided for the " +
                        "offence, or with fine, or with both. \n\n" +
                        "Exception: The provisions of Sections 213 and 214 do not extend to any case in which the " +
                        "offence may lawfully be compounded. \n\n" +
                        "Illustrations \n" +
                        "[Rep. by the Code of Criminal Procedure, X of 1882]. ");
                mydb2.addsection("215. Taking gift to help to recover property, etc.","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever takes or agrees or consents " +
                        "to take any gratification under pretence or on account of helping any person to recover " +
                        "any movable property of which he shall have been deprived by any offence punishable " +
                        "under this Code, shall, unless he uses all means in his power to cause the offender to be " +
                        "apprehended and convicted of the offence, be punished with imprisonment of either " +
                        "description for a term which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("216. Harbouring offender who has escaped from custody or whose apprehension " +
                        "has been ordered","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whenever any person convicted of, or charged with an offence, being " +
                        "in lawful custody for that offence, escapes from such custody, \n\n" +
                        "or whenever a public servant, in the exercise of the lawful powers of such public " +
                        "servant, orders a certain person to be apprehended for an offence, whoever, knowing of " +
                        "such escape or order for apprehension, harbours or conceals that person with the " +
                        "intention of preventing him from being apprehended, shall be punished in the manner " +
                        "following, that is to say; \n\n" +
                        "if a capital offence: if the offence for which the person was in custody or is ordered to be " +
                        "apprehended is punishable with death, he shall be punished with imprisonment of either " +
                        "description for a term which may extend to seven years, and shall also be liable to fine; \n\n" +
                        "if punishable with imprisonment for life, or with imprisonment: if the offence is " +
                        "punishable with imprisonment for life or imprisonment for ten years, he shall be punished " +
                        "with imprisonment of either description for a term which may extend to three years, with or " +
                        "without fine; \n\n" +
                        "\tand if the offence is punishable with imprisonment which may extend to one year " +
                        "and not to ten years, he shall be punished with imprisonment of the description provided " +
                        "for the offence for a term which may extend to one fourth part of the longest term of the " +
                        "imprisonment provided for such offence or with fine, or with both.\n\n \"Offence\" in this section includes also any act or omission of which a person is alleged to " +
                        "have been guilty out of Pakistan which, if he had been guilty of it in Pakistan would have " +
                        "been punishable as an offence, and for which he is under any law relating to extradition, " +
                        "or otherwise, liable to be apprehended or detained in custody in Pakistan, and every such " +
                        "act or omission shall, for the purposes of this section, be deemed to be punishable as if " +
                        "the accused person had been guilty of it in Pakistan. \n\n" +
                        "Exception: This provision does not extend to the case in which the harbour or " +
                        "concealment is by the husband or wife of the person to be apprehended, ");
                mydb2.addsection("216-A. Penalty for harbouring robbers or dacoits","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, knowing or having reason " +
                        "to believe that any persons are about to commit or have recently committed robbery or " +
                        "dacoity, harbours them or any of them, with the intention of facilitating the commission of " +
                        "such robbery or dacoity, or of screening them or any of them from punishment, shall be " +
                        "punished with rigorous imprisonment for a term which may extend to seven years, and " +
                        "shall also be liable to fine. \n\n" +
                        "Explanation: For the- purposes of this Section it is immaterial whether the robbery or " +
                        "dacoity is intended to be committed, or has been committed, within or without Pakistan.\n\n " +
                        "Exception: This provision does not extend to the case in which the harbour is by the " +
                        "husband or wife of the offender. \n\n" +
                        "Sec. 216-A ins. by the Criminal Law (Amendment) Act, 111 of 1894. \n\n" +
                        "216-B. Definition of \"harbour\" in Sections 212, 216and 216-A [Omitted by the Penal Code " +
                        "(Amendment) Act, VIII of 1942, S. 3] ");
                mydb2.addsection("217. Public servant disobeying direction of law with intent to save persons from " +
                        "punishment or property from forfeiture","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, being a public servant, knowingly " +
                        "disobeys any direction of-the taw as to the way in which he is to conduct himself as such " +
                        "public servant, intending thereby to save or knowing it to be likely that he will thereby " +
                        "save, any person from legal punishment, or Subject him to a less punishment than that to " +
                        "which he is liable, or with intent to save, or knowing that he is likely thereby to save, any " +
                        "property from forfeiture or any charge to which it is liable by law, shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both.");
                mydb2.addsection("218. Public servant framing incorrect record or writing with intent to save person " +
                        "from punishment or property from forfeiture","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, being a public servant, and " +
                        "being as such public servant, charged with the preparation of any record or other writing, " +
                        "frames that record 'or writing-in a manner which he knows to be incorrect, with intent to " +
                        "cause, or knowing it to be likely that he will thereby cause, loss or injury to the public or to " +
                        "any person, or with intent thereby to save, or knowing it to be likely that he will thereby " +
                        "save any person from legal punishment, or with intent to save, or knowing that he is likely " +
                        "thereby to save, any property from forfeiture or other charge to which it is liable by law, shall be punished with imprisonment of either description for a term which may extend to " +
                        "three years, or with fine or with both. ");
                mydb2.addsection("219. Public servant in judicial proceeding corruptly making report, etc., contrary to " +
                        "law","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever being a public servant, corruptly or maliciously makes or pronounces in any " +
                        "stage of a judicial proceeding, any report, order, verdict, or decision which he knows to be " +
                        "contrary to law, shall be punished with imprisonment of either description for a term which " +
                        "may extend to seven years, or with fine, or with both. ");
                mydb2.addsection("220. Commitment for trial or confinement by person having authority who knows " +
                        "that he Is acting contrary to law","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, being in any office which gives him legal " +
                        "authority to commit persons for trial or to confinement, or to keep persons in confinement, " +
                        "corruptly or maliciously commits any person for trial or confinement, or keeps any person " +
                        "in confinement, in the exercise of that authority, knowing that in so doing he is acting " +
                        "contrary to law, shall be punished with imprisonment of either description for a term which " +
                        "may extend to seven years, or with fine, or with both. ");
                mydb2.addsection("221. Intentional omission to apprehend on the part of public servant bound to " +
                        "apprehend","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, being a public servant, legally bound as such public servant to " +
                        "apprehend or to keep in confinement any person charged with or liable to be apprehended " +
                        "for an offence, intentionally omits to apprehend such person, or intentionally suffers such " +
                        "person to. escape, or intentionally aids such person in escaping or attempting to escape " +
                        "from such confinement, shall be punished as follows, that is to say-- \n\n" +
                        "with imprisonment of either description for a term which may extend to seven years, " +
                        "with or without fine, if the person in confinement, or who ought to have been apprehended, " +
                        "was charged with or liable to be apprehended for, an offence punishable with death; or \n\n" +
                        "with imprisonment of either description for a term which may extend to three years, " +
                        "with or without fine, if the person in confinement, or who ought to have been apprehended, " +
                        "was charged with, or liable to be apprehended for an offence punishable with " +
                        "imprisonment for life or imprisonment for a term which may extend to ten years; or \n\n" +
                        "with imprisonment of either description for a term which may extend to two years, " +
                        "with or without fine, if the person in confinement, or who ought to have- been " +
                        "apprehended, was charged with, or liable to be apprehended for, an offence punishable " +
                        "with imprisonment for a term less than ten years. ");
                mydb2.addsection("222. Intentional omission to apprehend on the part of public servant bound to " +
                        "apprehend person under sentence or lawfully committed","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, being a public " +
                        "servant, legally bound as such public servant to apprehend or to keep to confinement any " +
                        "person under sentence of a Court of Justice for any offence or lawfully committed to " +
                        "custody, intentionally, omits, to apprehend such person, or intentionally suffers such " +
                        "person to escape or intentionally aids such person in escaping or attempting to escape " +
                        "from such confinement, shall be punished as follows that is to say;\n\n\t with imprisonment for life or with imprisonment of either description for a term which " +
                        "may extend to fourteen years, with or without fine, if the person in confinement, or who " +
                        "ought to have been apprehended, is under sentence of death; or \n\n" +
                        "with imprisonment of either description for a term which may extend to seven years, " +
                        "with or without fine, if the person in confinement, or who ought to have been apprehended " +
                        "is subject by a sentence, of a Court of Justice, or by virtue of a commutation of such " +
                        "sentence, to imprisonment for life or imprisonment for a term of ten years or upwards; or \n\n" +
                        "with imprisonment of either description for a term which may extend to three years, or with " +
                        "fine, or with both, if the person in confinement, or who ought to have been apprehended is " +
                        "subject, by a sentence of a Court of Justice, to imprisonment for a term not extending to " +
                        "ten years or if the person was lawfully committed to custody. ");
                mydb2.addsection("223. Escape from confinement or custody negligently suffered by public servant","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, being a public servant legally bound as such public servant to keep in " +
                        "confinement any person charged with or convicted of any offence or lawfully committed to " +
                        "custody, negligently suffers such persons to escape from confinement, shall be punished " +
                        "with simple imprisonment for a term which may extend to two years, or with fine, or with " +
                        "both. ");
                mydb2.addsection("224. Resistance or obstruction by a person to his lawful apprehension","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever " +
                        "intentionally offers any resistance or illegal obstruction to the lawful apprehension of " +
                        "himself for any offence with which he is charged or of which he has been convicted; or " +
                        "escapes or attempts to escape from any custody in which he is lawfully detained for any " +
                        "such offence, shall be punished with imprisonment of either description for a term which " +
                        "may extend to two years, or with fine, or with both. \n\n" +
                        "Explanation: The punishment in this section is in addition to the punishment for which the " +
                        "person to be apprehended or detained in custody was liable for the offence with which he " +
                        "was charged, or of which he was convicted. ");
                mydb2.addsection("225. Resistance or obstruction to lawful apprehension of another person","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever " +
                        "intentionally offers any resistance or illegal obstruction to the lawful apprehension of any " +
                        "other person for an offence, or rescue or attempts to rescue any other person from any " +
                        "custody in which that person is lawfully detained for an offence, shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both; \n\n" +
                        "or, if the person to be apprehended, or the person rescued or attempted to be " +
                        "rescued, is charged with or liable to be apprehended for an offence punishable with " +
                        "imprisonment for life, or imprisonment for a term which may extend to ten years, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years, and shall also be liable to fine;\n\n\tor, if the person to be apprehended or, rescued, or attempted to be rescued, is " +
                        "charged with or liable to be apprehended for an offence punishable with death, shall be " +
                        "punished with imprisonment of either description for a term which may extend to seven " +
                        "years, and shall also be liable to fine; \n\n" +
                        "or, if. the person to be apprehended or rescued or attempted to be rescued, is " +
                        "liable under the sentence of a Court of Justice, or by virtue of a commutation of such a " +
                        "sentence, to imprisonment for life or imprisonment, for a term of ten years or upwards, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "seven years, and shall also be liable to fine; \n\n" +
                        "or, if the person to be apprehended or rescued, or attempted to be rescued, is " +
                        "under sentence of death, shall be punished with imprisonment for life or imprisonment of " +
                        "either description for a term not exceeding ten years, and shall also be liable to fine. ");
                mydb2.addsection("225-A. Omission to apprehend, or sufferance of escape, on part of public servant, in " +
                        "cases not otherwise provided for","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, being a public servant legally bound as " +
                        "such public servant to apprehend, or to keep in confinement, any person In any case not " +
                        "provided for in Section 221, Section 222 or Section 223, or in any other law for the time " +
                        "being in force, omits to apprehend that person or suffers him to escape from confinement, " +
                        "shall be punished: \n\n" +
                        "(a) if he does so intentionally, with imprisonment of either description for a term which may " +
                        "extend to three years, or with fine or with both; and \n\n" +
                        "(b) if he does so negligently, with simple imprisonment for a term which may extend to two " +
                        "years, or with fine, or with both. \n\n" +
                        "\t\t Section 225-A ins. by the Criminal Law (Amendment) Act, X of 1886. ");
                mydb2.addsection("225-B. Resistance or obstruction to lawful apprehension, or escape or rescue in " +
                        "cases not otherwise provided for","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, in any case not provided for in Section 224 " +
                        "or Section 225 or in any other law for the time being in force, intentionally offers any " +
                        "resistance or illegal obstruction to the lawful apprehension of himself or of any other " +
                        "person, or escapes or attempts to escape from any custody in which he is lawfully " +
                        "detained, or rescues or attempts to rescue any other person from any custody in which " +
                        "that person is lawfully detained, shall be punished with imprisonment of either description " +
                        "for a term which may extend to six months, or with fine, or with both. \n\n" +
                        " Sec. 225-B ins. by the Criminal Law (Amendment) Act, X of 1886. \n\n" +
                        "226. Unlawful return from transportation : [Omitted by the Law Reforms Ordinance, XII of " +
                        "1972, Section 2 and Sched.] ");
                mydb2.addsection("227. Violation of condition of remission of punishment","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, having accepted " +
                        "any conditional remission of punishment, knowingly violates any condition on which such " +
                        "remission was granted/shall be punished with the punishment to which he was originally sentenced, if he has already suffered no part of that punishment, and if he has suffered " +
                        "any part of that punishment, then with so much of that punishment as he has not already " +
                        "suffered. ");
                mydb2.addsection("228. Intentional insult or interruption to public servant sitting in judicial proceeding","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever intentionally offers any insult or causes any interruption to any public servant, " +
                        "while such public servant is sitting in any stage of a judicial proceeding, shall be punished " +
                        "with simple imprisonment for a term which may extend to six months, or with fine which " +
                        "may extend to one thousand rupees, or with both.");
                mydb2.addsection("229. Personation of a Juror or assessor","FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",13,"Whoever, by personation or otherwise, shall " +
                        "intentionally cause, or knowingly suffer himself to be returned, empanelled or sworn as a " +
                        "juryman or assessor in any case in which he knows that he is not entitled by law to be so " +
                        "returned, empanelled or sworn or knowing himself to have been so returned, empanelled " +
                        "or sworn contrary to law, shall voluntarily serve on such jury or as such assessor, shall be " +
                        "punished with imprisonment of either description for a term which may extend to two " +
                        "years, or with fine, or with both. ");
                //chapter 12 id=14
                mydb2.addchapters("OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS","34","CHAPTER XII");

                mydb2.addsection("230. \"Coin\" defined","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14," Coin is metal used for the time being as money, and stamped and " +
                        "issued by the authority of some State or Sovereign Power in order to be so used. " +
                        "“Pakistan coin”: Pakistan coin is metal stamped and issued by the authority of the " +
                        "Government of Pakistan in order to be used as money; and metal which has been so " +
                        "stamped and issued shall continue to be Pakistan coin for the purposes of this Chapter, " +
                        "notwithstanding that it may have ceased to be used as money. \n\n" +
                        "Illustrations \n" +
                        "(a) Cowries are not coin. \n\n" +
                        "(b) Lumps of unstamped copper, though used as money, are not coin. \n\n" +
                        "(c) Medals are not coin, inasmuch as they are not intended to be used as money. \n\n" +
                        "(d) & (e) [Omitted by the federal Laws (Revision and Declaration) " +
                        "Ordinance, XXV// of 1981.] ");
                mydb2.addsection("231. Counterfeiting coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever counterfeits or knowingly performs any part of the " +
                        "process of counterfeiting coin, shall be punished with imprisonment of either description " +
                        "for a term which may extend to seven years, and shall also be liable to fine.\n\nExplanation: A person commits this offence who intending to practise deception, or " +
                        "knowing it to be likely that deception will thereby be practised, causes a genuine coin to " +
                        "appear like a different coin. ");
                mydb2.addsection("232. Counterfeiting Pakistan coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever counterfeits, or knowingly performs any " +
                        "part of the process of counterfeiting Pakistan coin, shall be punished with imprisonment " +
                        "for life, or with imprisonment of either description for a term which may extend to ten " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("233. Making or selling instrument for counterfeiting coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever makes or mends, " +
                        "or performs any part of the process of making or mending, or buys, sells or disposes of, " +
                        "any die or instrument, for the purpose of being used, or knowing or having reason to " +
                        "believe that it is intended to be used, for the purpose of counterfeiting coin, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("234. Making or selling Instrument for counterfeiting Pakistan coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever makes " +
                        "or mends, or performs any part of the process of making or mending or buys, sells or " +
                        "disposes of, any die or instrument, for the purpose of being used, or knowing or having " +
                        "reason to believe that it is intended to be used, for the purpose of counterfeiting Pakistan " +
                        "coin, shall be punished with imprisonment of either description for a term which may " +
                        "extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("235. Possession of instrument or material for the purpose of using the same for " +
                        "counterfeiting coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever is in possession of any instrument or material, for the " +
                        "purpose of using the same for counterfeiting coin, or knowing or having reason to believe " +
                        "that the same is intended to be used for that purpose, shall be punished with " +
                        "imprisonment of either description for a term which may extend to three years, and shall " +
                        "also be liable to fine; \n\n" +
                        "if Pakistan coin: and if the coin to be counterfeited is Pakistan coin, shall be " +
                        "punished with imprisonment of either description for a term which may extend to ten " +
                        "years, and shall also be liable to fine.");
                mydb2.addsection("236. Abetting in Pakistan the counterfeiting out of Pakistan of coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, being " +
                        "within Pakistan, abets the counterfeiting of coin out of Pakistan shall be punished in the " +
                        "same manner as if he abetted the counterfeiting of such coin within Pakistan. ");
                mydb2.addsection("237. Import or export of counterfeit coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever imports into Pakistan, or exports " +
                        "there from, any counterfeit coin, knowingly or having reason to believe that the same is " +
                        "counterfeit, shall be punished with imprisonment of either description for a term which may " +
                        "extend to three years, and shall also be liable to fine. ");
                mydb2.addsection("238. Import or export of counterfeits of Pakistan coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever imports into Pakistan, " +
                        "or exports therefrom, any counterfeit coin which he knows or has reason to believe to be a " +
                        "counterfeit of Pakistan coin, shall be punished with imprisonment for life, or with imprisonment of either description for a term which may extend to ten years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("239. Delivery of coin, possessed with knowledge that it is counterfeit","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, " +
                        "having any counterfeit coin, which at the time when he became possessed of it he knew to " +
                        "be counterfeit, fraudulently or with intent that fraud may be committed, delivers the same " +
                        "to any person, or attempts to induce any. person to receive it, shall be punished with " +
                        "imprisonment of either description for a term which may extend to five years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("240. Delivery of Pakistan coin possessed with knowledge that it is counterfeit","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, having any counterfeit coin, which is a counterfeit of Pakistan coin, and which, " +
                        "at the time when he became possessed of it, he knew to be a counterfeit of Pakistan coin, " +
                        "fraudulently or with intent that fraud may be committed, delivers the same to any person, " +
                        "or attempts to induce any person to receive it, shall be punished with imprisonment of " +
                        "either description for a term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("241. Delivery of coin as genuine, which, when first possessed, the deliverer did not " +
                        "know to be counterfeit","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever delivers to any other person as genuine, or attempts to " +
                        "induce any other person to receive as genuine, any counterfeit coin which he knows to be " +
                        "counterfeit, but which he did not know to be counterfeit, as the time when he took it into " +
                        "his possession, shall be punished with imprisonment of either description for a term which " +
                        "may extend to two years, or with fine to an amount which may extend to ten times the " +
                        "value of the coin counterfeited, or with both. \n\n" +
                        "Illustration \n" +
                        "A, a coiner, delivers counterfeit rupees to his accomplice 8, for the purpose of uttering " +
                        "them. B sells the rupees to C, another utterer, who buys them knowing them to be " +
                        "counterfeit, C pays away the rupees for goods to D. who receives them, not knowing them " +
                        "to be counterfeit. D after receiving the rupees, discovers that they are counterfeit and pays " +
                        "them away as if they were good. Here D is punishable only under this section, but B and C " +
                        "are punishable under Section 239 or 240, as the case may be. ");
                mydb2.addsection("242. Possession of counterfeit coin by person who knew it to be counterfeit when " +
                        "he became possessed thereof","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, fraudulently, or with intent that fraud may be " +
                        "committed, is in possession of counterfeit coin, having known at the time when he became " +
                        "possessed thereof that such coin was counterfeit, shall be punished with imprisonment of " +
                        "either description for a term which may extend to three years, and shall also be liable to " +
                        "fine.");
                mydb2.addsection("243. Possession of Pakistan coin by person who knew It to be counterfeit when he " +
                        "became possessed thereof","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14," Whoever, fraudulently or with intent that fraud may be " +
                        "committed, as in possession of counterfeit coin, which is a counterfeit of Pakistan coin, " +
                        "having known at the time when he became possessed of it that it was counterfeit, shall be " +
                        "Punished with imprisonment of either description for a term, which may extend to seven " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("244. Person employed in mint causing coin to be of different weight or composition " +
                        "from that fixed by law","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, being employed in any mint lawfully established in " +
                        "Pakistan, does any act, or omits what he is legally bound to do, with the intention of " +
                        "causing any coin issued from that mint to be of a different weight or composition from the " +
                        "weight or composition fixed by law, shall be punished with imprisonment of either " +
                        "description for a term which may extend to seven years, and shall also be liable to fine.");
                mydb2.addsection("245. Unlawfully taking coining instrument from mint","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, without lawful " +
                        "authority, takes out of any mint, lawfully established in Pakistan, any coining tool or " +
                        "instrument, shall be punished with imprisonment of either description for a term which may " +
                        "extend to seven years, and shall also be liable to fine.");
                mydb2.addsection("246. Fraudulently or dishonestly diminishing weight or altering composition of coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever fraudulently or dishonestly performs on any coin any operation, which diminishes " +
                        "the weight or alters the composition of that coin, shall be punished with imprisonment of " +
                        "either description for a term, which may extend to three years, and shall also be liable to " +
                        "fine. \n\n" +
                        "Explanation: A person who scoops out part of the coin and puts anything else into the " +
                        "cavity alters the composition of that coin. ");
                mydb2.addsection("247. Fraudulently or dishonestly diminishing weight or altering composition of " +
                        "Pakistan coin","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever fraudulently or dishonestly performs on any Pakistan coin, any " +
                        "operation which diminishes the weight or alters the composition of that coin, shall be " +
                        "punished with imprisonment of either description for a term which may extend to seven " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("248. Altering appearance of coin with intent that it shall pass as coin of different " +
                        "description","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever performs on any coin any operation which alters the appearance of " +
                        "that coin, with the intention that the said coin shall pass as a different description, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("249. Altering appearance of Pakistan coin with intent that it shall pass as coin of " +
                        "different description","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever performs on any Pakistan coin any operation which alters " +
                        "the appearance of that coin, with the intention that the said coin shall pass as a coin of a " +
                        "different description, shall be punished with imprisonment of either description for a term " +
                        "which may extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("250. Delivery of coin, possessed with knowledge that it is altered","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, having " +
                        "coin in his possession with respect to which the offence defined in Section 246 or 248 has " +
                        "been committed, and having known at the time when he became possessed of such coin " +
                        "that such offence had been committed with respect to it, fraudulently or with intent that " +
                        "fraud may be committed, delivers such coin to any other person, or attempts to induce any other person to receive the same, shall be punished with imprisonment of either " +
                        "description for a term which may extend to five years, and shall also be liable to fine. ");
                mydb2.addsection("251. Delivery of Pakistan coin possessed with knowledge that It is altered","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, " +
                        "having coin in his possession with respect to .which the offence defined in Section 247 or " +
                        "249 has been committed, and having known at the time when he became possessed of " +
                        "such coin that such offence had been committed with respect to it, fraudulently or with " +
                        "intent that fraud may be committed, delivers such coin to any other person, or attempts to " +
                        "induce any other person to receive the same, shall be punished with imprisonment of " +
                        "either description for a term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("252. Possession of coin by person who knew it to be altered when he became " +
                        "possessed thereof","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever fraudulently or with intent that fraud may be committed, is " +
                        "in possession of coin with respect to which the offence defined in either of the Section 246 " +
                        "or 248 has been committed, having known at the time of becoming possessed thereof that " +
                        "such offence had been committed with respect to such coin, shall be punished with " +
                        "imprisonment of either description for a term which may extend to three years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("253. Possession of Pakistan coin by person who knew it to by altered when he " +
                        "became possessed thereof","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever fraudulently or with intent that fraud may be " +
                        "committed, is in possession of coin with respect of which the offence, defined in either of " +
                        "Section 247 or 249 has been committed having known at the time of becoming possessed " +
                        "thereof that such offence had been committed with respect to such coin, shall be punished " +
                        "with imprisonment of either description for a term which may extend to five years, and " +
                        "shall also be liable to fine. ");
                mydb2.addsection("254. Delivery of coin as genuine which, when first possessed, the deliverer did not " +
                        "know to be altered","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever delivers to any other person as genuine or as a coin of a " +
                        "different description from what it is, or attempts to induce any person to receive as " +
                        "genuine, or as a different coin from what it is, any coin in respect of which' he knows that " +
                        "any such operation as that mentioned in Sections 246, 247, 248 or 249 has been " +
                        "performed, but in respect of which he did not, at the time when he took it into his " +
                        "possession, know that such operation had been performed, shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine " +
                        "to an amount which may extend to ten times the value of the coin for which the altered " +
                        "coin is passed, or attempted to be passed. ");
                mydb2.addsection("255. Counterfeiting Government stamp","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever counterfeits, or knowingly performs " +
                        "any part of the process of counterfeiting, any stamp issued by Government for the " +
                        "purpose of revenue, shall be punished with imprisonment for life or with imprisonment of " +
                        "either description for a term which may extend to ten years, and shall also be liable to fine.\n\n " +
                        "Explanation: A person commits this offence who counterfeits by causing a genuine stamp " +
                        "of one denomination to appear like a genuine stamp of a different denomination. ");
                mydb2.addsection("256. Having possession of instrument or material for counterfeiting Government " +
                        "stamp","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever has in his possession any instrument or material for the purpose of " +
                        "being used, or knowing or having reason to believe that it is intended to be used, for the " +
                        "purpose of counterfeiting any stamp issued by Government for the purpose of revenue, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "seven years, and shall also be liable to fine. ");
                mydb2.addsection("257. Making or selling instrument for counterfeiting Government stamp","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever " +
                        "makes or performs any part of the process of making, or buys, or sells, or disposes of, any " +
                        "instrument for the purpose of being used, or knowing or having reason to believe that it is " +
                        "intended to be used, for the purpose of counterfeiting any stamp issued by Government " +
                        "for the purpose of revenue, shall be punished with imprisonment of either description for a " +
                        "term which may extend to seven years and shall also be liable to fine. ");
                mydb2.addsection("258. Sale of counterfeit Government stamp","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever sells, or offers for sale, any " +
                        "stamp which he knows or has reason to believe to be a counterfeit of any stamp issued by " +
                        "Government for the purpose of revenue shall be punished with imprisonment of either " +
                        "description for a term which may extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("259. Having possession of counterfeit Government stamp ","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever has in his " +
                        "possession any stamp which he knows to be a counterfeit of any stamp issued by " +
                        "Government for the purpose of revenue, intending to use, or dispose of the same as a " +
                        "genuine stamp, or in order that it may be used as a genuine stamp, shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("260. Using as genuine a Government stamp known to be counterfeit","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever uses " +
                        "as genuine any stamp knowing it to be a counterfeit of any stamp issued by Government " +
                        "for purpose of revenue, shall be punished with imprisonment of either description for a " +
                        "term which may extend to seven years, or with fine, or with both. ");
                mydb2.addsection("261. Effacing writing from substance, Government stamp, or removing from " +
                        "document a stamp used for it, with intent to cause loss to Government","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever " +
                        "fraudulently or with intent to cause loss to the Government, removes or effaces from any " +
                        "substance bearing any stamp issued by Government for the purpose of revenue, any " +
                        "writing or document for which such stamp has been used, or removes from any writing or " +
                        "document a stamp which has been used for such writing or document, in order that such " +
                        "stamp may be used for a different writing or document, shall be punished with " +
                        "imprisonment of either description for a term which may extend to there years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("262. Using Government stamp known to have been before used","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever " +
                        "fraudulently or with intent to cause loss to the Government, uses for any purpose a stamp " +
                        "issued by Government for the purpose of revenue, which he knows to have been before " +
                        "used, shall be punished with imprisonment of either description for a term which may " +
                        "extend to two years, or with fine, or with both. ");
                mydb2.addsection("263. Erasure of mark denoting that has been used","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"Whoever, fraudulently or with intent " +
                        "to cause loss to Government, erases or removes from a stamp issued by Government for " +
                        "the purpose of revenue, any mark, put or impressed upon such stamp for the purpose of " +
                        "denoting that the same has been used, or knowingly has in his possession or sells or " +
                        "disposes of any such stamp from which such mark has been erased or removed, or sells " +
                        "or disposes of any such stamp which he knows to have been used, shall be punished with " +
                        "imprisonment of either description for a term which may extend to three years or with fine, " +
                        "or with both.");
                mydb2.addsection("263-A. Prohibition of fictitious stamp","OFFENCES RELATING TO COIN AND GOVERNMENT STAMPS",14,"(l) Whoever-- " +
                        "(a) makes, knowingly alters, deals in or sells any fictitious stamp, or knowingly uses for " +
                        "any postal purpose any fictitious stamp, or \n\n" +
                        "(b) has in his possession, without lawful excuse, any fictitious stamp, or \n\n" +
                        "(c) makes or, without .lawful excuse, has in his possession any die, plate, instrument or " +
                        "materials for making any. fictitious stamp, shall be punished with fine which may extend to " +
                        "two hundred rupees. \n\n" +
                        "(2) An such stamp, die, plate, instrument or materials in the possession of any person for " +
                        "making any fictitious stamp may be seized and shall be forfeited. \n\n" +
                        "(3) In this section \"fictitious stamp\" means any stamp falsely purporting to be issued by " +
                        "Government for the purpose of denoting a rate of postage or any facsimile or imitation or " +
                        "representation, whether on paper or otherwise, of any stamp issued by Government for " +
                        "that purpose. \n\n" +
                        "(4) In this section and also in Sections 255 to 263, both inclusive, the word \"Government\" " +
                        "when used in connection with, or in reference to, any stamp issued, for the purpose of " +
                        "denoting a rate of postage, shall, notwithstanding anything in Section 17, be deemed to " +
                        "include the person or persons authorised by law to administer executive Government in " +
                        "any part of Pakistan, and also in any foreign country. \n\n" +
                        "Sec. 263-A ins. by the Criminal Law (Amendment) Act, Ill of 1895. ");

                //chapter 12
                mydb2.addchapters("OFFENCES RELATING TO WEIGHTS AND MEASURES","4","CHAPTER XIII");
                mydb2.addsection("264. Fraudulent use of false instrument for weighing","OFFENCES RELATING TO WEIGHTS AND MEASURES",15," Whoever fraudulently uses any " +
                        "instrument for weighing which he knows to be false, shall be punished with imprisonment " +
                        "of either description for a term, which may extend to one year, or with fine, or with both. ");
                mydb2.addsection("265. Fraudulent use of false weight or measure","OFFENCES RELATING TO WEIGHTS AND MEASURES",15," Whoever fraudulently uses any false " +
                        "weight or false measure of length or Capacity, or fraudulently uses any weight or any " +
                        "measure of length or capacity as a different weight or measure from what it is, shall be " +
                        "punished with imprisonment of either description for a term which may extend to one year, " +
                        "or with fine or with both. ");
                mydb2.addsection("266. Being in possession of false weight or measure","OFFENCES RELATING TO WEIGHTS AND MEASURES",15,"Whoever is in possession of any " +
                        "instrument for weighing, or of any weight, or of any measure of length or capacity, which " +
                        "he knows to be false and intending that the same may be fraudulently used, shall be " +
                        "punished with imprisonment of either description for a term which may extend to one year, " +
                        "Or with fine, or with both. ");
                mydb2.addsection("267. Making or selling false weight or measure","OFFENCES RELATING TO WEIGHTS AND MEASURES",15,"Whoever makes, sells or disposes of " +
                        "any instrument for weighing, or any weight, or any measure of length or capacity which he " +
                        "knows to be false, in order that the same may be used as true, or knowing that the same " +
                        "is likely to be used as true shall be punished with imprisonment of either description for a " +
                        "term which may extend to one year, or with fine, or with both. ");
                //chapter 13
                mydb2.addchapters("OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS","29","CHAPTER XIV");

                mydb2.addsection("268. Public nuisance","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"A person is guilty of a public nuisance who does any act or is " +
                        "guilty of an illegal omission which causes any common injury, danger or annoyance to the " +
                        "public or to the people in general who dwell or occupy property in the vicinity, or which " +
                        "must necessarily cause injury, obstruction, danger or annoyance to persons who may " +
                        "have occasion to use any public right. \n\n" +
                        "A common nuisance is not excused on the ground that it causes some convenience or " +
                        "advantage.");
                mydb2.addsection("269. Negligent act likely to spread infection of disease dangerous to life","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever " +
                        "unlawfully or negligently does any act which is, and which he knows or has reason to " +
                        "believe to be, likely to spread the infection of any disease dangerous to life, shall be " +
                        "punished with imprisonment of either description for a term which may extend to six " +
                        "months, or with fine, or with both. ");
                mydb2.addsection("270. Malignant act likely to spread infection of disease dangerous to life","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever " +
                        "malignantly does any act which is, and which he knows or has reason to believe to be, " +
                        "likely to spread the infection of any disease dangerous to life, shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("271. Disobedience to quarantine rule","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever knowingly disobeys any rule made and " +
                        "promulgated by the Federal or any Provincial Government for putting any vessel into a state of quarantine, or for regulating the intercourse of vessels in a state of quarantine with \n" +
                        "the shore or with other vessels, or for regulating the intercourse between places where an " +
                        "infectious disease prevails and other places, shall be punished with imprisonment of either " +
                        "description for a term which may extend to six months, or with fine, or with both. ");
                mydb2.addsection("272. Adulteration of food or drink intended for sale","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16," Whoever adulterates any article of " +
                        "food or drink, so as to make such article noxious as food or drink, intending to sell such " +
                        "article as food or drink, or knowing it to be likely that the same will be sold as food or drink, " +
                        "snail be punished with imprisonment of either description for a term which may extend to " +
                        "six months, or with fine which may extend to one thousand rupees, or with both.");
                mydb2.addsection("273. Sale of noxious food or drink","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever sells, or offers or exposes for sale, as food " +
                        "or drink, any article which has been rendered or has become noxious, or is in a state unfit " +
                        "for food or drink, knowing or haying reason to believe that the same is noxious as food or " +
                        "drink, shall be punished with imprisonment of either description for a term which may " +
                        "extend to six months, of with fine which may extend to one thousand rupees, or with both.");
                mydb2.addsection("274. Adulteration of drugs","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever adulterates any drug or medical preparation-in " +
                        "such a manner as to lessen the efficacy or change the operation of such drug) or medical " +
                        "preparation, or to make it noxious intending that it shall be sold or used for, or knowing it " +
                        "to be likely that it will be sold or used for, any medicinal purposes, as if it had not " +
                        "undergone such adulteration, shall be punished with imprisonment of either description for " +
                        "a term which may extend to six months or with fine which may extend to one thousand " +
                        "rupees, or with both. ");
                mydb2.addsection("275. Sale of adulterated drugs","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever, knowing any drug or medical preparation to " +
                        "have been adulterated in such a manner as to lessen its efficacy, to change its operation, " +
                        "or to render it noxious, sells the same, or offers or exposes it for sale, or issues it from any " +
                        "dispensary for medicinal purposes as unadulterated, or causes it to be used for medicinal " +
                        "purposes by any person not knowing of the adulteration, shall be punished with " +
                        "imprisonment of either description for a term which may extend to six months, or with fine " +
                        "which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("276. Sale of drug as a different drug or preparation","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever knowingly sells, or offers " +
                        "or exposes for sale, or issues from a dispensary for medicinal purposes, any drug or " +
                        "medical preparation, as a different drug or medical preparation, shall be punished with " +
                        "imprisonment of either description for a term which may extend to six months, or with fine " +
                        "which may extend to one thousand rupees, or with both, ");
                mydb2.addsection("277. Fouling water of public spring or reservoir","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever voluntarily corrupts or fouls " +
                        "the water of any public spring or reservoir, so as to render it less fit for the purpose for " +
                        "which it is ordinarily used, shall be punished with imprisonment of either description for a " +
                        "term which may extend to three months, or with fine which may extend to five hundred " +
                        "rupees, or with both. ");
                mydb2.addsection("278. Making atmosphere noxious to health","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever voluntarily vitiates the " +
                        "atmosphere in any place so as to make it noxious to the health of persons in general " +
                        "dwelling or carrying on business in the neighbourhood or passing along a public way, shall " +
                        "be punished with fine, which may extend to five hundred rupees. ");
                mydb2.addsection("279. Rash driving or riding on a public way","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever drives any vehicle, or rides,, on " +
                        "any public way in a manner so rash or negligent as .to endanger human life, or to be likely " +
                        "to cause hurt or injury to any other person, shall be punished with imprisonment of either " +
                        "description for a term which may extend to two years or with fine which may extend to one " +
                        "thousand rupees, or with both. ");
                mydb2.addsection("280. Rash navigation of vessel","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever navigates any vessel in a manner so rash or " +
                        "negligent as to endanger human life, or to be likely to cause hurt or injury to any other " +
                        "person, shall be punished with imprisonment of either description for a term which may " +
                        "extend to six months, or with fine which may extend to one thousand rupees or with both.");
                mydb2.addsection("281. Exhibition of false light, mark or buoy","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever exhibits any false light, mark or " +
                        "buoy intending or knowing it to be likely that such exhibition will mislead any navigator, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "seven years, or with fine, or with both. ");
                mydb2.addsection("282. Conveying person by water for hire in unsafe or overloaded vessel","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever " +
                        "knowingly or negligently conveys; or causes to be conveyed for hire, any person by water " +
                        "in any vessel, when that vessel is in such a state or so loaded as to endanger the fife of " +
                        "that person, shall be punished with imprisonment of either description for a term which " +
                        "may extend to six months, or with fine which may extend to one thousand rupees, or with " +
                        "both.");
                mydb2.addsection("283. Danger or obstruction in public way or line of navigation","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever, by doing any " +
                        "act, or by omitting to take order with any property in his possession or under his charge, " +
                        "causes danger, obstruction or injury to any person in any public way or public line of " +
                        "navigation, shall be punished with fine which may extend to two hundred rupees. ");
                mydb2.addsection("284. Negligent conduct with respect to poisonous substance","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever does, with " +
                        "any poisonous substance, any act in a manner so rash or negligent as to endanger human " +
                        "life, or to be likely to cause hurt or injury to any person, or knowingly or negligently omits " +
                        "to take such order with any poisonous substance in his possession as is sufficient to " +
                        "guard against any probable danger to human life from such poisonous substance, \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "six months, or with fine, which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("285. Negligent conduct with respect to fire or combustible matter","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever does, " +
                        "with tire or any combustible matter, any act so rashly or negligently as to endanger human " +
                        "life, or to be likely to cause hurt or injury to any other person, or knowingly or negligently omits to take such order with any fire or any combustible " +
                        "matter in his possession as is sufficient to guard against any probable danger to human " +
                        "life from such fire or combustible matter. \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "six months, or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("286. Negligent conduct with respect to explosive substance","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever does, with any " +
                        "explosive substance any act so rashly or negligently as to endanger human life, or to be " +
                        "likely to cause hurt or injury to any other person, \n\n" +
                        "or knowingly or negligently omits to take such order with any explosive substance in his " +
                        "possession as is sufficient to guard against any probable danger to human life from that " +
                        "substance, \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "six months, or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("287. Negligent conduct with respect to machinery","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever does, with any " +
                        "machinery, any act so rashly or negligently as to endanger human life or to be likely to " +
                        "cause hurt or injury to any other person, \n\n" +
                        "or knowingly or negligently omits to take such order with any machinery in his possession " +
                        "or under his care as is sufficient to guard against any probable danger to human life from " +
                        "such machinery, \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "Six months, or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("288. Negligent conduct with respect to pulling down or repairing buildings","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever, in pulling down or repairing any building, knowingly or negligently omits to take \n" +
                        "such order with that building as is sufficient to guard against any probable danger to " +
                        "human life from the fall of that building, or of any part thereof, shall be punished with " +
                        "imprisonment of either description for a term which may extend to six months, or with fine " +
                        "which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("289. Negligent conduct with respect to animal","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever, knowingly or negligently " +
                        "omits to take such order with any animal in his possession as is sufficient to guard against " +
                        "any probable danger to human life, or any probable danger of grievous hurt from such " +
                        "animal, shall be punished with imprisonment of either description for a term which may " +
                        "extend to six months, or with fine which may extend to one thousand Rupees, or with " +
                        "both. ");
                mydb2.addsection("290. Punishment for public nuisance in cases not otherwise provided for","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16," Whoever " +
                        "commits a public nuisance in any case not otherwise punishable by this Code, shall be " +
                        "punished with fine which may extend to two hundred rupees. ");
                mydb2.addsection("291. Continuance of nuisance after injunction to discontinue","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever repeats or " +
                        "continues a public nuisance having been enjoined by any public servant who has lawful " +
                        "authority to issue such injunction not to repeat or continue such nuisance, shall be " +
                        "punished with simple imprisonment for a term which may extend to six months, or with " +
                        "fine, or with both. ");
                mydb2.addsection("292. Sale, etc., of obscene books, etc.","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever:- \n\n" +
                        "(a) sells, lets to hire, distributes, publicly exhibits or in any manner puts into circulation, or " +
                        "for purposes of sale. hire, distribution, public exhibition or circulation,, makes, produces " +
                        "or has in his possession any obscene book, pamphlet, paper, drawing, painting, " +
                        "representation or figure or any other obscene object whatsoever, or \n\n" +
                        "(b) imports, exports or conveys any obscene object for any of the purposes aforesaid, or " +
                        "knowing or having reason to believe that such object will be sold, let to hire, distributed or " +
                        "publicly exhibited or in any manner put into circulation, or\n\n " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "Six months, or with fine which may extend to one thousand rupees, or with both. \n\n" +
                        "(c) takes part in or receives profits from, any business in the course of which he knows or " +
                        "has reason to believe that any such obscene objects are, for any of -the purposes " +
                        "aforesaid, made, produced, purchased, kept, imported, exported, conveyed, publicly " +
                        "exhibited or in any manner put into circulation, or . \n\n" +
                        "(d) advertises or makes known by any means whatsoever that any person he engaged or " +
                        "is ready to engage in any act which is an offence under this section, or that any such " +
                        "obscene object can be procured from or through any person, or \n\n" +
                        "(e) offers or attempts to do any act which is an offence under this section, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three months, or which tine or with both. . \n\n" +
                        "Exception: This section does not extend to any book, pamphlet, writing, drawing or " +
                        "painting kept or used bona fide for religious purposes or any representation sculptured, " +
                        "engraved, painted or otherwise represented on or in any temple, or on any car used for " +
                        "the conveyance of idols, or kept or used for any religious purpose. ");
                mydb2.addsection("293. Sale, etc., of obscene objects to young person","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever sells, .lets to hire, " +
                        "distributes,, exhibits or circulates to any person under the age of twenty years any such " +
                        "obscene object as is referred to in the last preceding section, or offers or attempts so to " +
                        "do, shall be punished with imprisonment of either description for a term which may extend " +
                        "to six months, or with fine, or with both. ");
                mydb2.addsection("294. Obscene acts and songs; ","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever, to the annoyance of others, --\n\n " +
                        "(a) does any obscene act in any public place, or \n\n" +
                        "(h) sings, recites or utters any obscene songs, ballad or words, in or near any public " +
                        "place, \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three months, or with fine, or with both. ");
                mydb2.addsection("294-A. Keeping lottery office","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever keeps any office or place for the purpose of " +
                        "drawing any lottery not being a State lottery or a lottery authorized by the Provincial " +
                        "Government shall be punished with imprisonment of either description for a term which " +
                        "may extend to six months, or with fine, or with both. \n\n" +
                        "And whoever publishes any proposal to pay any sum, or to deliver any goods, or to -do or " +
                        "forbear doing anything for the benefit of any person, on any event or contingency relative " +
                        "or applicable to the drawing of any ticket, lot, number or figure in any such lottery shall be " +
                        "punished with fine which may extend to one thousand rupees. \n" +
                        "Sec. 294-A ins- by the Pakistan Penal Code (Amendment) Act, XXVII of 1970");
                mydb2.addsection("294-B. Offering of prize in connection with trade, etc.","OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY CONVENIENCE, DECENCY AND MORALS",16,"Whoever offers, or undertakes " +
                        "to offer, in connection with any trade or business or sale of any commodity, any prize, " +
                        "reward or other similar consideration, by whatever name called, whether in money or kind, " +
                        "against any coupon, ticket, number or figure, or by any other device, as an inducement or " +
                        "encouragement to trade or business or to the buying of any commodity, or for the purpose " +
                        "of advertisement or popularising any commodity, and whoever publishes any such offer, " +
                        "shall be punishable, with imprisonment of either description for a term which may extend " +
                        "to six months, or with fine, or with both. \n" +
                        "Sec. 294-B ins. by Pakistan Penal Code (Amendment) Act, XX of 1965. ");
                //chapter 14

                mydb2.addchapters("OFFENCES RELATING TO RELIGION","10","CHAPTER XV");

                mydb2.addsection("295. Injuring or defiling place of worship, with Intent to insult the religion of any " +
                        "class","OFFENCES RELATING TO RELIGION",17,"Whoever destroys, damages or defiles any place of worship, or any object held " +
                        "sacred by any class of persons with the intention of thereby insulting the religion of any " +
                        "class of persons or with the knowledge that any class of persons is likely to consider such " +
                        "destruction damage or defilement as an insult to their religion. shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("295-A. Deliberate and malicious acts Intended to outrage religious feelings of any " +
                        "class by insulting Its religion or religious beliefs","OFFENCES RELATING TO RELIGION",17,"Whoever, with deliberate and " +
                        "malicious intention of outraging the 'religious feelings of any class of the citizens of " +
                        "Pakistan, by words, either spoken or written, or by visible representations insults the religion or the religious beliefs of that class, shall be punished with imprisonment of either " +
                        "description for a term which may extend to ten years, or with fine, or with both. " +
                        "Sec. 295-A ins. by the Criminal Law (Amendment) Act, XXV of 1927. ");
                mydb2.addsection("295-B. Defiling, etc., of Holy Qur'an","OFFENCES RELATING TO RELIGION",17,"Whoever wilfully defiles, damages or desecrates a " +
                        "copy of the Holy Qur'an or of an extract therefrom or uses it in any derogatory manner or " +
                        "for any unlawful purpose shall be punishable with imprisonment for life. " +
                        "Sec. 295-B added by P.P.C. (Amendment) Ordinance, I of 1982. ");
                mydb2.addsection("295-C. Use of derogatory remarks, etc., in respect of the Holy Prophet","OFFENCES RELATING TO RELIGION",17,"Whoever by " +
                        "words, either spoken or written, or by visible representation or by any imputation, " +
                        "innuendo, or insinuation, directly or indirectly, defiles the sacred name of the Holy Prophet " +
                        "Muhammad (peace be upon him) shall be punished with death, or imprisonment for life, " +
                        "and shall also be liable to fine. \n" +
                        "Sec. 295-C ins. by the Criminal Law (amendment) Act, 111 of 1986, S. 2");
                mydb2.addsection("296. Disturbing religious assembly ","OFFENCES RELATING TO RELIGION",17,"Whoever voluntarily causes disturbance to any " +
                        "assembly lawfully engaged in the performance of religious worship, or religious " +
                        "ceremonies, shall be punished with imprisonment of either description for a term which " +
                        "may extend to one year, or with fine, or with both. ");
                mydb2.addsection("297. Trespassing on burial places, etc.","OFFENCES RELATING TO RELIGION",17,"Whoever, with the intention of wounding the " +
                        "feelings of any person, or of insulting the religion of any person, or with the knowledge that " +
                        "the feelings of any person are likely to be wounded, or that the religion of any person is " +
                        "likely to be insulted thereby, \n\n" +
                        "commits any trespass in any place of worship or on any place of sculpture, or any place " +
                        "set apart for the performance \n\n" +
                        "of funeral rites or as a, depository for the remains of the dead, or offers any indignity to " +
                        "any human corpse or causes disturbance to any persons assembled for the performance " +
                        "of funeral ceremonies, \n\n" +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "one year, or with fine, or with both. ");
                mydb2.addsection("298. Uttering words, etc., with deliberate intent to wound religious feelings","OFFENCES RELATING TO RELIGION",17,"Whoever, with the deliberate intention of wounding the religious feelings of any person, " +
                        "utters any word or makes any sound in the hearing of that person or makes any gesture in " +
                        "the sight of that person or places any object in the sight of that person, shall be punished " +
                        "with imprisonment of either description for a term which may extend to one year or with " +
                        "fine, or with both.");
                mydb2.addsection("298-A. Use of derogatory remarks, etc., in respect of holy personages","OFFENCES RELATING TO RELIGION",17,"Whoever by " +
                        "words, either spoken or written, or by visible representation, or by any imputation, " +
                        "innuendo or insinuation, directly or indirectly, defiles the sacred name of any wife (Ummul Mumineen), or members of the family (Ahle-bait), of the Holy Prophet (peace be upon " +
                        "him), or any of the righteous Caliphs (Khulafa-e-Rashideen) or companions (Sahaaba) of " +
                        "the Holy Prophet (peace be upon him) shall be punished with imprisonment of either " +
                        "description for a term which may extend to three years, or with fine, or with both. \n\n" +
                        "Sec. 298-A added by the Pakistan Penal Code (Second Amendment) Ordinance, XLIV of 1980. ");
                mydb2.addsection("298-B. Misuse of epithets, descriptions and titles, etc., reserved for certain holy " +
                        "personages or places","OFFENCES RELATING TO RELIGION",17,"(1) Any person of the Quadiani group or the Lahori group (who " +
                        "call themselves 'Ahmadis' or by any other name who by words, either spoken or written, or " +
                        "by visible representation- \n\n" +
                        "(a) refers to or addresses, any person, other than a Caliph or companion of the Holy " +
                        "Prophet Muhammad (peace be upon him), as \"Ameer-ul-Mumineen\", \"Khalifatul\u0002Mumineen\", Khalifa-tul-Muslimeen\", \"Sahaabi\" or \"Razi Allah Anho\"; \n\n" +
                        "(b) refers to, or addresses, any person, other than a wife of the Holy Prophet Muhammad " +
                        "(peace bi upon him), as \"Ummul-Mumineen\"; \n\n" +
                        "(c) refers to, or addresses, any person, other than a member of the family \"Ahle-bait\" of " +
                        "the Holy Prophet Muhammad (peace be upon him), as \"Ahle-baft\"; or \n\n" +
                        "(d) refers to, or names, or calls, his place of worship a \"Masjid\"; " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three years, and shall also be liable to fine. \n\n" +
                        "(2) Any person of the Qaudiani group or Lahori group (who call themselves \"Ahmadis\" or " +
                        "by any other name) who by words, either spoken or written, or by visible representation " +
                        "refers to the mode or form of call to prayers followed by his faith as \"Azan\", or recites Azan " +
                        "as used by the Muslims, shall be punished with imprisonment of either description for a " +
                        "term which may extend to three years, and shall also be liable to fine. \n" +
                        "Sec. 298-B ins. by Anti-lslamic Activities of Quadiani Group, Lahori Group and Ahmadis (Prohibition and Punishment) " +
                        "Ordinance, XX of 1984");
                mydb2.addsection("298-C. Person of Quadiani group, etc., calling himself a Muslim or preaching or \n" +
                        "propagating his faith","OFFENCES RELATING TO RELIGION",17,"Any person of the Quadiani group or the Lahori group (who call " +
                        "themselves 'Ahmadis' or by any other name), who directly or indirectly, poses himself as a " +
                        "Muslim, or calls, or refers to, his faith as Islam, or preaches or propagates his faith, or " +
                        "invites others to accept his faith, by words, either spoken or written, or by visible " +
                        "representations, or in any manner whatsoever outrages the religious feelings of Muslims " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three years and shall also be liable to fine. \n\n" +
                        "Sec. 298-C. ins. by the Anti-Islamic Activities of Quadiani Group, Lahori Group and Ahmadis (Prohibition and " +
                        "Punishment) Ordinance, XX of 1984. ");

                //chapter 15
                mydb2.addchapters("OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ","75","CHAPTER XVI");

                mydb2.addsection("299. Definitions","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"In this Chapter, unless there is anything repugnant in the subject or " +
                        "context: \n\n" +
                        "(a) \"adult\" means a person who has attained the age of eighteen years ; \n\n" +
                        "(b) \"arsh\" means the compensation specified in this Chapter to be paid to the victim or his " +
                        "heirs under this Chapter; . \n\n" +
                        "(c) \"authorised medical officer\" means a medical officer or a Medical board, howsoever " +
                        "designated, authorised by the Provincial Government; \n\n" +
                        "(d) \"daman\" means the compensation determined by the Court to be paid by the offender " +
                        "to the victim for causing hurt not liable to arsh;\n\n" +
                        "(e) \"diyat\" means the compensation specified in Section 323 payable to the heirs of the " +
                        "victim ; \n\n" +
                        "(f) \"Government\" means the Provincial Government, \n\n" +
                        "(g) \"ikrah-e-tam\" means putting any person, his .spouse or any of his blood relations within " +
                        "the prohibited degree of marriage in fear of instant death or instant, permanent impairing " +
                        "of any organ of the body or instant fear of being subjected to sodomy or ziha-bil-jabr; \n\n" +
                        "(h) \"ikrah-e-naqis\" means any form of duress which does not amount to ikrah-i-tam; \n\n" +
                        "(i) \"minor\" means a person who is not an adult; \n\n" +
                        "(j) \"qatl\" means causing death of a person ; \n\n" +
                        "(k) \"qisas\" means punishment by causing similar hurt at the same part of the body of the " +
                        "convict as he has caused to the victim or by causing his death if he has committed qatl-i-amd in exercise Of the right of the victim or a wali', \n\n" +
                        "(l) \"ta'zir\" means purushment other than qisas, diyat, arsh , or daman; and \n\n" +
                        "(m) \"wali\" means a person entitled to claim qisas");
                mydb2.addsection("300. Qatl-e-Amd ","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever, with the intention of causing death or with the intention of " +
                        "causing bodily injury to a person, by doing an act which in the ordinary course of nature is " +
                        "likely to cause death, or with-the knowledge that his act is so imminently dangerous that it " +
                        "must in all probability cause death, causes the death of such person, is said to commit " +
                        "qatl-e-amd. ");
                mydb2.addsection("301. Causing death of person other than the person whose death was intended","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Where a person, by doing anything which he intends or knows to be likely to cause death, " +
                        "causes death of any person whose death he neither intends nor knows himself to be likely " +
                        "to cause, such an act committed by the offender shall be liable for qatl-i-amd. ");
                mydb2.addsection("302. Punishment of qatl-i-amd ","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever commits qatl-e-amd shall, subject to the " +
                        "provisions of this Chapter be: \n\n" +
                        "(a) punished with death as qisas; \n\n" +
                        "(b) punished with death for imprisonment for life as ta'zir having regard to the facts and " +
                        "circumstances of the case, if the proof in either of the forms specified in Section 304 is not " +
                        "available; or \n\n" +
                        "(c) punished with imprisonment of either description for a term which may extend to " +
                        "twenty-five years, where according to the Injunctions of Islam the punishment of qisas is " +
                        "tot applicable. ");
                mydb2.addsection("303. Qatl committed under ikrah-i-tam or ikrah-i-naqis","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever commits qatl: \n\n" +
                        "(a) under Ikrah-i-tam shall be punished with imprisonment for a term which may extend to " +
                        "twenty-five years but shall not be less than ten years and the person causing 'ikrah-i-tam' " +
                        "shall be punished for the '.kind of Qatl committed as a consequence of ikrah-i-tam; or \n\n" +
                        "(b) under 'ikrah-i-naqis' shall be punished for the kind of Qatl committed by him and the " +
                        "person, causing 'ikrah-i-naqis, shall be punished with imprisonment for a term which may " +
                        "extend to ten years. ");
                mydb2.addsection("304. Proof of qatl-i-amd liable to qisas, etc.","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Proof of qatl-i-amd shall be in any of " +
                        "the following forms, namely: - \n\n" +
                        "(a) the accused makes before a Court competent to try the offence a voluntary and true " +
                        "confession of the commission of the offence; or \n\n" +
                        "(b) by the evidence as provided in Article 17 of the Qanun-e-Shalladat, 1984 (P.O. No. 10 " +
                        "of 1984). \n\n" +
                        "(2) The provisions of sub-section (1) shall, mutatis, mutandis, apply to a hurt liable to " +
                        "qisas. ");
                mydb2.addsection("305. Wali","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"In case of qatl, the wali shall be-- \n\n" +
                        "(a) the heirs of the victim, according to his personal law; and \n\n" +
                        "(b) the Government, if there is no heir. ");
                mydb2.addsection("306. Qatl-e-amd not liable to qisas","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Oatil-i-Amd shall not be liable to qisas in the " +
                        "following cases, namely:-- \n\n" +
                        "(a) when an offender is a minor or insane: \n\n" +
                        "Provided that, where a person liable to qisas associates himself in the commission of the " +
                        "offence with a person not liable to qisas, with the intention of saving himself from qisas, " +
                        ".he shall not be exempted from qisas; \n\n" +
                        "(b) when an offender causes death of his child or grand-child, howlowsoever'; and \n\n" +
                        "(c) when any wali of the victim is a direct descendant, howlowsoever, of the offender. ");
                mydb2.addsection("307. Cases in which Qisas for qatl-i-amd shall not be enforced","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Qisas for qatl-i-amd, shall not be enforced in the following cases, namely:-- \n\n" +
                        "(a) when the offender dies before the enforcement of qisas; \n\n" +
                        "(b) when any wali voluntarily and without duress, to the satisfaction of the Court, waives " +
                        "the right of qisas under Section 309 or compounds under Section 310 and \n\n" +
                        "(c) when the right of qisas devolves on the offender as a result of the death of the wali of " +
                        "the victim, or on , the person who has no right of qisas against the offender., . \n\n" +
                        "(2) To satisfy itself that the wali has waived the right of qi'sas under Section 309 or " +
                        "compounded the right of qisas under Section 310 voluntarily and without duress the Court \n\n" +
                        "shall take down the statement of the wali and such other persons as it may deem " +
                        "necessary on oath and .record an opinion that it is satisfied that the Waiver or, as the case " +
                        "may be, the composition, was voluntary and not the result of any duress. \n\n" +
                        "Illustrations \n" +
                        "(i) A kills Z, the maternal uncle of his son B. Z has no other wali except D the wife of A. D " +
                        "has the right of qisas from A but if D dies, the right of qisas shall devolve on her son B " +
                        "who is also the son of the offender A. B cannot claim qisas against his father. Therefore, " +
                        "the qisas cannot be enforced. \n\n" +
                        "(ii) B kills Z, the brother of their husband A. Z has no heir except A. Here A can claim " +
                        "qisas from his wife B. But if A dies, the right of qisas shall devolve on his son D who is " +
                        "also son of B, the qisas cannot be enforced against B. ");
                mydb2.addsection("308. Punishment in qatl-i-amd not liable to qisas, etc.","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Where an offender guilty of " +
                        "qatl-i-amd is not liable to qisas under Section 306 or the gisas is not enforceable under " +
                        "clause (c) of Section 307, he shall be liable to diyat:\n\n Provided that, where the offender is minor or insane, diyat shall be payable either from his " +
                        "property or, by such person as may be determined by the Court: \n\n" +
                        "Provided further that where at the time of committing qatl-i-amd the offender being a " +
                        "minor, had attained sufficient maturity of being insane, had a lucid interval, so as to be " +
                        "able to realize the consequences of his act, he may also be punished with imprisonment " +
                        "of either description for a term which may extend to fourteen years as ta'zir. \n\n" +
                        "Provided further that, where the qisas is not enforceable under clause (c) of Section 307, " +
                        "the offender shall be liable to diyat only if there is any wali other than offender and if there " +
                        "is no wali other than the offender, he shall be punished with imprisonment of either " +
                        "description for a term which may extend to fourteen years as ta'zir. \n\n" +
                        "(2) Notwithstanding anything contained in sub-section (i), the Court, having regard to the " +
                        "facts and circumstances of the case in addition to the punishment of diyat, may punish the " +
                        "offender with imprisonment of either description for a term which may extend to fourteen " +
                        "years, as ta'zir. \n");
                mydb2.addsection("309. Waiver (Afw) of qisas in qatl-i-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18," In the case of qatl-i-amd, an adult sane wali " +
                        "may, at any time and without any compensation, waive his right of qisas: \n\n" +
                        "Provided that the right of qisas shall not be waived; \n\n" +
                        "(a) where the Government is the wali, or \n\n" +
                        "(b) where the right of qisas vests in a minor or insane, \n\n" +
                        "(2) Where a victim has more than one Wali any one of them may waive his right of qisas: " +
                        "Provided that the wali who does not waive the right of qisas shall be entitled to his share " +
                        "of diyat. \n\n" +
                        "(3) Where there are more than one victim, the waiver of the right of qisas by the wali of " +
                        "one victim shall not affect the right of qisas of the wali of the other victim. \n\n" +
                        "(4) Where there are more than one offenders, the waiver of the right of qisas against one " +
                        "offender shall not affect the right of qisas against the other offender. ");
                mydb2.addsection("310. Compounding of qisas (Sulh) in qatl-i-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18," (1) In the case of qatl-i-amd, an adult " +
                        "sane wali may, at any time on accepting badl-i-sulh, compound his right of qisas: \n\n" +
                        "Provided that giving a female in marriage shall not be a valid badl-i-sulh. \n\n" +
                        "(2) Where a wali is a minor or an insane, the wali of such minor or insane wali may " +
                        "compound the right of qisas on behalf of such minor or insane wali: Provided that the value of badf-i-sufh shall not be less than the value of diyat. \n\n" +
                        "(3) Where the Government is the wali, it may compound the right of qisas:\n\n " +
                        "Provided that fee value of badi-i-sulh shall not be less than the value of diyat. \n\n" +
                        "(4) Where the badl-i-sufh is not determined or is a property or a right the value of which " +
                        "cannot be determined in terms of money under Shari'ah, the right of qisas shall be " +
                        "deemed to have been compounded and the offender shall be liable to diyat. \n\n" +
                        "(5) Badl-i-sulh may be paid or given on demand or on a deferred date as may be agreed " +
                        "upon between the offender and the wali \n\n" +
                        "Explanation: In this section, Badl-i-sulh means the mutually agreed compensation " +
                        "according to Shari'ah to be paid or given by the offender to a wali in cash or in kind or in " +
                        "the form of movable or immovable property. ");
                mydb2.addsection("311-Ta'zir after waiver or compounding of right of qisas in qatl-i-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Notwithstanding anything contained in Section 309 or Section 310, where all the wali do " +
                        "not waive or compound the right of qisas, or keeping in view the principle of fasad-fil-arz " +
                        "the Court may, in its discretion having regard to the facts and circumstances of the case, " +
                        "punish an offender against whom the right of qisas has been waived or compounded with " +
                        "imprisonment of either description for a term of which may extend to fourteen years as " +
                        "ta'zir. \n\n" +
                        "Explanation: For the purpose of this section, the expression fasad-fil-arz shall include the " +
                        "past conduct of the offender, or whether he has any previous convictions, or the brutal or " +
                        "shocking manner in which the offence has been committed which is outrageous to the " +
                        "public conscience, or if the offender is considered a potential danger to the community. ");
                mydb2.addsection("312. Qatl-i-amd after waiver or compounding of qisas","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Where a wali commits qatl-i-amd of a convict against whom the right of qisas has been waived under Section 309 or " +
                        "compounded under Section 310, such wali shall be punished with-- . \\. \n\n" +
                        "(a) qisas, if he had himself, waived or compounded the right of qisas against the convict or " +
                        "had knowledge of such waiver of-composition by another wali, or \n\n" +
                        "(b) diyat, if he had no knowledge of such waiver or composition. ");
                mydb2.addsection("313. Right of qisas in qatl-i-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Where there is only one wali, he alone has the " +
                        "right of qisas in qatl-i-amd but, if there are more than one, the right of qisas vests in each " +
                        "of them. \n\n" +
                        "(2) If the victim- \n\n" +
                        "(a) has no wali, the Government shall have the right of qisas; or (b) has no wali other than a minor or insane or one of the wali is a minor or insane, the " +
                        "father or if he is not alive the paternal grandfather of such wali shall have the right of qisas " +
                        "on his behalf: \n\n" +
                        "Provided that, if the minor or insane wali has no father or paternal grandfather, " +
                        "howhighsoever, alive and no guardian has been appointed by the Court, the Government " +
                        "shall have the right of qisas on his behalf. ");
                mydb2.addsection("314. Execution of qisas in qatl-i-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Qisas in Qatll-i-amd shall be executed by a " +
                        "functionary of the Government by causing death of the convict as the Court may direct. \n\n" +
                        "(2) Qisas shall not be executed until all the wali are present at the time of execution, either " +
                        "personally or through their representatives authorised by them in writing in this behalf: \n\n" +
                        "Provided that where a wali or his representative fails to present himself on the date, time " +
                        "and place of execution of qisas after having been informed of the date, time and place as " +
                        "certified by the Court, an officer authorised by the Court shall give permission for the " +
                        "execution of qisas and the Government shall cause execution of qisas in the absence of " +
                        "such wali. \n\n" +
                        "(3) If the convict is a woman who is pregnant, the Court may, in consultation with an " +
                        "authorised medical officer, postpone the execution of qisas up to a period of two years " +
                        "after the birth of the child and during this period she may be released on bail on furnishing " +
                        "of security to the satisfaction of the Court, or, if she is not so released she shall, be dealt " +
                        "with as if sentenced to simple imprisonment. ");
                mydb2.addsection("315-Qatl shibh-i-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever, with intent to cause harm to the body or mind of any " +
                        "person, causes the death of that or of any other person by means of a weapon or an act " +
                        "which in the ordinary course of nature is not likely to cause death is said to commit qatl-shibh-i-amd. \n\n" +
                        "Illustration \n" +
                        "A in order to cause hurt strikes Z with a stick or stone which in the ordinary course of " +
                        "nature is not likely to cause death. Z dies as a result of such hurt. A shall be guilty of Qatl " +
                        "shibh-i-amd. ");
                mydb2.addsection("316. Punishment for Qatl shibh-l-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever commits qatl shibh-i-amd shall be " +
                        "liable to diyat and may also be punished with imprisonment of either description for a term " +
                        "which may extend to fourteen years as ta'zir.");
                mydb2.addsection("317. Person committing qatl debarred from succession","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Where a person " +
                        "committing qatl-i-amd or Qatl shibh-i-amd is an heir or a beneficiary under a will, he shall " +
                        "be debarred from succeeding to the estate of the victim as an heir or a beneficiary. ");
                mydb2.addsection("318. Qatl-i-khata","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever, without any intention to cause death of, or cause harm to, a " +
                        "person causes death of such person, either by mistake of act or by mistake of fact, is said " +
                        "to commit qatl-i-khata.\n\n " +
                        "Illustrations \n" +
                        "(a) A aims at a deer but misses the target and kills Z who is standing by, A is guilty of " +
                        "qatl-i-khata. \n\n" +
                        "(b) A shoots at an object to be a boar but it turns out to be a human being. A is guilty of " +
                        "qatl-i-khata. ");
                mydb2.addsection("319. Punishment for qatl-i-khata","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever commits qatl-i-khata shall be liable to diyat:. \n\n" +
                        "Provided that, where qatl-i-khata is committed by a rash or negligent act, other than rash " +
                        "or negligent driving, the offender may, in addition to diyat, also be punished with " +
                        "imprisonment of either description for a term which may extend to five years as ta'zir.");
                mydb2.addsection("320. Punishment for qatl-i-khata by rash or negligent driving","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever commits qatl-i-khata by rash or negligent driving shall, having regard to the facts and circumstances the " +
                        "case, in addition to diyat, be punished with imprisonment of either description for a term " +
                        "which may extend to ten years ");
                mydb2.addsection("321. Qatl-bis-sabab ","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever, without any intention, cause death of, or cause harm to, " +
                        "any person, does any unlawful act which becomes a cause for the death of another " +
                        "person, is said to commit qatl-bis-sabab. \n\n" +
                        "Illustration \n" +
                        "A unlawfully digs a pit in the thoroughfare, but without any intention to cause death of, or " +
                        "harm to, any person, B while passing from there falls in it and is killed. A has committed " +
                        "qatl-bis-sabab. ");
                mydb2.addsection("322. Punishment for qatl-bis-sabab","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever commit qatl bis-sabab shall be liable to " +
                        "diyat.");
                mydb2.addsection("323. Value of diyat","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) The Court shall, subject to the Injunctions of Islam as laid down in " +
                        "the Holy Qur'an and Sunnah and keeping In view the financial position of the convict and " +
                        "the heirs of the victim, fix the value of diyat which shall not be less than the value of thirty " +
                        "thousand six hundred and thirty grams of silver. \n\n" +
                        "(2) For the purpose of sub-section (1), the Federal Government shall, by notification in the " +
                        "official Gazette, declare the value of Silver, on the first day of July each year or on such " +
                        "date as it may deem fit, which shall be the value payable during a financial year. ");
                mydb2.addsection("324. Attempt to commit qatl-i-amd","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever does any act with such intention or " +
                        "knowledge, and under such circumstances, that, if he by. that act caused qatl, he would " +
                        "be guilty of qatl-i-amd, shall be punished with imprisonment for either description for a term which may extend to ten years, and shall also be liable to fine, " +
                        "and, if hurt is caused to any person by such act, the offender shall, in addition to the " +
                        "imprisonment and fine as aforesaid, be liable to the punishment provided for the hurt " +
                        "caused: \n\n" +
                        "Provided that. where the punishment for the hurt is qisas which is not executable, the " +
                        "offender shall be liable to arsh and may also be punished with imprisonment of either " +
                        "description for a term which may extend to seven years.");
                mydb2.addsection("325. Attempt to commit suicide","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever attempts to commit suicide and does any act " +
                        "towards the commission of such offence, shall be punished with simple imprisonment for a " +
                        "term which may extend to one year, or with fine, or with both.");
                mydb2.addsection("326. Thug","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever shall have been habitually associated with any other or others for " +
                        "the purpose of committing robbery or child-stealing by means of or accompanied with " +
                        "Qatl, is a thug. ");
                mydb2.addsection("327. Punishment","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever is a thug, shall be punished with imprisonment for life and " +
                        "shall also be liable to fine. ");
                mydb2.addsection("328. Exposure and abandonment of child under twelve years by parent or person " +
                        "having care of it","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever being the father or mother of a child under the age of twelve " +
                        "years, or having the care of such child, shall expose or leave such child in any place with " +
                        "the intention of wholly abandoning such child, shall be punished with imprisonment' of " +
                        "either description for- a term which may extend to seven years, or with fine, or with both. \n\n" +
                        "Explanation : This section is not intended to prevent the trial of the offender for qatl-i-amd " +
                        "or qatl-i-shibh-i-amd or qatl-bis-sabab, as the case may be, if the child dies in " +
                        "consequence of the exposure.");
                mydb2.addsection("329. Concealment of birth by secret disposal of dead body","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever, by secretly " +
                        "burying or otherwise disposing of the dead body of a child whether such child dies before " +
                        "or after or during its birth, intentionally conceals or endeavours to conceal the birth shall " +
                        "be punishable with imprisonment of either description for a term which may extend to two " +
                        "years, or with fine, or with both. ");
                mydb2.addsection("330. Disbursement of diyat","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"The diyat shall be disbursed among the heirs of the victim " +
                        "according to their respective shares in inheritance: \n\n" +
                        "Provided that, where an heir foregoes his share, the diyat shall not be recovered to the " +
                        "extent of his share. ");
                mydb2.addsection("331. Payment of Diyat","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) The diyat may be made payable in lumpsum or in instalments " +
                        "spread over a period of three years from the date of the final judgment.\n\n (2) Where a convict fails to pay diyat or any part thereof within the period specified in sub-section (1), the convict may be kept in jail and dealt with in the same manner as if " +
                        "sentenced to simple imprisonment until the diyat is paid full or may be released on bail If " +
                        "he furnishes security equivalent to the amount of diyat to the satisfaction of the Court. \n\n" +
                        "(3) Where a convict dies before the payment of diyat or any part thereof, it shall be " +
                        "recovered from his estate. ");
                mydb2.addsection("332. Hurt","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Whoever causes pain, harm, disease, infianity or injury to any person or " +
                        "impairs, disables or dismembers any organ of the body or part thereof of any person " +
                        "without causing his death, is said to cause hurt. \n\n" +
                        "(2) The following are the kinds of hurt : \n\n" +
                        "(a) Itlaf-i-udw \n\n" +
                        "(b) itlaf-i-salahiyyat-i-udw \n\n" +
                        "(c) shajjah \n\n" +
                        "(d) jurh and \n\n" +
                        "(e) all kinds of other hurts. ");
                mydb2.addsection("333. Itlaf-i-udw","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever dismembers, amputates, severs any limb or organ of the body " +
                        "of another person is said to cause Itlaf-i-udw.");
                mydb2.addsection("334. Punishment for Itlaf-udw","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever by doing any act with the intention of thereby " +
                        "causing hurt to any person, or with the knowledge that he is likely thereby to cause hurt to " +
                        "any person causes Itlaf-i-udw of any person, shall, in consultation with the authorised " +
                        "medical officer, be punished with qisas, and if the qisas is not executable keeping in view " +
                        "the principles of equality in accordance with the Injunctions of Islam, the offender shall be " +
                        "liable to arsh and may also be punished with imprisonment of either description for a term " +
                        "which may extend to ten years as ta'zir. ");
                mydb2.addsection("335. Itlaf-i-salahiyyat-i-udw","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever destroys or permanently impairs the functioning, " +
                        "power or capacity of an organ of the body of another person, or causes permanent " +
                        "disfigurement is said to cause itlaf-i-salahiyyat-i-udw. ");
                mydb2.addsection("336. Punishment for itlaf-i-salahiyyat-i-udw","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever, by doing any act with the " +
                        "intention of causing hurt to any person, or with the knowledge that he is likely to cause " +
                        "hurt to any person, causes itlaf-i-salahiyyat-i-udw of any person, shall, in consultation with " +
                        "the authorised medical officer, be punished with qisas and if the qisas is not executable, " +
                        "keeping in view the principles of equality in accordance with the Injunctions of Islam, the " +
                        "offender shall be liable to arsh and may also be punished with imprisonment of either " +
                        "description for a term which may extend to ten years as taz’ir. ");
                mydb2.addsection("337. Shajjah","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Whoever causes, on the head or face of any person, any hurt which " +
                        "does not amount to itlaf-i-udw or itlaf-i-salahiyyat-i-udw, is said to cause shajjah. \n\n" +
                        "(2) The following are the kinds of shaljah namely:- \n\n" +
                        "(a) Shajjah-i-Khafifah \n\n" +
                        "(b) Shalfah'i-mudihah \n\n" +
                        "(c) Shajjah-i-hashimah \n\n" +
                        "(d) Shajjah-i-munaqqilah \n\n" +
                        "(e) Shaijah-i-ammah and \n\n" +
                        "(f) Shajjah-i-damighah \n\n" +
                        "(3) Whoever causes shajjah \n\n" +
                        "(i) without exposing bone of the victim, is said to cause shajjah-i-khafifah; \n\n" +
                        "(ii) by exposing any bone of the victim without causing fracture, is said to cause shajjah-i-mudihah; \n\n" +
                        "(iii) by fracturing the bone of the victim, without dislocating it, is said to cause shajjah-i-hashimah; \n\n" +
                        "(iv) by causing fracture of the bone of the victim and thereby the bone is dislocated, is said " +
                        "to cause shajfah-i-munaqqilah; \n\n" +
                        "(v) by causing fracture of the skull of the victim so that the wound touches the membrane " +
                        "of the brain, is said to cause shajjah-i-ammah; \n\n" +
                        "(vi) by causing fracture of the skull of the victim and the wound ruptures the membrane of " +
                        "the brain is said to cause shaijah-i-damighah. ");
                mydb2.addsection("337-A. Punishment of shajjah","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever, by doing any act with the intention of thereby " +
                        "causing hurt to any person, or with the knowledge that he is likely thereby to cause hurt to " +
                        "any person, causes-- \n\n" +
                        "(i) Shajjah-I-khafifah to any person, shall be liable to daman and may also be punished " +
                        "with imprisonment of either description for a term which may extend to two years as ta'zir, \n\n" +
                        "(ii) shajjah-i-mudihah to any person, shall, in consultation with the authorised medical " +
                        "officer, be punished with qisas, and if the, qisas is not executable keeping in view the principles of equality, in accordance with the Injunctions of Islam, the convict shall be " +
                        "liable to arsh which shall be five percent of the diyat and may also be punished with " +
                        "imprisonment of either description for a term which may extend to five years as ta'zir,\n\n " +
                        "(iii) shajjah-i-hashimah to any person, shall be liable to arsh which shall be ten per cent of " +
                        "the diyat and may also be punished with imprisonment of either description for a term " +
                        "which may extend to ten years as ta'zir, \n\n" +
                        "(iv) shajiah-i-munaqqilah to any person, shall be liable to arsh which shall be fifteen per " +
                        "cent of the diyat and may also be punished with imprisonment of either description for a " +
                        "term which may extend to ten years as ta 'zir, \n\n" +
                        "(v) shajjah-i-ammah to any person, shall be liable to arsh which shall be one-third of the " +
                        "diyat and may also be punished with imprisonment of either description for a term which " +
                        "may extend to ten years as ta'zir, and \n\n" +
                        "(vi) shajjah-i-damighah to any person shall be liable to arsh which shall be one-half of " +
                        "diyat and may also be punished with imprisonment of either description for a term which " +
                        "may extend to fourteen years as ta'zir. ");
                mydb2.addsection("337-B. Jurh","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Whoever causes on any part of the body of a person, other than the " +
                        "head or face, a hurt which leaves a mark of the wound, whether temporary or permanent, " +
                        "is said to cause jurh. \n\n" +
                        "(2) Jurh is of two kinds, namely:- \n\n" +
                        "(a) Jaifah ; and \n\n" +
                        "(b) Ghayr-jaifah ");
                mydb2.addsection("337-C. Jaifah","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever causes jurh in which the injury extends to the body cavity of the " +
                        "trunk, is said to cause jaifah. ");
                mydb2.addsection("337-D. Punishment for jaifah","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever by doing any act with the intention of causing " +
                        "hurt to a person or with the knowledge that he is likely to cause hurt to such person, " +
                        "causes jaifah to such person, shall be liable to arsh which shall be one-third of the diyat " +
                        "and may also be punished with imprisonment of either description for a term which may " +
                        "extend to ten years as ta'zir. ");
                mydb2.addsection("337-E. Ghayr-jaifah","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Whoever causes jurh which does not amount to jaifah, is said to " +
                        "cause ghayr-jaifah. \n\n" +
                        "(2) The following are the kinds of ghayr-faifah, namety:- \n\n" +
                        "(a) damihah \n\n" +
                        "(b) badi'ah (c) mutalahimah \n\n" +
                        "(d) mudihah \n\n" +
                        "(e) hashimah ; and \n\n" +
                        "(f) munaqqilah \n\n" +
                        "(3) Whoever causes ghayr-jaifah— \n\n" +
                        "(i) in which the.skin is ruptured and bleeding occurs, is said to cause damiyah; \n\n" +
                        "(ii) by cutting or incising the flesh without exposing the bone, is said to cause badi'ah; \n\n" +
                        "(iii) by lacerating the flesh, is said to cause mutalahimah', \n\n" +
                        "(iv) by exposing the bone, is said to cause mudihah; \n\n" +
                        "(v) by causing fracture of a bone without dislocating it, is said to cause hashimah; and \n\n" +
                        "(vi) by fracturing and dislocating the bone, is said to cause munaqqilah. ");
                mydb2.addsection("337-F. Punishment of ghayr-jaifah","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever by doing any act with the intention of " +
                        "causing hurt to any person, or with the knowledge that he is likely to cause hurt to any " +
                        "person, causes\" \n\n" +
                        "(i) damihah to any person, shall be liable to daman and may also be punished with " +
                        "imprisonment of either description for a term which may extend to one year as ta'zir, \n\n" +
                        "(ii) badi'ah to any person, shall be liable to daman and may also be punished with " +
                        "imprisonment of either description for a term which may extend to three years as ta'zir, \n\n" +
                        "(iii) mutafahimah to any person, shall be liable to daman and may also be punished with " +
                        "imprisonment of either description for a term which may extend to three years as ta'zir; \n\n" +
                        "(iv) mudihah to any person, shall be liable to daman and may also be punished with " +
                        "imprisonment of either description for a term which may extend to five years as ta'zir, \n\n" +
                        "(v) hashimah to any person, shall be liable to daman and may also be punished with " +
                        "imprisonment of either description for a term which may extend to five years as ta'zir, and \n\n" +
                        "(vi) munaqqilah to any person, shall be liable to daman and may also be punished with " +
                        "imprisonment of either description for a term which may extend to seven years as ta'zir. ");
                mydb2.addsection("337-G. Punishment for hurt by rash or negligent driving","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever causes hurt by rash " +
                        "or negligent driving shall be liable to arsh or daman specified for the kind of hurt caused " +
                        "and may also be punished with imprisonment of either description for a term which may " +
                        "extend to five years as ta'zir. ");
                mydb2.addsection("337-H. Punishment for hurt by rash or negligent act","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Whoever causes hurt by rash " +
                        "or negligent act, other than rash or negligent driving, shall be liable to arsh or daman " +
                        "specified for the kind of hurt caused and may also be punished with imprisonment of either " +
                        "description for a term which may extend to three years as ta'zir. \n\n" +
                        "(2) Whoever does any act so rashly or negligently as to endanger human life or the " +
                        "personal safety of other, shall be punished with imprisonment of either-description for a " +
                        "term which may extend to three months, or with fine, or with both. ");
                mydb2.addsection("337-I. Punishment for causing hurt by mistake (khata)","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18," Whoever causes hurt by " +
                        "mistake (khata) shall be liable to arsh or daman specified for the kind of hurt caused.");
                mydb2.addsection("337-J. Causing hurt by mean of a poison","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever administers to. or causes to be " +
                        "taken by, any person, any poison or any stupefying, intoxicating or unwholesome drug, or " +
                        "such other thing with intent to cause hurt to such person, or with intent to commit or to " +
                        "facilitate the commission of an offence, or knowing it to be likely that he will thereby cause " +
                        "hurt may, in addition to the punishment of arsh or daman provided for the kind of hurt " +
                        "caused, be punished, having regard to the nature of the hurt caused, with imprisonment of " +
                        "either description for a term which may extend to ten years. ");
                mydb2.addsection("337-K. Causing hurt to extort confession, or to compel restoration of property","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever causes hurt for the purpose of extorting from the sufferer or any person " +
                        "interested in the sufferer any .confession or any information which may lead to the " +
                        "detection of any offence or misconduct, or for the purpose of constraining the sufferer, or " +
                        "any person interested in the Sufferer, to restore, or to cause the restoration of, any " +
                        "property or valuable security or to satisfy any claim or demand, or to give information " +
                        "which may lead to the restoration of any property, or valuable security shall, in addition to " +
                        "the punishment of qisas, arsh or daman, as the case may be, provided for the kind of hurt " +
                        "caused, be punished, having regard to the nature of the hurt caused, with imprisonment of " +
                        "either description for a term which may extend to ten years as ta'zir. ");
                mydb2.addsection("337-L. Punishment for other hurt","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Whoever causes hurt, not mentioned " +
                        "hereinbefore, which endangers life or which causes the sufferer to remain in severe bodily " +
                        "pain for twenty days or more or renders him unable to follow his ordinary pursuits for " +
                        "twenty days or more, shall be liable to daman and also be punished with imprisonment of " +
                        "either description for a term which may extend to seven years. \n\n" +
                        "(2) Whoever causes hurt not covered by sub-section (1) shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with " +
                        "daman, or with both.");
                mydb2.addsection("337-M. Hurt not liable to qisas","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Hurt shall not be liable to qisas in the following cases, " +
                        "namely:-- \n\n" +
                        "(a) when the offender is a minor or insane: \n\n" +
                        "Provided that he shall be liable to arsh and also to ta'zir to be determined by the Court " +
                        "having regard to the age of offender, circumstances of the case and the nature of hurt " +
                        "caused; \n\n" +
                        "(b) when an offender at the instance of the victim causes hurt to him: \n\n" +
                        "Provided that the offender may be liable to ta'zir provided for the kind of hurt caused by " +
                        "him; \n\n" +
                        "(c) when the offender has caused itlaf-i-udw of a physically imperfect organ of the victim " +
                        "and the convict does not suffer from similar physical imperfection of such organ: \n\n" +
                        "Provided that the offender shall be liable to arsh and may also be liable to ta'zir provided " +
                        "for the kind of hurt caused by him; and \n\n" +
                        "(d) when the organ of the offender liable to qisas is missing: \n\n" +
                        "Provided that the offender shall be liable to arsh and may also be liable to ta'zir provided " +
                        "for the kind of hurt caused by him. \n\n" +
                        "Illustrations \n" +
                        "(i) A amputates the right ear of Z, the half of which was already missing. If A's right ear is " +
                        "perfect, he shall be liable to arsh and not qisas. \n\n" +
                        "(ii) If in (he above illustration, Z's ear is physically perfect but without power of hearing, A " +
                        "shall be liable to qlsas because the defect in Z's ear is not physical. \n\n" +
                        "(iii) lf in illustration (i) Z's ear is pierced, A shall be liable to qisas because such minor " +
                        "defect is not physical imperfection. ");
                mydb2.addsection("337-N. Cases in which qisas for hurt shall not be enforced","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) The qisas for a hurt " +
                        "shall not be enforced in the following cases, namely :- \n\n" +
                        "(a) when the offender dies before execution of qisas; \n\n" +
                        "(6) when the organ of the offender liable to qisas is lost before the execution of qisas: \n\n" +
                        "Provided that offender shall be liable to arsh, and may also be liable to ta'zir provided for " +
                        "the kind of hurt caused by him; \n\n" +
                        "(c) when the victim waives the qisas or compounds the offence with badl-i-sufh; or (o) when the right of qisas devolves on the person who cannot claim qisas against the " +
                        "offender under this Chapter: \n\n" +
                        "Provided that the offender shall be liable to arsh, if there is any wali other than the " +
                        "offender, and if there is no wali other than the offender he shall be liable to ta'zir provided " +
                        "for the kind of hurt caused by him. \n\n" +
                        "(2) Notwithstanding anything contained in this Chapter, in all cases of hurt, the Court may, " +
                        "having regard to the kind of hurt caused by him, in addition to payment of arsh, award " +
                        "ta'zir to an offender who is a previous convict, habitual or hardened, desperate or " +
                        "dangerous criminal. ");
                mydb2.addsection("337- 0. Wali In case of hurt: In the case of hurt","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"The wali shall be- \n\n" +
                        "(a) the victim: \n\n" +
                        "Provided that, if the victim is a minor or insane, his right of qisas shall be exercised by his " +
                        "father or paternal grand father, howhighsoever; \n\n" +
                        "(b) the heirs of the victim, if the later dies before the execution of qisas: and \n\n" +
                        "(c) the Government, in the absence of the victim or the heirs of the victim. \n");
                mydb2.addsection("337-P. Execution of qisas for hurt","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Qisas shall be executed in public by an " +
                        "authorised medical officer who shall before such execution examine the offender and take " +
                        "due care so as to ensure that the execution of qisas does not cause the death of the " +
                        "offender or exceed the hurt caused by him to the victim. \n\n" +
                        "(2) The wali shall be present at the time of execution and if the wali or his representative is " +
                        "not present, after having been informed of the date, time and place by the Court an officer " +
                        "authorised by the Court in this behalf shall give permission for the execution of qisas. \n\n" +
                        "(3) If the convict is a woman who is pregnant, the Court may, in consultation with an " +
                        "authorised medical officer, postpone the execution of qisas upto a period of two years " +
                        "after the birth of the child and during this period she may be released on bail on furnishing " +
                        "of security to the satisfaction of the Court or, if she is not so released, shall be dealt with " +
                        "as if sentenced to simple' imprisonment. ");
                mydb2.addsection("337-Q. Arsh for single organs","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"The arsh for causing itlaf of an organ which Is found " +
                        "singly in a human body shall be equivalent to the value of diyat. \n\n" +
                        "Explanation: Nose and tongue are included in the organs which are found singly in a " +
                        "human body. ");
                mydb2.addsection("337-R. Arsh for organs in pairs","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"The arsh .for causing itlaf of organs found in a human " +
                        "body in pairs shall be equivalent to the value of diyat and if itlaf is caused to one of such " +
                        "organs the amount of arsh shall be one-half of the diyat: \n\n" +
                        "Provided that, where the victim has only one such organ or his other organ is missing or " +
                        "has already 'become incapacitated the arsh for causing itlaf of the existing or capable " +
                        "organ shall be equal to the value of diyat. \n\n" +
                        "Explanation: Hands, feet, eyes, lips and breasts are included in the organs which are " +
                        "found in a human body in pairs. ");
                mydb2.addsection("337-S. Arsh for the organs in quadruplicate","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1)The arsh for causing itlaf of organs " +
                        "found in a human body in a set of four shall be equal to-- \n\n" +
                        "(a) one-fourth of the diyat, if the itlaf is one of such organs; ... \n\n" +
                        "(b) one-half of the diyat, if the itlaf is of two of such organs; . \n\n" +
                        "(c) three-fourth of the diyat, if the itlaf is of three such organs; and \n\n" +
                        "(d) full diyat, if the itlaf is of all the four organs. \n\n" +
                        "Explanation: Eyelids are organs which are found in a human body in a set of four.");
                mydb2.addsection("337-T. Arsh for fingers","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) The arsh for causing itlaf of a finger of a hand or foot shall be " +
                        "one-tenth of the diyat. \n\n" +
                        "(2) The arsh for causing itlaf of a joint of a finger shall be one-thirteenth of the diyat: \n\n" +
                        "Provided that where the itlaf is of a joint of a thumb, the arsh shall be one-twentieth of the " +
                        "diyat. ");
                mydb2.addsection("337-U. Arsh for teeth ","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) The arsh for causing itlaf of a tooth, other than a milk tooth, " +
                        "shall be one-twentieth of the diyat. \n\n" +
                        "Explanation: The impairment of the portion of a tooth outside the gum amounts to causing " +
                        "itlaf of a tooth. \n\n" +
                        "(2) The arsh for causing itlaf of twenty or more teeth shall be equal to the value of diyat. \n\n" +
                        "(3) Where the itlaf is of a milk tooth, the accused shall be liable to daman and may, also " +
                        "be punished with imprisonment of either description for a term which may extend to one " +
                        "year: \n\n" +
                        "Provided that, where itlaf of a milk tooth impedes the growth of. a new tooth, the accused" +
                        "shall be liable to arsh specified in sub-section (1).");
                mydb2.addsection("337-V. Arsh for hair","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Whoever uproots; \n\n" +
                        "(a) all the hair of the head, beard, moustaches eyebrow, eyelashes or any other part of the " +
                        "body shall be liable to arsh equal to diyat and may also be punished with imprisonment of " +
                        "either description for a term which may extend to three years as ta'zir, \n\n" +
                        "(o) one. eyebrow shall be liable to arsh equal to one- half of the diyat; and \n\n" +
                        "(c) one eyelash, shall be liable to arsh equal to one fourth of the diyat \n\n" +
                        "(2) Where the hair of any part of the body of the victim are forcibly removed by any " +
                        "process not covered under sub section (1), the accused shall be liable to daman and " +
                        "imprisonment of either description which may extend to one year. ");
                mydb2.addsection("337-W. Merger of arsh","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Where an accused more than one hurt, he shall be liable to " +
                        "arsh specified for each hurt separately: \n\n" +
                        "Provided that, where; \n\n" +
                        "(a) hurt is caused to an organ, the accused shall be liable to arsh for causing hurt to such " +
                        "organ and not for arsh for causing hurt to any part of such organ and \n\n" +
                        "(b) the wounds join together and form a single wound, the accused shall be liable to arsh " +
                        "for one wound. \n\n" +
                        "Illustrations \n" +
                        "(i) A amputates Z's fingers of the right hand and then at the same time amputates that " +
                        "hand from the joint of his writs. There is separate arsh for hand and for fingers. A shall, " +
                        "however, be liable to arsh specified for hand only. \n\n" +
                        "(ii) A twice stabs Z on his thigh. Both the wounds are so close to each other that they form " +
                        "into one wound. A shall be liable to arsh for one wound only. \n\n" +
                        "(2) Where, after causing hurt to a person, the offender causes death of such person by " +
                        "committing qatl liable to diyat, arsh shall merge into such diyat. \n\n" +
                        "Provided that the death is caused before the healing of the wound caused by such hurt. ");
                mydb2.addsection("337-X. Payment of arsh","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) The arsh may be made payable in a lump sum or in " +
                        "instalments spread over a period of three years from the date of the final judgment. \n\n" +
                        "(2) Where a convict fails to pay arsh or any part thereof within the period specified in sub-section (1), the convict may be kept in jail and dealt with in the same manner as if " +
                        "sentenced to simple imprisonment until arsh is paid in full may be released on bail if he " +
                        "furnishes security equal to amount of arsh to the satisfaction of the Court.\n\n (3) Where a convict dies before the payment of arsh any part thereof, it shall be recovered " +
                        "from his estate. ");
                mydb2.addsection("337-Y. Value of daman","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) The value of daman may be determined by the Court " +
                        "keeping in view:- \n\n" +
                        "(a) the expenses incurred on the treatment of victim; \n\n" +
                        "(b) loss or disability caused in the functioning or power of any organ; and \n\n" +
                        "(c) the compensation for the anguish suffered by the victim. \n\n" +
                        "(2) In case of non-payment of daman, it shall be recovered from the convict and until " +
                        "daman is paid in full to the extent of his liability, the convict may be kept in jail and dealt " +
                        "with in the same manner as if sentenced to simple imprisonment or may be released on " +
                        "bail if he furnishes security equal to the amount of daman to the satisfaction of the Court. ");
                mydb2.addsection("337-Z. Disbursement of arsh or daman","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"The arsh or daman shall be payable to the " +
                        "victim or, if the victim dies, to his heirs according to their respective shares in inheritance. ");
                mydb2.addsection("338. Isqat-i-Hamal","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever causes woman with child whose organs have not been " +
                        "formed, to miscarry, if such miscarriage is not caused in good faith for the purpose of " +
                        "saving the life of the woman, or providing necessary treatment to her, is said to cause " +
                        "isqat-i-haml. \n\n" +
                        "Explanation : A woman who causes herself to miscarry is within the meaning of this \n" +
                        "section. ");
                mydb2.addsection("338-A. Punishment for Isqat-i-haml ","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever cause isqat-i-haml shall be liable to " +
                        "punishment as ta'zir- \n\n" +
                        "(a) with imprisonment of either description for a tern which may extend to three years, if " +
                        "isqat-i-haml is caused with the consent of the woman; or \n\n" +
                        "(b) with imprisonment of either description for a term which may extend to ten years, if " +
                        "isqat-i-haml is caused without the consent of the woman: \n\n" +
                        "Provided that, if as a result of isqat-i-haml, any hurt is caused to woman or she dies, the " +
                        "convict shall also be liable to the punishment provided for such hurt or death as the case " +
                        "may be. ");
                mydb2.addsection("338-B. Isqat-i-janin","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever causes a woman with child some of whose limbs or " +
                        "organs have been formed to miscarry, if such miscarriage is not caused in good faith for " +
                        "the purpose of saving the life of the woman, is said to cause Isqat-i-janin.\n\n Explanation : A woman who causes herself to miscarry is within the meaning of this \n" +
                        "section. ");
                mydb2.addsection("338-C. Punishment for Isqat-i-janin","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Whoever causes isqat-i-ianin sha!l be liable to; " +
                        "(a) one-twentieth of the diyat if the child is born dead; \n\n" +
                        "(b) full diyat if the chitd is born alive but dies as a result of any act of the offender; and \n\n" +
                        "(c) imprisonment of either description for a term which may extend to seven years as " +
                        "ta'zir: \n\n" +
                        "Provided that, if there are more than one child in the womb of the woman, the offender " +
                        "shall be liable to separate diyat or ta'zir, as the case may be/for every such child: \n\n" +
                        "Provided further that if, as a result of isqat-i-fanin, any hurt is caused to the woman or she " +
                        "dies, the offender shall also be liable to the punishment provided for such hurt or death, as " +
                        "the case may be. ");
                mydb2.addsection("338-D. Confirmation of sentence of death by way of qisas or tazir, etc.","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"A sentence of " +
                        "death awarded by way of qisas or ta'zir, or a sentence of qisas awarded for causing hurt, " +
                        "shall not be executed, unless it is confirmed by the High Court. ");
                mydb2.addsection("338-E. Waiver or compounding of offences ","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"(1) Subject to the provisions of this " +
                        "Chapter and Section 345 of the Code of. Criminal Procedure, 1898 (V of 1898), all " +
                        "offences under this Chapter may be waived or compounded and the provisions of " +
                        "Sections 309 and 310 shall, mutatis mutandis, apply to the waiver or compounding of such " +
                        "offences: \n\n" +
                        "Provided that, where an offence has been waived or compounded, the Court may, in its " +
                        "discretion having regard to the facts and circumstances of the case, acquit or award ta'zir " +
                        "to the offender according to the nature of the offence. \n\n" +
                        "(2) All questions relating to waiver or compounding of an offence or awarding of " +
                        "punishment under Section 310, whether before or after the passing of any sentence, shall " +
                        "be determined by trial Court: \n\n" +
                        "Provided that where the sentence of qisas or any other sentence is waived or " +
                        "compounded during the pendency of an appeal, such questions may be determined by the " +
                        "trial Court. ");
                mydb2.addsection("338-F. Interpretation","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"In the interpretation and application of the provisions of this " +
                        "Chapter, and in respect of matter ancillary or akin thereto, the Court shall be guided by the " +
                        "Injunctions of Islam as laid down in the Holy Qur'an and Sunnah. ");
                mydb2.addsection("338-G. Rules","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18," The Government may, in consultation with the Council of Islamic ideology, " +
                        "by notification in the official Gazette, make such rutes as it may consider necessary for " +
                        "carrying out the purposes of this Chapter. ");
                mydb2.addsection("338-H. Saving","OFFENCES AFFECTING THE HUMAN BODY Of offences Affecting Life ",18,"Nothing in this Chapter, except Sections 309. 310 and 338-E. shall apply " +
                        "to cases pending before any Court immediately before the commencement of the Criminal " +
                        "Law (Second Amendment) Ordinance, 1990 (VII of 1990), or to the offences committed " +
                        "before such commencement. \n\n" +
                        "Sections 299 to 338 H subs. by the Criminal Law (Amendment) Act. II of 1997.");
                //chapters 15-A
                mydb2.addchapters("WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT","41","CHAPTER XVI-A");

                mydb2.addsection("339. Wrongful restraint","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever voluntarily obstructs any person so as to prevent that " +
                        "person from proceeding in any direction in which that person has a right to proceed, is " +
                        "said wrongfully to restrain that person. \n\n" +
                        "Exception: The obstruction of a private way over land or water, which a person in good " +
                        "faith believes himself to have a lawful right to obstruct, is not an offence within the " +
                        "meaning of this section. \n\n" +
                        "Illustration \n" +
                        "A obstructs a path along which Z has a right to pass, A not believing in good faith that he " +
                        "has a right to stop the path, Z is thereby prevented from passing. A wrongfully restrains Z. ");
                mydb2.addsection("340. Wrongful confinement","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever wrongfully restrains any person in such a manner " +
                        "as 10 prevent that person from proceeding beyond certain circumscribing limits, is said " +
                        "\"wrongfully to confine\" that person. \n\n" +
                        "Illustrations \n\n" +
                        "(a) A causes Z to go within a walled space, and locks Z in. Z is thus prevented from " +
                        "proceeding in any direction beyond the circumscribing line of wall. A wrongfully confines Z. \n\n" +
                        "(b) A places men with firearms at the outlets of a building, and tells Z that they will fire at Z " +
                        "if Z attempts to leave the building. A wrongfully confines Z. ");
                mydb2.addsection("341. Punishment for wrongful restraint","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever wrongfully restrains any person, shall \n" +
                        "be punished with simple imprisonment for a term, which may extend to one month, or with " +
                        "fine, which may extend to five hundred rupees or with both. ");
                mydb2.addsection("342. Punishment for wrongful confinement","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever wrongfully confines any person, \n" +
                        "shall be punished with imprisonment of either description for, a term, which may extend to \n" +
                        "one year, or with fine which may extend to one thousand rupees or with both.");
                mydb2.addsection("343. Wrongful confinement for three or more days","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever wrongfully confines any \n" +
                        "person, for three days or more, shall be punished with imprisonment of either description \n" +
                        "for a term, which may extend to two years, or with fine, or with both.");
                mydb2.addsection("344. Wrongful confinement for ten or more days","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever wrongfully confines any \n" +
                        "person for ten days or more, shall be punished with imprisonment of either description for \n" +
                        "a term, which may extend to three years, and shall also be liable to fine. ");
                mydb2.addsection("345. Wrongful confinement of person for whose liberation writ, has been issued","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever keeps any person in wrongful confinement, knowing that a writ for the liberation \n" +
                        "of that person has been duly issued, shall be punished with imprisonment of either \n" +
                        "description for a term which may extend to two years, in addition to any term of \n" +
                        "imprisonment to which he may be liable under any other section of this Chapter. ");
                mydb2.addsection("346. Wrongful confinement in secret","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever wrongfully confines any person in such \n" +
                        "manner as to indicate an intention that the confinement of such person may not be known \n" +
                        "to any person interested in the person so confined, or to any public servant, or that the \n" +
                        "place of such confinement may not be known to or discovered by any such person of \n" +
                        "public servant as hereinbefore mentioned, shall be punished with imprisonment of either \n" +
                        "description for a term which may extend to two years in addition to any other punishment \n" +
                        "to which he may be liable for such wrongful confinement. ");
                mydb2.addsection("347. Wrongful confinement to extort property or constrain to illegal act","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever \n" +
                        "wrongfully confines any person for the purpose of extorting from the person confined, or \n" +
                        "from any person interested in the person confined, any property or valuable security or of \n" +
                        "constraining the person confined or any person interested in such person to do anything \n" +
                        "illegal or to give any information which may facilitate the commission of an offence, shall \n" +
                        "be punished with imprisonment of either description for a term which may extend to three \n" +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("348. Wrongful confinement to extort confession or compel restoration of property","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever wrongfully confines any person for the purpose of extorting from the person \n" +
                        "confined or any person interested in the person confined any confession or any \n" +
                        "information which may lead to the detection of an offence or misconduct, or for the \n" +
                        "purpose of constraining the person confined or any person interested in the person \n" +
                        "confined to restore or to cause the restoration of any property or valuable security or to \n" +
                        "satisfy any claim or demand, or to give information which may lead to the restoration of \n" +
                        "any property or valuable security, shall be punished with imprisonment of either \n" +
                        "description for a term which may extend to three years and shall also be liable to fine. ");
                mydb2.addsection("349. Force Of Criminal Force and Assault","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"A person is said to use force to another if he causes motion, change of \n" +
                        "motion, or cessation of motion to that other or if he causes to any substance such motion, \n" +
                        "or change of motion, or cessation of motion as brings that substance into contact with any \n" +
                        "part of that other's body, or with anything which that other is wearing or carrying, or with anything so situated that such contact affects that other's sense of feeling: provided that \n" +
                        "the person causing the motion, or change of motion, or cessation of motion, causes that \n" +
                        "motion, change of motion, or cessation of motion in one of the three ways hereinafter \n" +
                        "described: \n" +
                        "First: By his own bodily power. \n" +
                        "Secondly: By disposing any substance in such a manner that the motion or change or \n" +
                        "cessation of motion takes place without any further act on his part, or on the part of any \n" +
                        "other person. \n" +
                        "Thirdly: By inducing any animal to move, to change its motion, or to cease to move. ");
                mydb2.addsection("350. Criminal force","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever intentionally uses force to any person, without that \n" +
                        "person's consent, in order to the committing of any offence, or intending by the use of \n" +
                        "such force to cause or knowing it to be likely that by the use of such force he wilt cause \n" +
                        "injury, fear or annoyance to the person to whom the force is used, is said to use criminal \n" +
                        "force to that other. \n" +
                        "Illustrations \n" +
                        "(a) Z is sitting in a moored boat on a river. A unfastens the moorings, and thus \n" +
                        "intentionally causes the boat to drift down the stream. Here A intentionally causes motion \n" +
                        "to Z, and he does this by disposing substances in such a manner that the motion is \n" +
                        "produced without any other action on any person's part. A has, therefore, intentionally \n" +
                        "used force to Z; and if he has done so without Z's consent, in order to the committing of \n" +
                        "any offence or intending or knowing it to be likely that this use of force will cause injury, for \n" +
                        "or annoyance to Z, A has used criminal force to Z. \n" +
                        "(b) Z is riding in a chariot, A lashes Z's horses, and thereby cause them to quicken their \n" +
                        "pace. Here A has caused change of motion to Z by inducing the animals to change their \n" +
                        "motion. A has, therefore, used force to Z. and if ,A has done this without Z's consent, \n" +
                        "intending or knowing it to be likely that he may thereby injure, frighten or annoy Z. A has \n" +
                        "used criminal force to Z. \n" +
                        "(c) Z is riding in a palanquin. A, intending to rob Z. seizes the pole and stops the \n" +
                        "palanquin. Here A has caused cessation of motion to Z, and he has done this by his own \n" +
                        "bodily power. A has, therefore, used force to Z and as A has acted thus intentionally \n" +
                        "without Z's consent in order to the commission of an offence A has used criminal force to \n" +
                        "Z. \n" +
                        "(d) A intentionally pushes against Z in the street. Here A has by his own bodily power \n" +
                        "moved his own person so as to bring it into contact with Z. He has therefore, intentionally \n" +
                        "used force to Z; and if he has done so without Z's consent, intending or knowing it to be \n" +
                        "likely that he may thereby injure, frighten or annoy Z. he has used criminal force to Z. (e) A throws a stone, intending or knowing it to be likely that the stone will be thus brought \n" +
                        "into contact with Z. or with Z's clothes, or with something carried by Z or that it will strike \n" +
                        "water, and dash up the water against Z's clothes, or something carried by Z. Here, if the \n" +
                        "throwing of the stone produce the effect of causing any substance to come into contact \n" +
                        "with Z. or, Z's clothes. A has used force to Z: and if he did so without Z's consent intending \n" +
                        "thereby to injure, frighten or annoy Z. he has used criminal force to Z \n" +
                        "(f) A intentionally pulls up a woman's veil. Here A intentionally uses force to her and if he \n" +
                        "does so without her consent intending or knowing it to be likely that he may thereby injure, \n" +
                        "frighten or annoy her he has used criminal force to her. \n" +
                        "(g) Z is bathing. A pours into the bath water which he knows to be boiling. .Here A \n" +
                        "intentionally by his own bodily power causes such motion in the boiling water as brings \n" +
                        "that water into contact with Z, or with other water so situated that such contact must affect \n" +
                        "Z's sense of feeling. A has, therefore, intentionally used force to Z; and if he has done this \n" +
                        "without Z's consent intending or knowing it to be likely that he may thereby cause injury, \n" +
                        "fear or annoyance to Z. A has used criminal force. \n" +
                        "(h) A incites a dog to spring upon Z. without Z's consent. Here, if A intends lo cause injury, \n" +
                        "fear or annoyance to Z, he uses criminal force to Z. ");
                mydb2.addsection("351. Assault","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever makes any gesture, or any preparation intending or knowing it to \n" +
                        "be likely that such gesture or preparation will-cause any person present to apprehend that \n" +
                        "he who makes that gesture or preparation it about to use .of criminal force to that person, \n" +
                        "is said to commit an assault. \n" +
                        "Explanation: Mere words do not amount to an assault, But the words which a person uses \n" +
                        "may give to his gesture or preparation such a meaning as may make those gestures or \n" +
                        "preparations amount to an assault. \n" +
                        "Illustrations \n" +
                        "(a}) A shakes his fist at 2, intending or knowing it to be likely that he may thereby cause Z \n" +
                        "to believe that A is about to strike Z, A has committed an assault. \n" +
                        "(b) A begins to unloose the muzzle of a forcing dog intending, or knowing it to be likely \n" +
                        "that he may thereby cause Z to believe that he is about to cause the dog to attack Z. A \n" +
                        "has committed an assault upon Z. \n" +
                        "(c) A takes up a stick, saying to Z. \"I will give you a beating.\" Here, though the words used \n" +
                        "by A could in no case amount to an assault, and though the mere gesture accompanied \n" +
                        "by any other circumstances might not amount to an assault, the gesture explained by the \n" +
                        "words may amount to an assault. ");
                mydb2.addsection("352. Punishment for assault or criminal force otherwise than on grave provocation","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever assaults or uses criminal force to any person otherwise than on grave and \n" +
                        "sudden provocation given by that, person, shall be punished with imprisonment of either description for a term which may extend to three months, or with fine which may extend to \n" +
                        "five hundred rupees, or with both. \n" +
                        "Explanation: Grave and sudden provocation will not mitigate the punishment for the \n" +
                        "offence under this section, if the provocation is sought or voluntarily provoked by the \n" +
                        "offender as ah excuse for the offence, or \n" +
                        "if the provocation is given by anything done in obedience to the law or by, a public \n" +
                        "servant, in the lawful exercise of the powers such public servant, or \n" +
                        "if the provocation is given by anything done in the lawful exercise of the right of private \n" +
                        "defence. \n" +
                        "Whether the provocation was grave and sudden enough to mitigate the offence, is a \n" +
                        "question of fact. ");
                mydb2.addsection("353. Assault or criminal force to deter public servant from discharge of his duty","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever assaults or uses criminal force to any person being a public servant in the \n" +
                        "execution of his duty as such public servant, or with intent to prevent or deter that person \n" +
                        "from discharging his duty as such public servant, or in consequence of anything done or \n" +
                        "attempted to be done by such person in the lawful discharge of his duty as such public \n" +
                        "servant, shall be punished with imprisonment of either description for a term which may \n" +
                        "extend to two years, or with fine or with both.");
                mydb2.addsection("354. Assault or criminal force to woman with intent to outrage her modesty","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever assaults or uses criminal force to any woman, intending to outrage or knowing it \n" +
                        "to be likely that he will thereby outrage her modesty, shall be punished with imprisonment \n" +
                        "of either description for a term which may extend to two years or with fine, or with both. ");
                mydb2.addsection("354-A. Assault or use of criminal force to woman and stripping her of her clothes","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever assaults or use criminal force to any woman and strips her of her clothes and in \n" +
                        "that condition, exposes her to the public view, shall be punished with death or with \n" +
                        "imprisonment for life, and shall also be liable to fine. \n" +
                        "Sec- 354-A Ins., by the Criminal Law (Amend.) Ordinance, XXIV of 1984. ");
                mydb2.addsection("355. Assault or criminal force with intent to dishonour person, otherwise than on \n" +
                        "grave provocation","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever assaults or uses criminal force to any person, intending \n" +
                        "thereby to dishonour that person, otherwise than on grave and sudden provocation given \n" +
                        "by that person, shall be punished with imprisonment of either description for a term which \n" +
                        "may extend to two years, or with fine, or with both. ");
                mydb2.addsection("356. Assault or criminal force in attempt to commit theft of property carried by a \n" +
                        "person","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever assaults or uses criminal force to any person in attempting to commit \n" +
                        "theft on any property which that person is then wearing or carrying shall be punished with \n" +
                        "imprisonment of either description for a term which may extend to two years, or with fine, \n" +
                        "or with both. ");
                mydb2.addsection("357. Assault or criminal force in attempting wrongfully to confine person","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever \n" +
                        "assaults or uses criminal force to any person, in attempting wrongfully to confine that \n" +
                        "person, shall be punished with imprisonment of either description for a term which may \n" +
                        "extend to one year or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("358. Assault or criminal force on grave provocation","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever assaults or uses \n" +
                        "criminal force to any person on grave and sudden provocation given by that person, shall \n" +
                        "be punished with simple imprisonment for a term which may extend to one month or with \n" +
                        "fine which may extend to two hundred rupees, or with both. \n" +
                        "Explanation: The last section is subject to the same explanation as Section 352.");
                mydb2.addsection("359. Kidnapping","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Kidnapping is of two kinds: Kidnapping from Pakistan and \n" +
                        "kidnapping from lawful guardianship. ");
                mydb2.addsection("360. Kidnapping from Pakistan, etc.","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever conveys any person beyond the limits \n" +
                        "of Pakistan without the consent of that person, or of some person legally authorised to \n" +
                        "consent on behalf of that person is said to kidnap that person from Pakistan. ");
                mydb2.addsection("361. Kidnapping from lawful guardianship","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever takes or entices any minor under \n" +
                        "fourteen years of age if a male, or under sixteen years of age if a female, or any person of \n" +
                        "unsound mind, out of the keeping of the lawful guardian of such minor or person of \n" +
                        "unsound mind, without the consent of such guardian, said to kidnap such minor or person \n" +
                        "from lawful guardianship. \n" +
                        "Explanation: The words \"lawful guardian\" in this section include any person lawfully \n" +
                        "entrusted with the care or custody of such minor or other person. \n" +
                        "Exception: This section does not extend to the act of any person who in good faith \n" +
                        "believes himself to be the father of an illegitimate child or who in good faith believes \n" +
                        "himself to be entitled to the lawful custody of such child, unless such act is committed for \n" +
                        "an immoral or unlawful purpose. ");
                mydb2.addsection("362. Abduction","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever by force compels, or by any deceitful means induces, any \n" +
                        "person to go from any place, is said to abduct that person.");
                mydb2.addsection("363. Punishment for kidnapping","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever kidnaps any person from Pakistan or from \n" +
                        "lawful guardianship, shall be punished with imprisonment of either description for a term \n" +
                        "which may extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("364. Kidnapping or abducting in order to murder","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever kidnaps or abducts \n" +
                        "any person in order that such person may be murdered or may be so disposed of as to be \n" +
                        "put in danger of being murdered, shall be punished with imprisonment for life or rigorous \n" +
                        "imprisonment for a term which may extend to ten years and shall also be liable to fine, Illustrations \n" +
                        "(a) A kidnaps Z from Pakistan, intending or knowing it to be likely that Z may be sacrificed \n" +
                        "to an idol. A has committed the offence defined in this section. \n" +
                        "(b) A forcibly carries or entices 5 away from his home in order that B may be murdered. A \n" +
                        "has committed the offence defined in this section. ");
                mydb2.addsection("364-A. Kidnapping or abducting a person under the age of fourteen","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever \n" +
                        "kidnaps or abducts any person under the i[age of fourteen] in order that such person may \n" +
                        "be murdered or subjected to grievous hurt, or slavery, or to the lust of any person or may \n" +
                        "be so disposed of as to be put in danger of being murdered or subjected to grievous hurt, \n" +
                        "or slavery, or to the lust of any person shall be punished with death or with imprisonment \n" +
                        "for life or with rigorous imprisonment for a term which may extend to fourteen years and \n" +
                        "shall not be less than seven years. ");
                mydb2.addsection("365. Kidnapping or abducting with intent secretly and wrongfully to confine person","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever kidnaps or abducts any person with intent to cause that person to be secretly \n" +
                        "and wrongfully confined, shall be punished with imprisonment of either description for a \n" +
                        "term which may extend to seven years, and shall also be liable to fine\u0002");
                mydb2.addsection("365-A. Kidnapping or abducting for extorting property, valuable security, etc.","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever kidnaps or abducts any person for the purpose of extorting from the person \n" +
                        "kidnapped or abducted, or from any person interested in the person kidnapped or \n" +
                        "abducted any property, whether movable or immovable, or valuable security, or to compel \n" +
                        "any person to comply with any other demand, whether in cash or otherwise, for obtaining \n" +
                        "release of the person kidnapped or abducted, shall be punished with death or \n" +
                        "imprisonment for life and shall also be liable to forfeiture of property. \n" +
                        "S. 365-A added by the Criminal Law (Amendment) Act, III of 1990, \n" +
                        "366. Kidnapping, abducting or inducing woman to compel her marriage, etc.: [Rep. by the \n" +
                        "Offence of Zina (Enforcement of Hudood) Ordinance, Vfl of 1979, S. 19.] ");
                mydb2.addsection("366-A. Procuration of minor girl","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever by any means whatsoever, induces any \n" +
                        "minor girl under the age of eighteen years to go from any place or to do any act with intent \n" +
                        "that such girl may be, or knowing that it is likely that she will be, forced or seduced to illicit \n" +
                        "intercourse with another person shall be punishable with imprisonment which may extend \n" +
                        "to ten years and shall also be liable to fine. \n" +
                        "Sec. 366-A ins, by the Penal Code (Amendment) Act, XX of 1923. ");
                mydb2.addsection("366-B. Importation of girl from foreign country ","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever imports into Pakistan from \n" +
                        "any country outside Pakistan any girl under the age of twenty-one years with intent that \n" +
                        "she may be, or knowing it to be likely that she will be, forced or seduced to illicit \n" +
                        "intercourse with another person, shall be punishable with imprisonment which may extend \n" +
                        "to ten years and shall also be liable to fine. \n" +
                        "Sec. 366-B subs. by the Federal Laws (Revision and Declaration) Ordinance. XXVII of 1981.");
                mydb2.addsection("367. Kidnapping or abducting in order to subject person to grievous hurt, slavery, \n" +
                        "etc.","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever kidnaps or abducts any person in order that such person may be subjected, \n" +
                        "or may be so disposed of as to be put in danger of being subjected to grievous hurt, or \n" +
                        "slavery or knowing it to be likely that such person will be so subjected or disposed of shall \n" +
                        "be punished with imprisonment of either description for a term which may extend to ten \n" +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("368. Wrongfully concealing or keeping in confinement, kidnapped or abducted \n" +
                        "person","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever knowing that any person has been kidnapped or has been abducted \n" +
                        "wrongfully conceals or confines such person shall be punished in the same manner as if \n" +
                        "he had kidnapped or abducted Such person with the same intention or knowledge, or for \n" +
                        "the same purposes as that with or for which he conceals or detains such person in \n" +
                        "confinement. ");
                mydb2.addsection("369. Kidnapping or abducting child under ten years with intent to steal from its \n" +
                        "person ","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19," Whoever kidnaps or abducts any child under the age of ten years with the \n" +
                        "intention of taking dishonestly any movable property from the person of such child, shall \n" +
                        "be punished with imprisonment of either description for a term which may extend to seven \n" +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("370. Buying or disposing of any person as a slave","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever imports, exports, \n" +
                        "removes, buys, sells or disposes of any person as a slave, or accepts, receives or detains \n" +
                        "against his will any person as a slave, shall be punished with imprisonment of either \n" +
                        "description for a term which may extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("371. Habitual dealing in slaves","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever habitually imports, exports, removes, buys, \n" +
                        "sells, traffics or deals in slaves. Shall be punished with imprisonment for life, or with \n" +
                        "imprisonment of either description for a term not exceeding ten years, shall also be liable \n" +
                        "to fine.");
                mydb2.addsection("372. Selling minor for purposes of prostitution, etc.","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"[Repealed by the Offence of Zina \n" +
                        "(Enforcement of Hudood) Ordinance, VII of 1979, S. 19.] ");
                mydb2.addsection("373. Buying minor for purposes of prostitution, etc.","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"[Repealed by the Offence of Zina \n" +
                        "(Enforcement of Hudood) Ordinance, VII of 1979, S. 19.] ");
                mydb2.addsection("374. Unlawful compulsory labour","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"(1) Whoever unlawfully compels any person to labour \n" +
                        "against the will of that person, shall be punished with imprisonment of either description \n" +
                        "for a term which may extend to 1 [five] years or with fine, or with both. \n" +
                        "(2) Whoever compels a prisoner of war or a protected person to serve in the armed forces \n" +
                        "of Pakistan shall be punished with imprisonment of either description for a term which may \n" +
                        "extend to one year. \n" +
                        "Explanation: In this section the expression \"prisoner of war\" and \"protected person\" shall \n" +
                        "have the same meanings as have been assigned to them respectively by Article 4 of the Geneva Convention Relative to the Treatment of Prisoners of War of August 12, 1949, \n" +
                        "and Article 4 of the Geneva Convention Relative to the Protection of Civilian Persons in \n" +
                        "Time of War of August 12, 1949, ratified by Pakistan on the second June, 1951]. ");
                mydb2.addsection("375. Rape Of Rape","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"[Repealed by • the Offence of Zina (Enforcement of Hudood) Ordinance, VII of \n" +
                        "1979, S. 19]. ");
                mydb2.addsection("376. Punishment of rape","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"[Repealed by the Offence of Zina (Enforcement of Hudood) \n" +
                        "Ordinance, VII of 1979, S. 19]. ");
                mydb2.addsection("377. Unnatural offences Of Unnatural Offences ","WRONGFUL RESTRAINT & WRONGFUL CONFINEMENT",19,"Whoever voluntarily has carnal intercourse against the order of \n" +
                        "nature with any man, woman or animal, shall be punished with imprisonment for life, or \n" +
                        "with imprisonment of either description for a term which shall not be less than two years \n" +
                        "nor more than ten years, and shall also be liable to fine. \n" +
                        "Explanation: Penetration is sufficient to constitute the carnal intercourse necessary to the \n" +
                        "offence described in this section. ");

                //chapters 16
                mydb2.addchapters("OFFENCES AGAINST PROPERTY Of Theft","81","CHAPTER XVII");

                mydb2.addsection("378. Theft","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, intending to take dishonestly any movable property out of the " +
                        "possession of any person without that person's consent, moves that property in order to " +
                        "such taking, is said to commit theft. \n\n" +
                        "Explanation 1: A thing so long as it is attached to the earth, not being movable property, is " +
                        "not the subject of theft; but it becomes capable of being the subject of theft as soon as it is " +
                        "served from the earth. \n\n" +
                        "Explanation 2: A moving effected by the same act which effects the severance may be a " +
                        "theft. \n\n" +
                        "Explanation 3: A person is said to cause a thing to move by removing an obstacle, which " +
                        "prevented it from moving, or by separating it from any other thing, as well as by actually " +
                        "moving it, Explanation 4: A person, who by any means causes an animal to move, is said to move " +
                        "that animal, and to move everything which, in consequence of the motion so caused, is " +
                        "moved by that animal. \n\n" +
                        "Explanation 5: The consent mentioned in the definition may be express or implied, and " +
                        "may be given either by the person in possession, or by any person having for that purpose " +
                        "authority either express or implied. \n\n" +
                        "Illustrations \n\n" +
                        "(a) A cuts down a tree on Z's ground with the intention of dishonestly taking the tree out of " +
                        "Z's possession without Z's consent. Here, as soon as A has severed the tree in order to " +
                        "such taking, the has committed theft. \n\n" +
                        "(b) A puts a bait for dogs in his pockets, and thus induces Z's dog to follow it. Here if A's " +
                        "intention be dishonestly to take the dog out of Z's possession without Z's consent A has " +
                        "committed theft as soon as Z's dog has begun to follow A. \n\n" +
                        "(c) A meets a bullock carrying a box of treasure. He drives the bullock in a certain " +
                        "direction, in order that he may dishonestly take the treasure. As soon as the bullock " +
                        "begins to move, A has committed theft of the treasure. \n\n" +
                        "(d) A being Z's servant and entrusted by Z with the care of Z's plate, dishonestly runs " +
                        "away with the plate, without Z's consent. A has committed theft. \n\n" +
                        "(e) Z. going on a journey, entrusts his plate to A the keeper of a warehouse, till Z shall " +
                        "return. A carries the plate to a goldsmith and sells it. Here the plate was not in 2's " +
                        "possession. It could not, therefore, be taken out of Z's possession, and A has not " +
                        "committed theft though he may have committed criminal breach of trust. \n\n" +
                        "(f) A finds a ring belonging to Z on a table in the house which Z occupies. Here the ring in " +
                        "Z's possession, and if A dishonestly removes it. A commits theft. \n\n" +
                        "(g) A finds a ring lying on the high-road, not in the possession of any person. A. by taking " +
                        "it, commits no theft, though he may commit criminal misappropriation of property, \n\n" +
                        "(h) A sees a ring belonging to Z lying on a table in Z's house. Not venturing to " +
                        "misappropriate the ring immediately for fear of search and detection A hides the ring in a " +
                        "place where it is highly improbable that it will ever be found by Z. with the intention of " +
                        "taking the ring from the hiding place and soiling it when the toss is forgotten Here A. at the " +
                        "time of first moving the ring, commits the theft. \n\n" +
                        "(i) A delivers his watch to Z, a jeweller to be regulated. Z carries it to his shop. A, not " +
                        "owing to the jeweller, any debt for which the jewellers might lawfully detain the watch as a " +
                        "security, enters the shop openly, takes his watch by force out of Y's hand, and carries it " +
                        "away. Here A. though he may have committed criminal trespass and assault, has not " +
                        "committed theft, inasmuch as what he did was not done dishonestly.\n\n (j) If A owes money to Z for repairing the watch, and if Z retains the watch lawfully as a " +
                        "security for the debt, and A takes the watch out of Z's possession, with the intention of " +
                        "depriving Z of the property as security for his debt. he commits theft, inasmuch as he " +
                        "takes it dishonestly. \n\n" +
                        "(k) Again, if A. having pawned his. watch to Z, takes it of Z's possession without Z's " +
                        "consent not having paid what he borrowed on the watch, he commits theft, though the " +
                        "watch is his own property inasmuch as he takes it dishonestly. \n\n" +
                        "(l) A takes an article belonging to Z out of Z's possession without Z's consent, with the " +
                        "intention of keeping it until he obtains money from Z as a reward for its restoration Here A " +
                        "takes dishonestly: A has. therefore, committed theft. \n\n" +
                        "(m) A being on friendly terms with Z, goes to Z's library in Z's absence, and takes away a " +
                        "book without Z's express consent for the purpose merely of reading it. and with the " +
                        "intention of returning it. Here, it is probable that A may have conceived that he had Z's " +
                        "implied consent to use Z's book. If this was A's impression, A .has not committed theft \n\n" +
                        "(n) A asks charity from Z's wife. She gives A money, food and clothes, which A knows to " +
                        "belong to her husband. Here it is probable that A may conceive that Z's wife is authorised " +
                        "to give away alms. If this was A's impression. A has not committed theft. \n\n" +
                        "(o) A is the paramour of Z's wife. She gives A valuable property, which A knows to belong " +
                        "to her husband Z, and to be such property as she has no authority from Z to give. If A " +
                        "takes the property dishonestly, he commits theft. \n\n" +
                        "(p) A. in good faith believing property belonging to Z to be A's own property, takes that " +
                        "property out of S's possession. Here, as A does not take dishonestly, he does not commit " +
                        "theft. ");
                mydb2.addsection("379. Punishment for theft","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits theft shall be punished with imprisonment " +
                        "of either description for a term which may extend to three years, or with fine, or with both. ");
                mydb2.addsection("380. Theft in dwelling house, etc.","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits theft in any building, tent or vessel, " +
                        "which building, tent or vessel is used as a human dwelling, or used for the custody of " +
                        "property shall be punished with imprisonment of either description for a term which may " +
                        "extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("381. Theft by clerk or servant or property in possession of master","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever being a " +
                        "clerk or servant, or being employed in the capacity of a clerk or servant, commits theft in " +
                        "respect of any property in the possession of his master or-employer, shall be punished " +
                        "with imprisonment of either description for a term which may extend to seven years, and " +
                        "shall also be liable to fine. ");
                mydb2.addsection("381-A. Theft of a car or other motor vehicles","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits theft of a car or any " +
                        "other motor vehicle, including motor-cycle, scooter and Tractor shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years and with " +
                        "fine not exceeding the value of the stolen car or motor vehicle. \n\n" +
                        "Explanation : Theft of an electric motor of a tube-well or transformer shall be within the " +
                        "meaning of this section. \n\n" +
                        "S. 381 A added by the Criminal Law (Amdt). Act, I of 1996. ");
                mydb2.addsection("382. Theft after preparation made for causing death, hurt or restraint in order to the " +
                        "committing of the theft","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, commits theft, having made preparation for causing " +
                        "death, or hurt, or restraint, or fear of death, or of hurt, or of restraint, to any person, in " +
                        "order to the committing of such theft, or in order to the effecting of his escape after the " +
                        "committing of such theft, or in order to the retaining of property' taken by such theft, shall " +
                        "be punished with rigorous imprisonment for a term, which may extend to ten years, and " +
                        "shall also be liable to fine. \n\n" +
                        "Illustrations \n" +
                        "(a.) A commits theft on property in Z's possession: and, while committing this theft, hff1 " +
                        "has a loaded pistol under his garment having provided this pistol for the purpose of hurting " +
                        "Z in case Z should resist. A has committed the offence defined in this section. \n\n" +
                        "(b) A picks Z's pocket, having posted several of his companions near him, in order that " +
                        "they may restrain Z. if Z should perceive what is passing and should resist, or should " +
                        "attempt to apprehend A. A has committed the offence defined in this section. \n");
                mydb2.addsection("383. Extortion Of Extortion","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever intentionally puts any person in fear of any injury to that person, " +
                        "or to any other, and thereby dishonestly induces the person so put in fear to deliver to any " +
                        "person any property or valuable security or anything signed or sealed which may be " +
                        "converted into a valuable security, commits \"extortion\". \n\n" +
                        "Illustrations \n" +
                        "(a) A threatens to publish a defamatory libel concerning Z unless Z gives him money. He " +
                        "thus induces Z to give him money. A has committed extortion. \n\n" +
                        "(b) A threatens Z that he will keep Z's child in wrongful confinement, unless Z will sign and " +
                        "deliver to A a promissory-note binding Z, to pay certain money to A. Z signs and delivers " +
                        "the note. A has committed extortion. \n\n" +
                        "(c) A threatens to send club-men to plough up Z's field unless A will sign and deliver to 6 a " +
                        "bond binding Z under a penalty to deliver certain produce to B, and thereby induces Z to " +
                        "sign and deliver the bond. A has committed extortion.\n\n (d) A, by putting Z in fear of grievous hurt, dishonestly induces Z to sing or affix his seal to " +
                        "a blank paper and deliver it to A. Z signs and delivers the paper to A. Here, as the paper " +
                        "so signed may be converted into a valuable security, A has committed extortion. ");
                mydb2.addsection("384. Punishment for extortion","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, commits extortion shall be punished with " +
                        "imprisonment of either description for a term which may extend to three years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("385. Putting person in fear of injury in order to commit extortion","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, in order " +
                        "to the committing of extortion, puts any, person in fear, or attempts to put any person in " +
                        "fear, of any injury, shall be punished with imprisonment of either description for a term " +
                        "which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("386. Extortion by putting a person in fear of death or grievous hurt","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "commits extortion by putting any person in fear of death or of grievous hurt to that person " +
                        "to any other, shall be punished with imprisonment of either description for a term which " +
                        "may extend to ten years and shall also be liable to fine. ");
                mydb2.addsection("387. Putting person in fear of death or of grievous hurt, in order to commit " +
                        "extortion","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, in order to the committing of extortion, puts or attempts to put any " +
                        "person in fear of death or of grievous hurt to that person or to any Other, shall be " +
                        "punished with imprisonment of either description for a term which may extend to seven " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("388. Extortion by threat of accusation of an offence punishable with death or " +
                        "imprisonment for life, etc.","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits extortion by putting any person in fear of " +
                        "an accusation against that person or any other, of having committed or attempted to " +
                        "commit any offence punishable with death, or with imprisonment for life, with " +
                        "imprisonment for a term which may extend to ten years, or of having attempted to induce " +
                        "any other person to commit such offence, shall be punished with imprisonment of either " +
                        "description for a term which may extend to ten years, and shall also be liable to fine;\n\n " +
                        "and, if the offence be one punishable under Sec. 377 of this Code, may be punished with " +
                        "imprisonment for life. ");
                mydb2.addsection("389. Putting person in fear of accusation of offence, in order to commit extortion","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, in order to the committing of extortion, puts or attempts to put any person in fear " +
                        "of an accusation, against that person or any other, of having committed, or attempted to " +
                        "commit, commit an offence punishable with death or With imprisonment for life, or " +
                        "imprisonment for a term which may extend to ten years, shall be punished with " +
                        "imprisonment of either description for a term which may extend to ten years, and shall " +
                        "also be liable to fine, and, if the offence be one punishable under Sec. 377 of this Code, " +
                        "may be punished with imprisonment for life.");
                mydb2.addsection("390. Robbery Of Robbery and Dacoity","OFFENCES AGAINST PROPERTY Of Theft",20,"In all robbery there is either theft or extortion. \n\n" +
                        "When theft is robbery:\n" +
                        " Theft is \"robbery\" if, in order to the committing of the theft, or in " +
                        "committing the theft, or in carrying away or attempting to carry away property obtained by " +
                        "the theft, the offence, for that end, voluntarily causes or attempts to cause to any person " +
                        "death or hurt, or wrongful restraint, or fear of instant death or of instant hurt or of instant " +
                        "wrongful restraint. \n\n" +
                        "When extortion is robbery \n: Extortion is \"robbery\" if the offender, at the time of " +
                        "committing the extortion, is in the presence of the person put in fear, and commits the " +
                        "extortion by putting that person in fear of instant death, of instant hurt, or of instant " +
                        "wrongful restraint to that person, or to some other person, and by so putting in fear; " +
                        "induces the person so put in fear then and there to deliver up the thing extorted. \n\n" +
                        "Explanation: The offender is said to be present if he is sufficiently near to put the other " +
                        "person in fear of instant death, of instant hurt, or of instant wrongful restraint. \n\n" +
                        "Illustrations \n" +
                        "(a) A holds Z down, and fraudulently takes Z's money and jewels from Z's clothes, without " +
                        "Z's consent. Here A has committed theft, and in order to the committing of that theft, has " +
                        "voluntarily caused wrongful restraint to Z. A has therefore committed robbery; \n\n" +
                        "(b) A meets Z on the high road, shows a pistol, and demands Z's purse. 2, in " +
                        "consequence, surrender his purse. Here A has extorted the purse from Z by putting him in " +
                        "fear of instant hurt and being at the time of committing the extortion in his presence.\" A " +
                        "has therefore committed robbery. \n\n" +
                        "(c) A meets Z and Z's child on the high road. A takes the child, and threatens to filing it " +
                        "down a precipice, unless Z delivers his purse. Z, in consequence, delivers his purse. Here " +
                        "A has extorted the purse from Z, by causing Z to be in fear of instant hurt to the child who " +
                        "is there present, A has, therefore, committed robbery on Z. \n\n" +
                        "(d) A obtains property from Z by saying Your child is in the hands of my gang, and will be " +
                        "put to death unless you send us ten thousand rupees\". This is extortion, punishable as " +
                        "such; but it is not robbery, unless Z is put in fear of the instant death of his child. ");
                mydb2.addsection("391. Dacoity","OFFENCES AGAINST PROPERTY Of Theft",20,"When five or more persons conjointly commit or attempt to commit a " +
                        "robbery, or where the whole number of persons conjointly committing or attempting to " +
                        "commit a robbery and persons present and aiding such commission or attempt, amount to " +
                        "five or more, every person so committing, attempting or aiding is said to commit \"dacoity\". ");
                mydb2.addsection("392. Punishment for robbery","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits robbery shall be punished with rigorous " +
                        "imprisonment for a term which shall not be less than three years nor more than ten years, " +
                        "and shall also be liable to fine ; and, if the robbery be committed on the highway the " +
                        "imprisonment may be extended to fourteen years. ");
                mydb2.addsection("393. Attempt to commit robbery","OFFENCES AGAINST PROPERTY Of Theft",20," Whoever attempts to commit robbery shall be " +
                        "punished with rigorous imprisonment for a term, which may extend to seven years, and " +
                        "shall be liable to fine.");
                mydb2.addsection("394. Voluntarily causing hurt in committing robbery","OFFENCES AGAINST PROPERTY Of Theft",20,"If any person, in committing or in " +
                        "attempting to commit robbery, voluntarily causes hurt, such person, and any other person " +
                        "jointly concerned in committing or attempting to commit such robbery, shall be punished " +
                        "with imprisonment for life, or with rigorous imprisonment for a term which shall not be less " +
                        "than four years nor more than ten years, and shall also be liable to fine. ");
                mydb2.addsection("395. Punishment for dacoity","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits dacoity shall be punished with " +
                        "imprisonment for life, or with rigorous imprisonment for a term which shall not be less than " +
                        "four years nor more than ten years and shall also be liable to fine.");
                mydb2.addsection("396. Dacoity with murder","OFFENCES AGAINST PROPERTY Of Theft",20,"If any one of five or more persons, who are conjointly " +
                        "committing dacoity, commits murder in so committing dacoity, everyone of those persons " +
                        "shall be punished with death, or imprisonment for life, or rigorous imprisonment for a term " +
                        "which 2[shall not be less than four years nor more than] ten years, and shall also be liable " +
                        "to fine. ");
                mydb2.addsection("397. Robbery or dacoity, with attempt to cause death or grievous hurt ","OFFENCES AGAINST PROPERTY Of Theft",20,"If, at the time " +
                        "of committing robbery or dacoity, the offender uses any deadly weapon, or causes " +
                        "grievous hurt to any person or attempts to cause death or grievous hurt to any person the " +
                        "imprisonment with which such offender shall be punished shall not be less than seven " +
                        "years. ");
                mydb2.addsection("398. Attempt to commit robbery or dacoity when armed with deadly weapon","OFFENCES AGAINST PROPERTY Of Theft",20,"If, at " +
                        "the time of attempting to commit robbery or dacoity, the offender is armed with any deadly " +
                        "weapon, the imprisonment with which such offender shall be punished shall not be less " +
                        "than seven years.");
                mydb2.addsection("399. Making preparation to commit dacoity","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever makes any preparation for " +
                        "committing dacoity, shall be punished with rigorous imprisonment for a term which may " +
                        "extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("400. Punishment for belonging to gang of dacoits","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, at any time after the " +
                        "passing of this Act, shall belong to a gang of persons associated for the purpose of " +
                        "habitually committing dacoity, shall be punished with imprisonment for life, or with rigorous " +
                        "imprisonment for a term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("401. Punishment for belonging to gang of thieve","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, at any time after the " +
                        "passing of this Act, shall belong to any wandering or other gang of persons associated for " +
                        "the purpose of habitually committing theft or robbery, and not being of thugs or dacoits, " +
                        "shall be punished with rigorous imprisonment for a term which may extend to seven years, " +
                        "and shall also be liable to fine. ");
                mydb2.addsection("402. Assembling for purpose of committing dacoity","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, at any time after the " +
                        "passing of this Act shall be one of five or more persons assembled for the purpose of " +
                        "committing dacoity, shall be punished with rigorous imprisonment for a term which may " +
                        "extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("402-A. Hijacking Of Hijacking","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever unlawful, by the use or show of force or by threats of any " +
                        "kind, seizes, or exercised control of, an aircraft is said to commit hijacking. ");
                mydb2.addsection("402-B. Punishment for Hijacking","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits, or conspires or attempts' to " +
                        "commit, or abets the commission of, hijacking shall be punished with death or " +
                        "imprisonment for life, and shall also be liable to forfeiture of property and fine. ");
                mydb2.addsection("402-C. Punishment for harbouring hijacking, etc.","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever knowingly harbours any " +
                        "person whom he knows or has reason to be a person who is about to commit or has " +
                        "committed or abetted an offence of hijacking, or knowingly permits any such persons to " +
                        "meet or assemble in any place or premises in his possession or under his control, shall be " +
                        "punished with death or imprisonment for life, and shall also be liable to fine. \n\n" +
                        "Sections 402-B &. 402-C ins. by the Pakistan Penal Code (Second Amendment) Ordinance. XXX of 1981, Section 2.");
                mydb2.addsection("403. Dishonest misappropriation of property","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever dishonestly misappropriates or \n" +
                        "converts to his own use any ' movable property, shall be punished with imprisonment of " +
                        "either description for a term which may extend to two years, or with fine, or with both. \n\n" +
                        "Illustrations \n" +
                        "(a) A tapes property belonging to Z out of Z's possession in good faith, believing, at the " +
                        "time when he takes it, that the property belongs to himself, A is not guilty of theft; but if A, " +
                        "after discovering his mistakes, dishonestly appropriates the property to his own use, he is " +
                        "guilty of an offence under this section. \n\n" +
                        "(b) A, being on friendly terms with Z, goes into Z's library in Z's absence, and takes away " +
                        "a book without Z's express consent- Mere, if A was under the impression that he had Z's " +
                        "implied consent to take the book for the purpose of reading it, A has not committed theft " +
                        "But, if A afterwards sells the book for his own benefit, he is guilty of an offence under this " +
                        "section. \n\n" +
                        "(c) A and B, being joint owners of a horse. A takes the horse out of B's possession, " +
                        "Intending to use it. Here as A has a right to use the horse he does not dishonestly " +
                        "misappropriate it. But, if A sells the horse and appropriates the whole proceeds to his own " +
                        "use, he is guilty of an offence under this section. \n\n" +
                        "Explanation 1 : A dishonest misappropriation for a time only is a misappropriation within " +
                        "the meaning of this section.\n\n Illustration \n" +
                        "A finds a Government promissory-note belonging to Z, bearing a blank endorsement. A " +
                        "knowing that the note belongs to Z, pledges it with a banker as a security for a loan, " +
                        "intending at a future time to restore it to Z A has committed an offence under this section. \n\n" +
                        "Explanation 2 : A person who finds property not in the possession of any other person, " +
                        "and takes such property for the purpose of protecting it for, or of restoring it to, the owner, " +
                        "does not take or misappropriate it dishonestly, and is not guilty of an offence; but he is " +
                        "guilty of the offence above defined, if he appropriates it to his own use, when he knows or " +
                        "has the means of discovering the owner, or before he has used reasonable means to " +
                        "discover and give notice to the owner and has kept the property a reasonable time to " +
                        "enable the owner to claim it. \n\n" +
                        "What are reasonable means or what is a reasonable time in such a case, is a question of " +
                        "fact. \n\n" +
                        "It is not necessary that the finder should know who is the owner of the property, or that " +
                        "any particular person is the owner of it, is sufficient if, at the time of appropriating it, he " +
                        "does not believe it to be his own property, or in good faith believes that the real owner " +
                        "cannot be found. \n\n" +
                        "Illustrations \n" +
                        "(a) A finds a rupee on the high-road, not knowing to whom the rupee belongs. A picks up " +
                        "the rupees. Here A has not committed the offence defined in this section. \n\n" +
                        "(b) A finds a letter on the road, containing a bank note. From the direction and contents of " +
                        "the letter he learns to whom the note belongs. He appropriate the note. He is guilty of an " +
                        "offence under this section. \n\n" +
                        "(c) A finds a cheque payable to bearer. He can form no conjecture as to the person who " +
                        "has lost the cheque. But the name of the person, who has drawn the cheque, appear, A " +
                        "knows that this person can direct him to the person on whose favour the cheque was " +
                        "drawn. A appropriates the cheque without attempting to discover the owner. He is guilty of " +
                        "an offence under this section. \n\n" +
                        "(d) A sees Z drop his purse with money In it, A picks up the purse with the intention of " +
                        "restoring it to Z, but afterwards appropriates It to his own use, A has committed an offence " +
                        "under this section. ");
                mydb2.addsection("404. Dishonest misappropriation of property possessed by deceased person at " +
                        "the time of his death","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever dishonestly misappropriates or converts to his own use " +
                        "properly, knowing that such property was in the possession of a deceased person at the " +
                        "time of that person decease, and has not since been in the possession of any persons " +
                        "legally entitled to such possession, shad be punished with imprisonment of either " +
                        "description for a term which may extend to three years and shall also be liable to fine; and if the offender at the time of such person's decease was employed by him as a clerk or " +
                        "servant, the imprisonment may extend to seven years. \n\n" +
                        "Illustration \n" +
                        "Z dies in possession of furniture and money. His servant A, before the money comes into " +
                        "the possession of any person entitled to such possession, dishonestly misappropriates it. " +
                        "A has committed the offence defined in this section. ");
                mydb2.addsection("405. Criminal breach of trust Of Criminal Breach of Trust ","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, being in any manner entrusted with property, or " +
                        "with any dominion over property, dishonestly misappropriates or converts to his own use " +
                        "that property, or dishonestly uses or disposes of that property, in violation of any direction " +
                        "of law prescribing the mode in which such trust is to be discharged, or of any legal " +
                        "contract, express or implied, which he has made touching the discharge of such trust, or " +
                        "wilfully suffers any other person so to do, commits \"criminal breach of trust. \n\n" +
                        "Illustrations \n" +
                        "(a) A, being executor to the wilt of a deceased person, dishonestly disobeys the law which " +
                        "directs him to divide the effects according to the will, and appropriates them to his own " +
                        "use. A has committed criminal breach of trust. \n\n" +
                        "(b) A is a .warehouse-keeper, Z going on a journey entrusts his furniture to A, under a " +
                        "contract that it shall be returned on payment of a stipulated sum for warehouse-room. A " +
                        "dishonestly sells the goods. A has committed criminal breach of trust. \n\n" +
                        "(c) A, residing in Dacca, is agent for Z, residing at Lahore. There is an express or implied " +
                        "contract between A and Z, that all sums remitted by Z to A shall be invested by A, " +
                        "according to Z's direction. Z remits a lakh of rupees to A, with directions to A to invest the " +
                        "same in Company's paper. A dishonestly disobeys the directions and employs the money " +
                        "in his own business. A has committed criminal breach of trust. \n\n" +
                        "(d) But if A, in the last illustration, not dishonestly but in good faith, believing that It will be " +
                        "more for Z's advantage, to hold shares in the Bank of Bengal disobeys Z's directions and " +
                        "buys shares in the Bank of Bengal for Z, instead of buying Company's paper, here, though " +
                        "Z should suffer loss, and should be entitled to bring a civil action against A, on account of " +
                        "that loss, yet A. not having acted dishonestly, has not committed criminal breach of trust. \n\n" +
                        "(e) A, a Revenue-Officer, is entrusted with public money and is either directed by law, or " +
                        "bound by a contract, express or implied, with the Government, to pay into a certain " +
                        "treasury all the public money which he holds. A dishonestly appropriates the money. A " +
                        "has committed criminal breach of trust. \n\n" +
                        "(f) A, a carrier, is entrusted by Z with property to be carried by land or by water. A " +
                        "dishonestly misappropriates the property. A has committed criminal breach of trust. ");
                mydb2.addsection("406. Punishment for criminal breach of trust","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, commits criminal breach of " +
                        "trust snail be punished with imprisonment of either description for a term which may " +
                        "extend to seven years, or with fine, or with both. ");
                mydb2.addsection("407. Criminal breach of trust by carrier, etc.","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, being entrusted with property as " +
                        "a carrier, wharfinger or warehouse-Keeper, commits criminal breach of trust in respect of " +
                        "such property, shall be punished with imprisonment of either description for a term which " +
                        "may extend to seven years, and shall also be liable to fine.");
                mydb2.addsection("408. Criminal breach of trust by clerk or servant","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, being a clerk or servant or " +
                        "employed as a clerk or servant, and being in any manner entrusted in such capacity with " +
                        "property, or with any dominion over property, commits criminal breach of trust in respect of " +
                        "that property, shall be punished with imprisonment of either description for a term which " +
                        "may extend to seven years, and shall also be liable to fine");
                mydb2.addsection("409. Criminal breach of trust by public servant, or by banker, merchant or agent","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever being in any manner entrusted with property, or with any dominion over property " +
                        "in his capacity of a public servant or in the way of his business as a banker, merchant, " +
                        "factor, broker, attorney or agent, commits criminal breach of trust in respect of that " +
                        "property, shall be punished with imprisonment for life or with imprisonment of either " +
                        "description for a term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("410. Stolen property Of Receiving of Stolen Property ","OFFENCES AGAINST PROPERTY Of Theft",20," Property, the possession whereof has been transferred by theft, or " +
                        "by extortion, or by robbery, and property which has been criminally misappropriated or in " +
                        "respect of which criminal breach of trust has been committed, is designated as stolen, " +
                        "property, \"whether the transfer has been made, or the misappropriation or breach of trust " +
                        "has been committed, within or without Pakistan. But, if such property subsequently comes " +
                        "into the possession of a person legally entitled to the possession thereof it then ceases to " +
                        "be stolen property. ");
                mydb2.addsection("411. Dishonestly receiving stolen property","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever dishonestly receives or retains, " +
                        "any stolen property, knowing or having reason to believe the same to be stolen property, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "three years, or with fine, or with both. ");
                mydb2.addsection("412. Dishonestly receiving stolen property in the commission of a dacoity","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "dishonestly receives or retains any stolen property, the possession whereof he knows or " +
                        "has reason to believe to have been transferred by the commission of dacoity, or " +
                        "dishonestly receives from person, whom he knows or has reason to believe to belong or to " +
                        "have belonged to a gang of dacoits, property which he knows or has reason to believe to " +
                        "have been stolen, shall be punished with imprisonment for life, or with rigorous " +
                        "imprisonment for a term which may extend to ten years, and shall also be liable to fine.");
                mydb2.addsection("413. Habitually dealing in stolen property","OFFENCES AGAINST PROPERTY Of Theft",20," Whoever habitually receives or deals in " +
                        "property which he knows or has reason to believe to be stolen property, shall be punished " +
                        "with imprisonment for life, or with imprisonment of either description for a term which may " +
                        "extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("414. Assisting in concealment of stolen property ","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever voluntarily assists in " +
                        "concealing or disposing of or making away with-property which he knows or has reason to " +
                        "believe to be stolen property, shall be punished with imprisonment of either description for " +
                        "a term which may extend to three years, or with fine, or with both.");
                mydb2.addsection("415. Cheating Of Cheating","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, by deceiving any person, fraudulently or dishonestly induces " +
                        "the person so deceived to deliver any property to any person, or to consent that any " +
                        "person shall retain any property, or intentionally induces the person so deceived to do or " +
                        "omit to do anything which he would not do or omit if he were not so deceived, and which " +
                        "act or omission causes or is likely to cause damage or harm to that person 1 [or any other " +
                        "person] in body, mind, reputation or property, is said to \"cheat\". \n\n" +
                        "Explanation: A dishonest concealment of facts is a deception within the meaning of this " +
                        "section. \n\n" +
                        "Illustrations\n" +
                        "(a) A, by falsely pretending to be in the Civil Service, intentionally deceives Z and thus " +
                        "dishonestly induces Z to let him have on credit goods for which he does not mean to pay, " +
                        "A cheats. \n\n" +
                        "(b)A by putting a. counterfeit mark on an article, intentionally deceives Z, into a belief that " +
                        "this article was made by a certain celebrated manufacturer, and thus dishonestly induces " +
                        "Z to buy and pay for the article. A cheats. \n\n" +
                        "(c) A, by exhibiting to Z a false sample of an article, Intentionally deceives Z into believing " +
                        "that the article corresponds with the sample, and thereby dishonestly induces Z to buy and " +
                        "pay for the article. A cheats. \n\n" +
                        "(d) A, by tendering in payment for an article a bill w a house with which A keeps no money " +
                        "and by which A expects that the bill will be dishonoured, intentionally deceives Z. and " +
                        "thereby dishonestly Induces Z to deliver the article, intending not to pay for ft. A cheats. \n\n" +
                        "(e)A, by pledging as diamonds articles which ft knows are not diamonds, intentionally " +
                        "deceives Z, and thereby dishonestly induces Z to lend money, A cheats. \n\n" +
                        "(f) A, intentionally deceives Z, into a belief that A means to repay any money that 2 may " +
                        "lend to him and thereby dishonestly induces Z to lend him money; A not intending to repay " +
                        "it. A cheats.\n\n (g) A, intentionally deceives Z into a belief that A means to deliver to Z a certain quantity " +
                        "of indigo plant which he does not intend to deliver, and thereby dishonestly induces Z to " +
                        "advance money upon the faith of such delivery. A cheats; but (f A, at the time of obtaining " +
                        "the money. Intends to deliver the indigo plant, and afterwards breaks Ns contact and does " +
                        "not deliver ft, he does not cheat, but is liable only to a civil action for breach of contract. \n\n" +
                        "(h) A intentionally deceives Z into a belief that A has performed A's part of a contract " +
                        "made with Z, which he has not performed and thereby dishonestly induces Z to pay " +
                        "money. A cheats. \n\n" +
                        "(f}A sells and conveys an estate to S. A, knowing that in consequence of such sale he has " +
                        "no right to the property, sells or mortgages the same to Z. without disclosing the fact of the " +
                        "previous sale and conveyance to B, and receives the purchase or mortgage money from " +
                        "Z. A cheats, ");
                mydb2.addsection("416. Cheating by personation","OFFENCES AGAINST PROPERTY Of Theft",20,"A person is said to \"cheat by personation\" if he cheats by " +
                        "pretending to be some other person, or by knowingly substituting one person for another, " +
                        "or representing that he or any other person is a person other than he or such other person " +
                        "really is. \n\n" +
                        "Explanation: The offence is committed whether the individual personated is a real or " +
                        "imaginary person. \n\n" +
                        "Illustrations \n" +
                        "(a) A cheats by pretending to be a certain rich banker of the same name, A cheats by " +
                        "personation. \n\n" +
                        "(b) A cheats by pretending to be 8, a person who is deceased. A cheats by personation. ");
                mydb2.addsection("417. Punishment for cheating","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever cheats shall be punished with imprisonment of " +
                        "either description for a term, which may extend to one year, or with fine, or with both.");
                mydb2.addsection("418. Cheating with knowledge that wrongful loss may ensue to person whose " +
                        "interest offender is bound to protect","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever cheats with the knowledge that he is " +
                        "likely thereby to cause wrongful loss to a person whose interest in the transaction to which " +
                        "the cheating relates, he was bound either by law, or by legal contract, to protect shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years, or with fine, or with both. ");
                mydb2.addsection("419. Punishment for cheating by personation","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever cheats by personation shall " +
                        "be punished with imprisonment of either description for a term which may " +
                        "extend to seven years, or with fine, or with both.");
                mydb2.addsection("420. Cheating and dishonestly Inducing delivery of property","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever cheats and " +
                        "thereby dishonestly induces the person deceived to deliver any property to any person, or " +
                        "to make, alter or destroy the whole or any part of a valuable security, or anything which is signed or sealed, and which is capable of being converted into a valuable security, shall " +
                        "be punished with imprisonment, of either description for a term which may extend to seven " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("421. Dishonest or fraudulent removal or concealment of property to prevent " +
                        "distribution among creditors Of Fraudulent Deeds and Dispossession of Property","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever dishonestly or fraudulently removes, conceals or " +
                        "delivers to any person, or transfers or causes to be transferred to any person, without " +
                        "adequate consideration, any property, intending thereby to prevent, or knowing it to be " +
                        "likely that he will thereby prevent, the distribution of that property according to law among " +
                        "his creditors or the creditors of any other .person, shall be punished with imprisonment of " +
                        "either description for a term which may extend to two years, or with fine or with both. ");
                mydb2.addsection("422. Dishonestly or fraudulently preventing debt being available for creditors","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever dishonestly or fraudulently prevents any debt or demand due to himself or to any " +
                        "other person from being made available according to law for payment of his debt or the " +
                        "debts of such other person shall be punished with imprisonment of either description for a " +
                        "term which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("423. Dishonest or fraudulent execution of deed of transfer containing false " +
                        "statement of consideration","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever dishonestly or fraudulently signs, executes or " +
                        "becomes a party to any deed or instrument which purports to transfer or subject to any " +
                        "charge of any property, or any interest therein, and which contains any false statement " +
                        "relating to the consideration for such transfer or charge, or relating to the person or " +
                        "persons for whose use or benefit it is really intended to operate, shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("424. Dishonest or fraudulent removal or concealment of property","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "dishonestly or fraudulently conceals or removes any property of himself or any other " +
                        "person, or dishonestly or fraudulently assists in the concealment or removal thereof, or " +
                        "dishonestly releases any demand or claim to which he is entitled, shall be punished with " +
                        "imprisonment of either description for a term which may extend to two years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("425. Mischief","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, with intent to cause, or knowing that he is likely to cause, " +
                        "wrongful loss or damage to the public or to any person, causes the destruction of any " +
                        "property or any such change in any property or in the situation thereof as destroys or " +
                        "diminishes its value or utility, or affects it injuriously, commits \"mischief\". \n\n" +
                        "Explanation 1: It is not essential to the offence of mischief that the offender should intend " +
                        "to cause loss or damage to the owner of the property injured or destroyed. It is sufficient ft he intends to cause, or knows that he is likely to cause, wrongful loss or damage to any " +
                        "person by injuring any property, whether it belongs to that person or not. \n\n" +
                        "Explanation 2: Mischief may be committed by an act effecting property belonging to the " +
                        "person who commits the act, or to that person and others Jointly. \n\n" +
                        "Illustrations \n" +
                        "(a) A voluntarily burns a valuable security belonging to Z intending to cause wrongful loss " +
                        "to Z. A has committed mischief. \n\n" +
                        "(b)A introduces water into an ice-house, belonging to Z and thus causes the ice to melt, " +
                        "intending wrongful loss to Z. A has committed mischief. \n\n" +
                        "(c) A, voluntarily throws into a river a ring belonging to Z with the intention of thereby " +
                        "causing wrongful loss to Z, A has committed mischief. \n\n" +
                        "(d) A, knowing that his effects are about to be taken In execution In order to satisfy a debt " +
                        "due from him to Z, destroys those effects, with the intention of thereby preventing Z from " +
                        "obtaining satisfaction of the debt, and of thus causing damage to Z. A has committed " +
                        "mischief. \n\n" +
                        "(e) A having insured a ship, voluntarily causes the same to be cast away with the intention " +
                        "of causing damage to the underwriters. A has committed mischief. \n\n" +
                        "(f) A causes a ship to be cast away, intending thereby to cause damage to Z, who has lent " +
                        "money on bottomry on the ship. A has commuted mischief. \n\n" +
                        "(g) A, having joint property with Z in a horse, shoots the horse, intending thereby to cause " +
                        "wrongful loss to Z. A has committed mischief. \n\n" +
                        "(h) A cause cattle to enter upon a field belonging to Z, intending to cause and knowing " +
                        "that he is likely to cause damage to Z's crop. A has committed mischief. ");
                mydb2.addsection("426. Punishment for mischief","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits mischief shall be punished with " +
                        "imprisonment of either description for a term which may extend to three months, or with " +
                        "fine, or with both. ");
                mydb2.addsection("427. Mischief causing damage to the amount of fifty rupees","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commit " +
                        "mischief and thereby causes loss or damage to the amount of fifty rupees or upwards, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "two years, or with fine, or with both. ");
                mydb2.addsection("428. Mischief by killing or maiming animal of the value of ten rupees","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "commits mischief by killing, poisoning, maiming or rendering useless any animal of the " +
                        "value of ten rupees or upwards, shall be punished with imprisonment of either description " +
                        "for a term which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("429. Mischief by killing or maiming cattle, etc., of any value or any animal of the " +
                        "value of fifty rupees","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits Mischief by killing, poisoning, maiming or " +
                        "rendering useless, any elephant, camel, horse, mule, buffalo, bull, cow or ox, whatever " +
                        "may be the value thereof, or any other animal of the value of fifty rupees or upwards, shall " +
                        "be punished with imprisonment of either description for a term which may extend to five " +
                        "years, or with both. ");
                mydb2.addsection("430. Mischief by injury to works of irrigation or by wrongfully diverting water","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits mischief by doing any act which causes, or which he knows to be likely " +
                        "to cause, a diminution of the supply of water for agricultural purposes, or for food or drink " +
                        "for human beings or for animals which are property, or for cleanliness or for carrying on " +
                        "any manufacture, shall be punished with imprisonment of either description for a term " +
                        "which may extend to five years, or with fine, or with both.");
                mydb2.addsection("431. Mischief by Injury to public road, bridge, river or channel","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits " +
                        "mischief by doing any act which renders or which he knows to be likely to render any " +
                        "public road, bridge, navigable river or navigable channel, natural or artificial, impassable " +
                        "or less safe for travelling or conveying property, shall be punished with imprisonment of " +
                        "either description for a term which may extend to five years, or with fine, or with both. ");
                mydb2.addsection("432. Mischief by causing inundation or obstruction to public drainage attended with " +
                        "damage","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits mischief by doing any act which causes or which he knows to " +
                        "be likely to cause an inundation or an obstruction to any public drainage attended with " +
                        "injury or damage, shall be punished with imprisonment of either description for a term " +
                        "which may extend to five years, or with fine, or with both. ");
                mydb2.addsection("33. Mischief by destroying, moving or rendering less useful a light-house or sea-mark","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits mischief by destroying, moving or rendering less useful a light-house or sea-mark: Whoever commits mischief by destroying or moving any light-house or other light " +
                        "used as a sea-mark, or any sea-mark or buoy or other thing placed as a guide for " +
                        "navigators, or by any act which renders any such light-house, sea-mark, buoy or other " +
                        "such thing as aforesaid jess useful as a guide for navigators, shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, or with " +
                        "fine, or with both. ");
                mydb2.addsection("434. Mischief by destroying or moving, etc., a landmark fixed by public authority","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits mischief by destroying or moving any landmark fixed by the authority of " +
                        "a public servant, or by any act which renders such landmark less useful as such, shall be " +
                        "punished with imprisonment of either description for a term which may extend to one year, " +
                        "or with fine, or with-both. ");
                mydb2.addsection("435. Mischief by fire or explosive substance with intent to cause damage to amount " +
                        "of one hundred rupees or (in case of agricultural produce) ten rupees","OFFENCES AGAINST PROPERTY Of Theft",20," Whoever " +
                        "commits mischief by fire or any explosive substance, intending to cause, or knowing it to " +
                        "be likely that he will thereby cause damage to any property to the amount of one hundred " +
                        "rupees or upwards or (where the property is agricultural produce) ten rupees or upwards shall be punished with imprisonment of either description for a term which shall not be less " +
                        "than two years nor more than] seven years, and shall also be liable to fine. ");
                mydb2.addsection("436. Mischief by fire or explosive substance with intent to destroy house, etc.","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits mischief by fire or any explosive substance, intending to cause, or " +
                        "knowing it to be likely that he with thereby cause, the destruction of any building which is " +
                        "ordinarily used as a place of worship or as a human dwelling or as a place for the custody " +
                        "of property shall be punished with imprisonment for life, or with imprisonment of either " +
                        "description for a term which shall not be less than three years nor more than] ten years, " +
                        "and shall also be liable to fine.");
                mydb2.addsection("437. Mischief with Intent to destroy or make unsafe a decked vessel or one of " +
                        "twenty tons burden","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits mischief, to any decked vessel or any vessel of a " +
                        "burden of twenty tons or upwards, intending to destroy or render unsafe, or knowing ft to " +
                        "be likely that he will thereby destroy or render unsafe, that vessel, shall be punished with " +
                        "imprisonment of either description for a term which may extend to ten years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("438. Punishment for the mischief described in Section 437 committed by fire or " +
                        "explosive substance","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits, or attempts to commit, by fire or any explosive " +
                        "substance, such mischief as is described in the last preceding section, shall be punished " +
                        "with imprisonment for life or with imprisonment of either description for a term which may " +
                        "extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("439. Punishment for intentionally running vessel aground or ashore with Intent to " +
                        "commit theft, etc,","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever intentionally runs any vessel aground or ashore, intending to " +
                        "commit theft of any property contained therein or to' dishonestly misappropriate any such " +
                        "property, or with intent that such theft or misappropriation of property may be committed, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "ten years, and shall also be liable to fine.");
                mydb2.addsection("440. Mischief committed after preparation made for causing death or hurt","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "commits mischief, having made preparation for causing to any person death, or hurt, or " +
                        "wrongful restraint, or fear of death, or of hurt, or of wrongful restraint shall be punished " +
                        "with imprisonment of either description for a term which may extend to five years, and " +
                        "shall also be liable to fine. " );
                mydb2.addsection("441. Criminal trespass","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever enters into or upon property in the possession of " +
                        "another with intent to commit an offence or to intimidate, insult or annoy any person in " +
                        "possession of such property, or, having lawfully entered into or upon such property, " +
                        "unlawfully remains there with intent thereby to intimidate, insult or annoy any such person, " +
                        "or with intent to commit an offence, is said to commit \"criminal trespass\". ");
                mydb2.addsection("442. House-trespass","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits criminal trespass by entering into or " +
                        "remaining in any building, tent or vessel used as a human dwelling or any building used as " +
                        "a place for worship, or as a place for the custody of property, is said to commit \"house-trespass\". \n\n" +
                        "Explanation: The introduction of any part of the criminal trespasser's body is entering " +
                        "sufficient to constitute house trespass. \n");
                mydb2.addsection("443. Lurking house-trespass","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits house-trespass having taken \n" +
                        "precautions to conceal such house-trespass from some person who has a right to exclude \n" +
                        "or eject the trespasser from the building, tent or vessel which is the subject of the \n" +
                        "trespass, is said to commit \"lurking house- trespass\". ");
                mydb2.addsection("444. Lurking house-trespass by night","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits lurking house-trespass after " +
                        "sunset and before sunrise, is said to commit 'lurking house-trespass by night\". \n");
                mydb2.addsection("445. House-breaking","OFFENCES AGAINST PROPERTY Of Theft",20,"A person is said to commit \"house-breaking\" who commits house-trespass if he effects his entrance into the house or-any part of it in any of the six ways " +
                        "hereinafter described; or if, being in the house or any part of it for the purpose of " +
                        "committing an offence, or, having committed an offence therein, he quits the house or any " +
                        "part of it in any of such six ways, that is to say:\" \n\n" +
                        "First: If he enters or quits through a passage made by himself, or by any abettor of the " +
                        "house-trespass, in order to the committing of the house-trespass. \n\n" +
                        "Secondly : If he enters or quits through any passage not intended by any person, other " +
                        "than himself or an abettor of the offence, for human entrance; or through any passage to " +
                        "which he has obtained access by scaling or climbing over any wall or building. \n\n" +
                        "Thirdly : If he enters or quits through any passage which he or any abettor of the house-trespass has opened, in order to the committing of the house-trespass by any means by " +
                        "which that passage was not intended by the occupier of the house to be-opened. \n\n" +
                        "Fourthly: If he enters or quits by opening any lock in order to the committing of the house-trespass, or in order to the quitting of the house after a house-trespass. " +
                        "Fifthly: if he effects his entrance or departure by using criminal force of committing an " +
                        "assault, or by threatening any person with assault. \n\n" +
                        "Sixthly: he enters or quits any passage which he knows to have been fastened against " +
                        "such entrance or departure, and to. have been fastened by himself or by an abettor of the " +
                        "house-trespass. \n\n" +
                        "Explanation : Any out-house or building occupied with a house, and between, which and. " +
                        "such house there is an immediate internal communication, is part of the house within the " +
                        "meaning of this section.\n\nIllustrations \n" +
                        "(a) A commits house-trespass by making a hole through the wall of Z's house, and putting " +
                        "his hand through the aperture. This is house breaking. \n\n" +
                        "(b) A commits house-trespass by creeping into a ship at a port hole between decks. This " +
                        "is house breaking. \n\n" +
                        "(c) A commits house-trespass by entering Z's house through a window. This is house-breaking. \n\n" +
                        "(d) A commits house-trespass by entering Z's house through the door, having opened a " +
                        "door, which was fastened. This is house-breaking. \n\n" +
                        "(e) A commits house-trespass by entering Z's house through the door having lifted a latch " +
                        "by putting a wire through a hole in the door. This is house-breaking: \n\n" +
                        "(f) A finds the key of Z's house door, which Z had lost, and commits house-trespass by " +
                        "entering Z's house, having opened the door with that key. This is house breaking. \n\n" +
                        "(g) Z is standing in his doorway. A forces a passage by knowing Z down, and commits " +
                        "house-trespass by entering the house. This is house breaking. \n\n" +
                        "(h) Z, the door-keeper of Y is standing in Y's doorway. A commits house-trespass by " +
                        "entering the house, having deterred Z from opposing him by threatening to beat him. This " +
                        "is house-breaking. ");
                mydb2.addsection("446. House-breaking by night","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits house-breaking after sunset and " +
                        "before sunrise, is said to commit \"house-breaking by night.\" ");
                mydb2.addsection("447. Punishment for criminal trespass","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits criminal trespass shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "months, or with fine which may extend to five hundred rupees, or with both. ");
                mydb2.addsection("448. Punishment for house-trespass","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits house-trespass shall be " +
                        "punished with imprisonment of either description for a term which may extend to one year, " +
                        "or with fine which may extend to one thousand rupees, or with both. ");
                mydb2.addsection("449. House-trespass in order to commit offence punishable with death","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "commits house-trespass in order to the committing of any offence punishable with death, " +
                        "shall be punished with imprisonment for life, or with rigorous imprisonment for a term not " +
                        "exceeding ten years, and shall also be liable to fine. ");
                mydb2.addsection("450. House-trespass In order to commit offence punishable with imprisonment for " +
                        "life","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits house-trespass in order to the committing of any offence punishable with imprisonment for life, shall be punished with imprisonment of either " +
                        "description for a term not exceeding ten years, and shall also be liable to fine. ");
                mydb2.addsection("451. House-trespass in order to commit offence punishable with imprisonment","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits house trespass in order to the committing of any offence punishable " +
                        "with imprisonment, shall be punished with imprisonment of either description for a term " +
                        "which may extend to two years, and shall also be liable to fine; and if the offence intended " +
                        "to be committed is theft, the term of the imprisonment may be extended to seven years. ");
                mydb2.addsection("452. House-trespass after preparation for hurt, assault or wrongful restraint","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits house-trespass having made preparation for causing hurt to any person " +
                        "or for assaulting any person, or for wrongfully restraining any person, or for putting any " +
                        "person in fear of hurt, or of assault, or of wrongful restraint, shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "also be liable to tine. ");
                mydb2.addsection("453. Punishment for lurking house-trespass or house-breaking","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits " +
                        "lurking house-trespass or house-breaking, shall be punished with imprisonment of either " +
                        "description for a term which may extend to two years, and shall also be liable to fine.");
                mydb2.addsection("454. Lurking house trespass or house-breaking in order to commit offence " +
                        "punishable with Imprisonment","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits lurking house-trespass or house-breaking, in order to the. committing of any offence punishable with imprisonment, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three " +
                        "years, and shall also be liable to fine, and if the offence intended to be committed is theft, " +
                        "the term of the imprisonment may be extended to ten years. ");
                mydb2.addsection("455. Lurking house-trespass or house-breaking after preparation for hurt, assault or " +
                        "wrongful restraint","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits lurking house-trespass, or house-breaking, having " +
                        "made preparation for causing hurt to any person, or for assaulting any person, or for " +
                        "wrongfully restraining any person, or for putting any person in fear of hurt or of assault or " +
                        "of wrongful restraint, shall be punished with imprisonment of either description for a term " +
                        "which may extend to ten years, and shall also be liable to fine.");
                mydb2.addsection("456. Punishment for lurking house-trespass or house-breaking by night","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "commits lurking house-trespass by night or house-breaking by night, shall be punished " +
                        "with imprisonment of either description for a term which may extend to three years, and " +
                        "shall also be liable to fine. ");
                mydb2.addsection("457. Lurking house-trespass or house-breaking by night in order to Commit offence " +
                        "punishable with imprisonment","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits lurking house-trespass by night, or " +
                        "house-breaking by night, in order to the committing of any offence punishable with " +
                        "imprisonment, shall be punished with imprisonment of either description for a term which " +
                        "may extend to five years, and shall also be liable to fine; and, if the offence intended to be " +
                        "committed is theft, the term of the imprisonment may be extended to fourteen years.");
                mydb2.addsection("456. Lurking house-trespass or house-breaking by night after preparation for hurt, " +
                        "assault or wrongful restraint","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits lurking house-trespass by night or " +
                        "house-breaking by night, having made preparation for causing hurt to any person, or for " +
                        "assaulting any person, or for wrongfully restraining any person, or for putting any person " +
                        "in fear of hurt, or of assault, or of wrongful restraint, shall be punished with imprisonment " +
                        "of either description for a term which may extend to fourteen years, and shall also be " +
                        "liable to fine.");
                mydb2.addsection("457. Lurking house-trespass or house-breaking by night in order to commit offence " +
                        "punishable with imprisonment","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits lurking house-trespass by night, or " +
                        "house-breaking by night, in order to the committing of any offence punishable with " +
                        "imprisonment, shall be punished with imprisonment of either description for a term which " +
                        "may extend to five years, and shall also be liable to fine; and, if the offence intended to be " +
                        "committed is theft, the term of the imprisonment may be extended to fourteen years. ");
                mydb2.addsection("458. Lurking house-trespass or house-breaking by night after preparation for hurt, " +
                        "assault or wrongful restraint","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever commits lurking house-trespass by night or " +
                        "house-breaking by night, having made preparation for causing hurt to any person, or for " +
                        "assaulting any person, or for wrongfully restraining any person, or for putting any person " +
                        "in fear of hurt, or of assault, or of wrongful restraint, shall be punished with imprisonment " +
                        "of either description for a term which may extend to fourteen years, and shall also be " +
                        "liable to fine. \n");
                mydb2.addsection("459. Hurt caused whilst committing lurking house trespass or house-breaking","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, whilst committing lurking house-trespass or house-breaking, causes hurt to any " +
                        "person or attempts to commit oaf/ of, or hurt to, any person shall be punished with " +
                        "imprisonment for life, or imprisonment of either description for a term which may extend to " +
                        "ten years, and shall also be liable to the same punishment for committing qatl or causing " +
                        "hurt or attempting to cause qatl or hurt as is specified in Chapter XVI of this Code. ");
                mydb2.addsection("460. Persons jointly concerned in lurking house-trespass or house-breaking by " +
                        "night punishable for qatl or hurt caused by one of them","OFFENCES AGAINST PROPERTY Of Theft",20,"If, at the time of the " +
                        "committing of lurking house-trespass by night or house-breaking by night, any person " +
                        "guilty of such offence shall voluntarily cause or attempt to commit qatl of, or hurt to, any " +
                        "person, every person jointly concerned in committing such lurking house-trespass by night " +
                        "or house-breaking by night, shall be punished with imprisonment for life or with " +
                        "imprisonment of either description for a term which may extend to ten years and shall also " +
                        "be liable to the same punishment for committing qatl or causing hurt or attempting to " +
                        "cause qatl or hurt as is specified in Chapter XVI of this Code]. \n" +
                        "Scs. 459 & 460 subs. by the Criminal Law (Amendment) Act, II of 1997 ");
                mydb2.addsection("461. Dishonestly breaking open receptacle containing property ","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever " +
                        "dishonestly or with intent to commit mischief breaks open or unfastens and closed " +
                        "receptacle which contains or which, he believes to contain property, shall be punished " +
                        "with imprisonment or either description for a term which may extend to two years, or with " +
                        "fine, or with both. ");
                mydb2.addsection("462. Punishment for same offence when committed by person entrusted with " +
                        "custody","OFFENCES AGAINST PROPERTY Of Theft",20,"Whoever, being entrusted with any dosed receptacle which contains or which he " +
                        "believes to contain property, without having authority to open the same, dishonestly, or " +
                        "with intent to commit mischief, breaks open or unfastens that receptacle, shall be " +
                        "punished with imprisonment of either description for a term which may extend to three-years, or with fine, or with both.");
                //chapter 17
                mydb2.addchapters("OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS","35","CHAPTER XVIII");

                mydb2.addsection("463. Forgery","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever makes any false document or part of a document, with intent to " +
                        "cause damage or injury, to the public or to any person, or to support any claim or title, or " +
                        "to cause any person to part with property, or to enter into any express or implied contract, " +
                        "or with intent to commit fraud or that fraud may be committed, commits forgery. ");
                mydb2.addsection("464. Making a false document","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21," A person is said to make a false document. \n\n" +
                        "First: Who dishonestly or fraudulently makes, signs, seals or executes a document or part " +
                        "of a document, or makes any mark denoting the execution of a document, with the " +
                        "intention of causing it to be believed that such document or part of a document was made, " +
                        "signed, sealed or executed by the authority of a person by whom or by whose authority he " +
                        "knows that it was not made, signed, sealed or executed, or at a time at which he knows " +
                        "that it was not made, signed, seated or executed; or \n\n" +
                        "Secondly : Who, without lawful authority, dishonesty or fraudulently, by cancellation or " +
                        "otherwise, alters a document in any material part thereof, after it has been made \"or " +
                        "executed either by himself or by any other person, whether such person be living or dead " +
                        "at the time of such alteration; or \n\n" +
                        "Thirdly: Who dishonestly or fraudulently causes any person to sign, seal, execute or later " +
                        "a document, knowing that such person by reason of unsoundness of mind or intoxication " +
                        "cannot, or that. by reason of deception practised upon him, he does not know the contents " +
                        "of the document or the nature of the alteration. \n\n" +
                        "Illustrations \n" +
                        "(a) A has a letter of credit upon B for rupees 10,QOO, written by Z. A, in order to defraud " +
                        "E, adds a cipher to the 10,000 and makes the sum 10,000, intending that it may be " +
                        "believed by 5 that Z so wrote .the letter, A has committed forgery. \n\n" +
                        "(b) A, without Z's authority, affixes Z's seat to a document purporting to be a conveyance " +
                        "of an estate from Z to A, with the intention of selling the estate to 6 and thereby of " +
                        "obtaining from B the purchase-money. A has committed forgery.\n\n(c) A picks up a cheque on a banker signed by B, payable to bearer, but without any sum " +
                        "having been inserted in the cheque. A fraudulently tills up the cheque by inserting the sum " +
                        "of ten thousand rupees. A commits forgery, \n\n" +
                        "(d) A leaves with B, his agent, a- cheque on a banker, signed by A, without inserting the " +
                        "sum payable and authorises B to fill up the cheque by inserting a sum not exceeding ten " +
                        "thousand rupees for the purpose of making certain payments. B fraudulently fills up the " +
                        "cheque by inserting the sum of twenty thousand rupees. B commits forgery. \n\n" +
                        "(e) A draws a bill of exchange on himself in the name of B without B's authority, intending " +
                        "to discount it as. a genuine bill with a banker and intending to take up the bill on its " +
                        "maturity. Here, as A draws the bill with intent to deceive the banker by leading him to " +
                        "suppose that he had the security of B, and thereby to discount the bill, A is guilty of " +
                        "forgery. \n\n" +
                        "(f) Z's will contains these words: \"I direct that all my remaining property be equally divided " +
                        "between A, B and C.\" A dishonestly scratches out B's name, intending that it may be " +
                        "believed that the whole was left to himself and C, A has committed forgery. \n\n" +
                        "(g) A endorses a Government promissory-note and makes it payable to Z or his order by " +
                        "writing on the bill the words \"Pay to Z or his order\" and signing the endorsement. B " +
                        "dishonestly erases the words \"Pay to Z or his order\" and thereby converts the special " +
                        "endorsement into a blank endorsement. B commits forgery. \n\n" +
                        "(h) A sells and conveys an estate to Z, A afterwards, in order to defraud Z of his estate' " +
                        "executes a conveyance of the same estate to B, dated six months earlier than the date of " +
                        "the conveyance to Z, Intending it to be believed that he had conveyed the estate to B " +
                        "before he conveyed it to Z. A has committed forgery. \n\n" +
                        "(i) Z dictate his will to A. A intentionally writes down a different legatee from the legatee " +
                        "named by Z, and by representing to Z, that he has prepared th6 will according to his " +
                        "instructions, Induces Z to sign the will. A has committed forgery. \n\n" +
                        "(j) A writes a- fetter and signs it with B's name without B's authority, certifying that A is a " +
                        "man of good character and distressed circumstances from unforeseen misfortune, " +
                        "intending by means of such letter to obtain aims from Z and other persons. Mere, as A " +
                        "made false document in order to induce Z to part with property, A has committed forgery. \n\n" +
                        "(k) A without B's authority writes a letter and signs It in B's name certifying to A's " +
                        "character, Intending thereby to obtain employment under Z. A has committed forgery " +
                        "inasmuch as he intended to deceive Z by the forged certificate, and thereby to induce Z to " +
                        "enter into an express or implied contract for service. \n\n" +
                        "Explanation 1: A man's signature of his own name may amount to forgery. \n\n" +
                        "Illustrations\n (a) A signs his own name to a bill of exchange, intending that it may be believed that the " +
                        "bill was drawn by another person of the same name. A has committed forgery. \n\n" +
                        "(b) A writes the word \"accepted\" on a piece of paper and sings it with Z's name, in order " +
                        "that 8 may afterwards write on the paper a bill of exchange drawn by B upon Z, and " +
                        "negotiate the bill as though it had been accepted by Z. A is guilty of forgery; and if B, " +
                        "knowing the fact, draws the bill upon the paper pursuant to A’s intention, B is also guilty of " +
                        "forgery. \n\n" +
                        "© A picks up a bill of exchange payable to the order of a different person of the same " +
                        "name A endorses the bill in his own name, intending to cause it to be believed that it was " +
                        "endorsed by the person to whose order it was payable, here A has committed forgery. \n\n" +
                        "(d) A purchases an estate sold under execution of a decree against B. B after the seizure " +
                        "of the estate, in collusion With Z, executes a lease of the estate to Z at a nominal rent and " +
                        "for a long period and dates the lease six months prior to the seizure, with intent to defraud " +
                        "A, and to cause it to be believed that the lease was granted before the seizure. S, though " +
                        "he executes the lease in his own name, commits forgery by antedating it. \n\n" +
                        "(e) A, a trader, in anticipation of insolvency, lodges effects with B for A's benefit, and with " +
                        "intent to defraud his creditors and in order to give a colour to the transaction, writes a " +
                        "promissory-note binding himself to pay to B a sum for value received, and antedates that " +
                        "note, intending that it may be believed to have been made before A was on the point of " +
                        "insolvency. A has committed forgery under the first head of the definition. \n\n" +
                        "Explanation 2: The making of a false document in the name of a fictitious person, " +
                        "intending it to be believed that the document was made by a real person, or in the name of " +
                        "a deceased person, intending it to be believed that the document was made by the person " +
                        "in his lifetime, may amount to forgery. \n\n" +
                        "Illustration \n" +
                        "A draws a bill of exchange upon a fictitious person, and fraudulently accepts the bill in the " +
                        "name of such fictitious person with intent to negotiate it. A commits forgery. ");
                mydb2.addsection("465. Punishment for forgery","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever commits forgery shall be punished with " +
                        "imprisonment of either description for a term, which may extend to two years, or with fine, " +
                        "or with both. \n");
                mydb2.addsection("466. forgery or record of Court or of public register, etc.","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever forges a document, " +
                        "purporting to be a record or proceeding of or in a Court of Justice, or a register of birth, " +
                        "baptism, marriage or burial or a register kept by a public servant as such, or a certificate " +
                        "or document purporting to be made by public servant in his official capacity, or an " +
                        "authority to institute or defend a suit, or to take any proceedings therein or to confess " +
                        "Judgment, or a power-of-attorney, shall be punished with imprisonment of either " +
                        "description for a term which may extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("467. Forgery of valuable security, will, etc.","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21," Whoever forges a document which purports " +
                        "to be a valuable security, or a will, or an authority to adopt a son, or which purports to give " +
                        "authority to any person to make or transfer any valuable security, or to receive the " +
                        "principal, interest or dividends thereon, or to receive or deliver any money, movable " +
                        "property, or valuable security, or any document purporting to be as acquaintance or " +
                        "receipt acknowledging the payment of money, or an acquaintance or receipt for the " +
                        "delivery of any movable property or valuable security, shall be punished with " +
                        "imprisonment for life, or with imprisonment of either description for a term which may " +
                        "extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("468. Forgery for purpose of cheating","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever commits forgery, intending that, the " +
                        "document forged shall be used for the purpose of cheating, shall be punished with \n" +
                        "imprisonment of either description for a term which may extend to seven years, and shaft \n" +
                        "also be liable to fine. ");
                mydb2.addsection("469. Forgery for purpose of harming reputation","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever commits forgery, intending \n" +
                        "that the document forged shall harm the reputation of any party, or knowing that it is likely " +
                        "to be used for that purpose, shall be punished with imprisonment of either description for a " +
                        "term which may extend to three years, and shall also be liable to fine. ");
                mydb2.addsection("470. Forged document","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"A false document made wholly or in part by forgery is designated " +
                        "\"a forged document\". ");
                mydb2.addsection("471. Using as genuine a forged document","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever fraudulently or dishonestly uses " +
                        "as genuine any document which he knows or has reason to believe to be a forged " +
                        "document, shall be punished in the same manner as if he had forged such document. ");
                mydb2.addsection("472. Making or possessing counterfeit seal, etc., with intent to commit forgery " +
                        "punishable under Section 467 ","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever makes or counterfeits any seal, plate or other " +
                        "instrument for making an impression, intending that the same shall be used for the " +
                        "purpose of committing any forgery which would be punishable under Section 467 of this " +
                        "Code, or with such intent, has in his possession any such seal, plate or other instrument, " +
                        "knowing the same to be counterfeit, shall be punishable with imprisonment for life, or with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("473. Making or possessing counterfeit seal, etc., with intent to commit forgery " +
                        "punishable otherwise:","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever makes or counterfeits any seal, plate or other " +
                        "instrument for making an impression, intending that the same shall be used for the " +
                        "purpose of committing any forgery which would be punishable under any section of this " +
                        "chapter other than Section 467, or such intent, has in his possession any such seal, plate " +
                        "or other instrument, knowing the same to be counterfeit, shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("474. Having possession of document described in Section 466 or 467 knowing it to " +
                        "be forged and intending to use it as genuine","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever has in his possession any " +
                        "document knowing the same to be forger and intending that the same shall fraudulently or " +
                        "dishonestly be used as genuine, shall, if the document is one of the description mentioned " +
                        "in Section 466 of this Code, be-punished with imprisonment of either description for a term " +
                        "which may extend to seven years, and shall also be liable to fine and if the document is " +
                        "one of the description mentioned in Section 467; shall be punished with imprisonment for " +
                        "life, or with imprisonment of either description, for a term which may extend to seven " +
                        "years, and shall also be liable to fine, ");
                mydb2.addsection("475. Counterfeiting device or mark used for authenticating documents described in \n" +
                        "Section 467, or possessing counterfeit marked material","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever counterfeits " +
                        "upon, or in the substance of, any material, any device or mark used for the purpose of " +
                        "authenticating any document described in .'Section 467 of this Code, intending that such " +
                        "device or mark shall be used for the purpose of giving the appearance of authenticity to " +
                        "any document then forged or thereafter to be forged on such material, or who, with such " +
                        "intent, has in his possession any material upon or in the substance of which any such " +
                        "device or mark has been counterfeit, shall be punished with imprisonment for fife, or with " +
                        "imprisonment of either description, for a term which may extend to seven years, and shall " +
                        "also be liable to fine. ");
                mydb2.addsection("476. Counterfeiting device or mark used for authenticating documents other than " +
                        "those described in Section 467, or possessing counterfeit marked material","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever counterfeits upon, or in the substance of, any material, any device or mark used " +
                        "for the purpose of authenticating any document other than the documents described in " +
                        "Section 467 of this Code, Intending that device or mark shall be used for the purpose of " +
                        "giving the appearance of authenticity to any document then forged or thereafter to be " +
                        "forged on such material, or who, with such intent, has in his possession any material upon " +
                        "or in the substance of which any such device or mark has been counterfeited, shall be " +
                        "punished with imprisonment of either description for a term which may extend to seven " +
                        "years, and shall also be liable to fine. ");
                mydb2.addsection("477. Fraudulent cancellation, destruction, etc., of will, authority to adopt, or valuable " +
                        "security","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21," Whoever fraudulently or dishonestly, or with intent to cause damage or injury to " +
                        "the public or to any person, cancels, destroys or defaces or attempts to cancel, destroy or " +
                        "deface or secretes or attempts to secrete any document which is or purports to be a will, " +
                        "or an authority to adopt a son, or any valuable security, or commits mischief in respect to " +
                        "such document, shall be punished with imprisonment for life or with imprisonment of either " +
                        "description- for a term-which may extend to seven years, and shall also be liable to fine. ");
                mydb2.addsection("477-A. Falsification of accounts","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever, being a clerk, officer or servant, or employed " +
                        "or acting in the capacity of a clerk, officer or servant, wilfully, and with intent to defraud, " +
                        "destroys, alters, mutilates or falsifies any book, paper, writing, valuable security or account " +
                        "which belongs to or is in the possession of his employer, or has bean received by him for " +
                        "or on behalf of his employer, or wilfully, and with intent to defraud, makes or abets the making of any false entry in, or omits or alters or abets the omission or alteration of any " +
                        "material particular form or in, any such book, paper, writing valuable security or account, " +
                        "shall be punished with imprisonment of either description for a term which may extend to " +
                        "seven years, or with fine, or with both. \n\n" +
                        "Explanation: It shall be sufficient in any charge under this section to allege a general " +
                        "intention to defraud without naming any particular person intended to be defrauded or " +
                        "specifying any particular sum of money intended to be the subject of the fraud, or any " +
                        "particular day on which the offence was committed \n" +
                        "Section 477-A ins, by the Criminal Law (Amendment) Act, IIl of 1895. ");
                mydb2.addsection("478. Trade mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"A mark used for denoting that goods are the manufacture or " +
                        "merchandise of a particular person is called a trade mark, and for the purposes of this " +
                        "Code the expression \"trade mark\" includes any trademark which is registered in the " +
                        "register of trade marks kept under the Trade Marks Act, 1940 (V of 1940). \n\n" +
                        "Sec. 478 subs. by the Federal Laws (Revision and Declaration) Ordinance, XXVII of 1981.");
                mydb2.addsection("479. Property, mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"A mark used for denoting that movable property belongs to a " +
                        "particular person is called a property mark.");
                mydb2.addsection("480. Using a false trade mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever marks any goods or any case, packages or " +
                        "other receptacle containing goods, or uses any case, package or other receptacle with " +
                        "any mark thereon, in a manner reasonably calculated to cause it to be believed that the " +
                        "goods so marked/or any goods contained in any such receptacle so marked, are the " +
                        "manufacture or merchandise of a person whose manufacture or merchandise they are " +
                        "not, is said to use a false trade mark.");
                mydb2.addsection("481. Using a false property mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever marks any movable property or goods or " +
                        "any case, package or other receptacle containing movable property or goods, or uses any " +
                        "case package or other receptacle having any mark thereon, in a manner reasonably " +
                        "calculated to cause it to be believed that the property or goods so marked, or any property " +
                        "or goods contained in any such receptacle so marked, belong to a person to whom they " +
                        "do not belong, is said to use a false property mark. ");
                mydb2.addsection("482. Punishment for using a false trade-mark or property mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever uses any " +
                        "false trade mark or any false property mark shall, unless he proves that he acted without " +
                        "intent to defraud, be punished with imprisonment of either description for a term which " +
                        "may extend to one year, or with fine, or with both. ");
                mydb2.addsection("483. Counterfeiting a trademark or property mark used by another","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever " +
                        "counterfeits any trade mark or property mark used by any other person shall be punished " +
                        "with imprisonment of either description for a term which may extend to two years, or with " +
                        "fine, or with both. ");
                mydb2.addsection("484. Counterfeiting a mark used by a public servant","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever counterfeits any " +
                        "property mark used by a public servant, or any mark used by a public servant to denote " +
                        "that any property has been manufactured by a particular person or at a particular time or " +
                        "place, or that the property is of a particular quality or has passed through a particular " +
                        "office, or that it is entitled to any exemption, or uses as genuine any such mark knowing " +
                        "the same to be counterfeit, shall be punished with imprisonment of either description for a " +
                        "term which may extend to three years, and shall also be liable to fine. ");
                mydb2.addsection("485. Making or possession of any instrument for counterfeiting a trade mark or " +
                        "property mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever makes or has in his possession any die, plate or other " +
                        "instrument for the purpose of counterfeiting a trade mark or property mark, or has in his " +
                        "possession a trade mark or property mark for the purpose of denoting that any goods are " +
                        "the manufacture or merchandise of a person whose manufacture or merchandise they are " +
                        "not, or that they belong to a person to whom they do not belong, shall be punished with " +
                        "imprisonment of either description for a term which may extend to three years, or with fine, " +
                        "or with both. ");
                mydb2.addsection("486. Selling goods marked with a counterfeit trade mark or property mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever " +
                        "sells, or exposes, or has in possession for sale or any purpose of trade or manufacture, " +
                        "any goods or thing with a counterfeit trade mark or property mark affixed to or impressed " +
                        "upon the same or to or upon any case, package or other receptacle in which such goods " +
                        "are contained, shall, unless he proves. \n\n" +
                        "(a) that, having taken all reasonable precautions against committing an offence against " +
                        "this section, he had at the time of the commission of the alleged offence no reason to " +
                        "suspect the genuineness of the mark and \n\n" +
                        "(b) that, on demand made by or on behalf of the prosecutor, he gave all the information in " +
                        "his power with respect to the persons from whom he obtained such goods or things, or \n\n" +
                        "(c) that otherwise he had acted innocently, " +
                        "be punished with imprisonment of either description for a term which may extend to one " +
                        "year, or with fine. or with both. ");
                mydb2.addsection("487. Making a false mark upon any receptacle containing goods ","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever makes " +
                        "any false mark upon any case, package or other receptacle containing goods, in a manner " +
                        "reasonably calculated to cause any public servant or any other person to believe that such " +
                        "receptacle contains goods which it does not contain or that it does not contain goods " +
                        "which it does contain, or that the goods contained in such receptacle are of a nature or " +
                        "quality different from the real nature or quality thereof, shall, unless he proves that he " +
                        "acted without intent to defraud, be punished with imprisonment of either description for a " +
                        "term which may extend to three years, or with fine, or with both. ");
                mydb2.addsection("488. Punishment for making use of any such false mark","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever makes use of any " +
                        "such false mark in any manner prohibited by the last foregoing section shall, unless he " +
                        "proves that he acted without intent to defraud, be punished as if he had committed an " +
                        "offence against that section. ");
                mydb2.addsection("489. Tampering with property mark with intent to cause injury","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever removes, " +
                        "destroys, defaces or adds to any property mark, intending or knowing it to be likely that he " +
                        "may thereby cause injury to any person, shall be punished with imprisonment of either, " +
                        "description for a term which may extend to one year, or with fine or with both.");
                mydb2.addsection("489-A. Counterfeiting currency-notes or bank-notes","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever counterfeits, or " +
                        "knowingly performs any part of the process of counterfeiting, any currency-note or bank-note, shall be punished with imprisonment for life, or with imprisonment of either " +
                        "description for a term which may extend to ten years, and shall also be liable to fine. \n\n" +
                        "Explanation: For the purposes of this section and of Sections 489-B, 489-C and 489-D, " +
                        "that expression \"bank-note\" means a promissory-note or engagement for the payment of " +
                        "money to bearer on demand issued by any person carrying on the business of banking in " +
                        "any part of the world, or issued by or under the authority of any State or Sovereign Power, " +
                        "and intended to be used as equivalent to, or as a substitute for money. \n\n" +
                        "Section 489-A to 489-D ins. by the Currency-Notes Foreign Act, XII of 1899, S.2. ");
                mydb2.addsection("489-B. Using as genuine, forged or counterfeit currency-notes or bank-notes","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever sells to, or buys or receives from, any other person, or otherwise traffics, in or " +
                        "uses as genuine, any forged or counterfeit currency-note or bank-note, knowing or having " +
                        "reason to believe the same to be forged or counterfeit, shall be punished with " +
                        "imprisonment for life, or with imprisonment of either description for a term which may " +
                        "extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("489-C. Possession of forged or counterfeit currency-notes or bank-notes","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever " +
                        "has in his possession any forged or counterfeit currency-note or bank-note, knowing or " +
                        "having reason to believe the same to be forged or counterfeit and intending to use the " +
                        "same as genuine or that it may be used as genuine, shall be punished with imprisonment " +
                        "of either description for a term which may extend to seven years, or with fine, or with both. ");
                mydb2.addsection("489-D. Making or possessing instruments or materials for forging or counterfeiting " +
                        "currency-notes or bank-notes","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever makes, or performs any part of the process of " +
                        "making, or buys or sells or disposes of, or has to his possession, any machinery,- " +
                        "instrument or material for the purpose of being used, or knowing or having reason to " +
                        "believe that it is intended to be used, for forging or counterfeiting any currency-note or " +
                        "bank-note, shall be punished with imprisonment for life, or with imprisonment of either " +
                        "description for a term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("489-E. Making or using documents resembling currency-notes or bank-notes","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21," (1) " +
                        "Whoever makes, or causes to be made, or uses for any purposes whatsoever, or delivers to any person, any document purporting to be, or in any way resembling or so nearly " +
                        "resembling, as to be calculated to device, any currency-note or bank-note shall be " +
                        "punished with imprisonment of either description for a term which may extend to one year, " +
                        "or with fine or with both. \n\n" +
                        "(2) If any person, whose name appears on a document the making of which is an offence " +
                        "under sub-section (1), refuses, without lawful excuse, to disclose to a police-officer on " +
                        "being so required the name and address of the person by whom it was printed or " +
                        "otherwise made, he shall be punished with imprisonment of either description for a term " +
                        "which may extend to one year, or with fine, or with both. \n\n" +
                        "(3) Where the name of any person appears on any document in respect of which any " +
                        "person is charged with an offence under sub-section (1) or on any other document used or " +
                        "distributed in connection with that document it may, until the contrary is proved, be " +
                        "presumed that person caused the document to be made. \n" +
                        "Sec. 489-E ins. by the Penal Code (Amendment) Act, VI of 1943. S. 2.");
                mydb2.addsection("489-F. Counterfeiting of using documents resembling National Prize Bonds or " +
                        "un-authorised sale thereof","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"Whoever counterfeits, or causes to counterfeit, or perform " +
                        "any act to use for any purpose whatsoever, or delivers to any person any document " +
                        "purporting to be, or in any manner resembling to the National Prize Bonds, or indulges in " +
                        "the business of sale or purchase of National Prize Bonds, or promotes such sale or " +
                        "purchase of National Prize Bonds, in contravention of the rules made for the purpose, " +
                        "shall be punishable with imprisonment for a term which may extend to five years, or with " +
                        "fine not exceeding one hundred thousand rupees, or with both. \n" +
                        "Sec. 489-F ins. by Ordinance. LXXII of 95 ");
                mydb2.addsection("489-F. Dishonestly issuing a cheque","OFFENCES RELATING TO DOCUMENTS AND TO TRADE OR PROPERTY MARKS",21,"How ever dishonestly issues a cheque towards " +
                        "repayment of a loan or fulfilment of an obligation which is dishonoured on presentation, " +
                        "shall be punished with imprisonment which may extend to three years or with fine, or with " +
                        "both, unless he can establish, for which the burden of proof shall rest on him, that he had " +
                        "made arrangements with his bank to ensure that the cheque would be honoured and that " +
                        "the bank was at fault in not honouring the cheque. ");
                //chapter 18
                mydb2.addchapters("THE CRIMINAL BREACH OF CONTRACTS OF SERVICE","3","CHAPTER XIX");

                mydb2.addsection("490. Breach of contract of service during voyage or journey","THE CRIMINAL BREACH OF CONTRACTS OF SERVICE",22,"[Rep. By the Workmen's " +
                        "Breach of Contract Repealed Act III of 1925), S. 2 and Schedule].");
                mydb2.addsection("491. Breach of contract to attend on any supply wants of helpless person","THE CRIMINAL BREACH OF CONTRACTS OF SERVICE",22,"Whoever, " +
                        "being bound by a lawful contract to attend on or to supply the wants of any person who, by " +
                        "reason of youth; or of unsoundness of mind, or of a disease or bodily weakness, is " +
                        "helpless or incapable of providing for his own safety or of supplying his own wants, " +
                        "voluntarily omits so to do, shall be punished with imprisonment of either description for a term which may extend to three months, or with fine which may extend to two hundred " +
                        "rupees, or with both. ");
                mydb2.addsection("492. Breach of contract to serve at distant place to which servant is conveyed at masters " +
                        "expense","THE CRIMINAL BREACH OF CONTRACTS OF SERVICE",22," [Rep. by the Workman's Breach of Contract (Repeating) Act, HI of 1925, Sec. 2 " +
                        "and Schedule]. ");
                //chapter 20
                mydb2.addchapters("OFFENCES RELATING TO MARRIAGE","6","CHAPTER XX");

                mydb2.addsection("493. Cohabitation caused by a man deceitfully inducing a belief of lawful marriage","OFFENCES RELATING TO MARRIAGE",23," [Rep. " +
                        "by the Offence of Zina (Enforcement of Hudood) Ordinance, VH of 1979, S. 19]. ");
                mydb2.addsection("494. Marrying again during lifetime of husband or wife","OFFENCES RELATING TO MARRIAGE",23,"Whoever, having a husband or " +
                        "wife living, marries in any case in which, such marriage is void by reason of its taking " +
                        "place during the life of such husband or wife, shall be punished with imprisonment of " +
                        "either description for a term which may extend to seven years, and shall also be liable to " +
                        "fine. \n\n" +
                        "Exception: This Section does not extend to any person, whose marriage with such " +
                        "husband or wife has been declared void by a Court of competent jurisdiction, \n\n" +
                        "nor to any person who contracts a marriage during the life of a former husband or wife, if " +
                        "such husband or wife, at the time of the subsequent marriage, shall have been continually " +
                        "absent from such person for the space of seven years, and shall not have been heard of " +
                        "by such person as being alive within that time provided the person contracting such " +
                        "subsequent marriage shall, before such marriage takes place, inform the person with " +
                        "whom such marriage is contracted of the real state of facts so far as the same are within " +
                        "his or her knowledge. ");
                mydb2.addsection("495. Same offence with concealment of former marriage from person with whom " +
                        "subsequent marriage is contracted ","OFFENCES RELATING TO MARRIAGE",23,"Whoever commits the offence defined in the last " +
                        "preceding section having concealed from the person with whom the subsequent marriage " +
                        "is contracted, the fact of the former marriage, shall be punished with imprisonment of " +
                        "either description for a term which may extend to ten years, and shall also be liable to fine. ");
                mydb2.addsection("496. Marriage ceremony fraudulently gone through without lawful marriage","OFFENCES RELATING TO MARRIAGE",23,"Whoever, dishonestly or with a fraudulent intention, goes through the ceremony of being " +
                        "married, knowing that he is not thereby lawfully married, shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, and shall " +
                        "be liable to fine. ");
                mydb2.addsection("497. Adultery","OFFENCES RELATING TO MARRIAGE",23,"[Rep. by the Offence of Zina (Enforcement of Hudood) Ordinance, VII of " +
                        "1979, S. 19]. ");
                mydb2.addsection("498. Enticing or taking away or detaining with criminal intent a married woman","OFFENCES RELATING TO MARRIAGE",23,"[Rep. by " +
                        "the Offence of Zina (Enforcement of Hudood) Ordinance, Vll of 1979, S. 19]. ");

                mydb2.addchapters("DEFAMATION","4","CHAPTER XXI");

                mydb2.addsection("499. Defamation","DEFAMATION",24,"Whoever by words either spoken or intended to be read, or by signs or " +
                        "by visible representations, makes or publishes any imputation concerning any person " +
                        "intending to harm, or knowing or having reason to believe that such imputation will harm, " +
                        "the reputation of such person, is said except in the cases hereinafter excepted, to defame " +
                        "that \n\n" +
                        "Proviso: [Omitted by the Criminal Law (Amendment) Act JV of 1986.] \n\n" +
                        "Explanation 1: It may amount to defamation to impute anything to a deceased person, if " +
                        "the jmputator would harm the reputation of that person if living, and is intended to be " +
                        "hurtful to the feelings of his family or other near relatives. \n\n" +
                        "Explanation 2: It may amount to defamation to make an imputation concerning a company " +
                        "or an association or collection of persons as such. \n\n" +
                        "Explanation 3: An imputation in the form of an alternative or expressed ironically, may " +
                        "amount to defamation. \n\n" +
                        "Explanation 4: No imputation is said to harm a person's reputation, unless that imputation " +
                        "directly or indirectly, in the estimation of others, lowers the moral or intellectual character " +
                        "of that person, or lowers the character of that person in respect of his caste or of his " +
                        "calling or lowers the credit of that person, or causes it to be believed that the body of that " +
                        "person is in a loathsome state, or in a state generally considered a disgraceful. \n\n" +
                        "Illustration \n\n" +
                        "(a) A says: Z is an honest man, he never state B's watch, intending to cause it to be " +
                        "believed that Z did steal 6's watch., This is defamation, unless it fall within one of the " +
                        "exceptions. \n\n" +
                        "(£)) A is asked who stole B's watch. A points to Z, intending to cause it to be believed that " +
                        "Z stole B's watch. This is defamation unless it falls within one of the exceptions. \n\n" +
                        "(c) A draws a picture of Z running away with B's watch, intending it to be believed that Z " +
                        "stole B's watch. This is defamation, unless it falls within one of the exceptions. \n\n" +
                        "First Exception-Imputation of truth which public good requires to be made or " +
                        "published: It is not defamation to impute anything which is true concerning any person, if it be for the public good that the imputation should be made or published. Whether or not it " +
                        "is for the public good is a question off act. \n\n" +
                        "Second Exception on Public conduct of public servants: It is not defamation to " +
                        "express in good faith any opinion whatever respecting the conduct of a public servant in " +
                        "the discharge of his public functions, or respecting his character, so far as his character " +
                        "appears in that conduct, and no further. \n\n" +
                        "Third Exception-Conduct of any person touching any public question : It is not " +
                        "defamation to express in good faith any opinion whatever respecting the conduct of any " +
                        "person touching any public question, and. respecting his character, so far as his character " +
                        "appears in that conduct, and no further. \n\n" +
                        "Illustration \n" +
                        "It is not defamation in A to express in good faith any opinion whatever respecting Z's " +
                        "conduct in petitioning Government on a public question, in signing requisition for a " +
                        "meeting on a public question, in presiding or attending as such meeting, in forming or " +
                        "joining any society which invites the public support, in voting or canvassing for a particular " +
                        "candidate for any situation in the efficient discharge of the duties of which the public is " +
                        "interested. \n\n" +
                        "Fourth Exception Publication of reports of proceedings of Courts:\n It is not " +
                        "defamation to public a substantially true report of the proceedings of a Court of Justice, or " +
                        "of the result of any such proceedings. \n\n" +
                        "Explanation: Justice of the peace or other officer holding an enquiry in open Court " +
                        "preliminary to a trial in a Court of Justice is a Court within the meaning of the above " +
                        "section. \n\n" +
                        "Fifth Exception -Merits of case decided in Court or conduct of witnesses and other " +
                        "concerned:\n It is not defamation to express in good faith any opinion whatever respecting " +
                        "the merits of any case, civil or criminal, which has been decided by a Court of Justice, or " +
                        "respecting the conduct of any person as a party, witness or agent, in any such case, or " +
                        "respecting the character of such person, as far as his character appears in that conduct, " +
                        "and not further. \n\n" +
                        "Illustration \n" +
                        "(a) A says: \"I think Z's evidence on that trial is so contradictory that he must be stupid or " +
                        "dishonest,\" A is within this exception if he says that in good faith, inasmuch as the opinion " +
                        "which he expresses respects Z's character as it appears in Z's conduct as a witness, and " +
                        "no further. \n\n" +
                        "(b) But if A says: \"I do not believe what Z asserted at that trial because ! know him to be a " +
                        "man without veracity.\" A is not within this exception, inasmuch as the opinion which he " +
                        "expresses of Z's character, is an opinion not founded on Z's conduct as a witness.\n\n Sixth Exception -Merits of public performance:\n It is not defamation to express in good " +
                        "faith any opinion respecting the merits of any performance which its author has submitted " +
                        "to the judgment of the public, or respecting the character of the author so far as his " +
                        "character appears in such performance, and no further. \n\n" +
                        "Explanation:\nA performance may be submitted to the judgment of the public expressly or " +
                        "by acts on the part of the author, which imply such submission to the judgment of the " +
                        "public. \n\n" +
                        "Illustrations \n" +
                        "(a) A person who publishes a book, submits that book to the judgment of the public. \n\n" +
                        "(b) A person who makes a speech in public, submits that speech to the judgment of the " +
                        "public, \n\n" +
                        "(c) An actor or singer who appears on a public stage, submits his acting or singing to the " +
                        "judgment of the public. \n\n" +
                        "(d) A says of a book published by Z. \"Z's book is foolish; Z must be a weak man. Z's book " +
                        "is indecent; Z must be a man of impure mind.\" A is within this exception, if he says this in " +
                        "good faith, Inasmuch as the opinion which he expresses of Z respects Z's character only " +
                        "so far as it appears in Z's book, and no further. \n\n" +
                        "(e) But if A says: I am not surprised that Z's book is foolish and indecent, for he is a weak " +
                        "man and a libertine. A is not within this exception, inasmuch as the opinion which he " +
                        "expresses of Z's character is an opinion not founded on Z's book. \n\n" +
                        "Seventh Exception -Censure passed in good faith by person having lawful authority " +
                        "over another: It is not defamation in a person having over another any authority, either " +
                        "conferred by law or arising out of a lawful contract made with that other, to pass in good " +
                        "faith any censure on the conduct of that other in matters to which such lawful authority " +
                        "relates. \n\n" +
                        "Illustration \n" +
                        "A Judge censuring in good faith the conduct of a witness, or of an officer of the Court; a " +
                        "head of a department censuring in good faith those who are under this orders; a parent " +
                        "censuring in good faith a child in the presence of other children; a schoolmaster, whose " +
                        "authority is derived from a parent, censuring in good faith a pupil in service;' a banker " +
                        "censuring in good faith, the cashier of his bank for the conduct of such cashier as such " +
                        "cashier are within this exception, \n\n" +
                        "Eight Exception -Accusation preferred in good faith to authorised person :\nIt is not " +
                        "defamation to prefer in good faith an accusation against any person to any of those who " +
                        "have lawful authority over that person with respect to the subject matter of accusation. \n\n" +
                        "Illustration \nIf A in good faith accuses Z before a Magistrate; if A in good faith complains of the " +
                        "conduct of Z, a servant, to Z's master; if A in good faith complains of the conduct of Z, a " +
                        "child-Z's father A is within this exception. \n\n" +
                        "Ninth Exception- Imputation made in good faith by person for protection of his or " +
                        "other's interest: It is not defamation to make an imputation on the character of another " +
                        "provided that the imputation be made in good faith for the protection of the interest of the " +
                        "person making it, or of any other person, or for the public good. \n\n" +
                        "Illustrations \n" +
                        "(a) A, a shopkeeper, says to B, who manages his business—\"Sell nothing to Z unless he " +
                        "pays you ready money, for I have no opinion of his honesty.\" A is within the exception, if " +
                        "he has made this imputation on Z in good faith for the protection of his own interests. \n\n" +
                        "(b) A, a Magistrate, in making a report of his own superior officer, casts an imputation on " +
                        "the character of Z. Here, if the imputation is made in good faith, and for the good, A is " +
                        "within the exception. \n\n" +
                        "Tenth Exception -Caution intended for good of person to whom conveyed or for " +
                        "public good: It is not defamation to convey a caution, in good faith, to one person against " +
                        "another, provided that such caution be intended for the good of the person to whom it is " +
                        "conveyed, or of some person in whom that person is interested, or for the public good. ");
                mydb2.addsection("500. Punishment for defamation","DEFAMATION",24,"Whoever defames another shall be punished with " +
                        "simple imprisonment for a term which may extend to two years, or with fine, or with both:");
                mydb2.addsection("501. Printing or engraving matter known to be defamatory","DEFAMATION",24,"Whoever prints or " +
                        "engraves any matter, knowing or having good reason to relieve that such matter is " +
                        "defamatory of any person, shall be punished with simple imprisonment for a term which " +
                        "may extend to two years, or with fine, or with both. ");
                mydb2.addsection("502. Sale of printed or engraved substance containing defamatory matter","DEFAMATION",24,"Whoever " +
                        "sells or offers for sale any printed or engraved substance containing defamatory matter " +
                        "knowing that it contains such matter, shall be punished with simple imprisonment for a " +
                        "term which may extend to two years, or with fine, or with both. ");

                mydb2.addchapters("CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE","7","CHAPTER XXII");

                mydb2.addsection("503. Criminal Intimidation","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"Whoever threatens another with any injury to his person, " +
                        "reputation or property, or to the person or reputation of any one in whom that person is " +
                        "interested, with intent to cause alarm to that person, or to cause that person to do any act " +
                        "which he is not legally bound to do, or to omit to do any act which that person is legally " +
                        "entitled to do, as the means of avoiding the execution of such threat, commits criminal " +
                        "intimidation. Explanation : A threat to injure the reputation of any deceased person in whom the person " +
                        "threatened is interested, is within this section. \n\n" +
                        "Illustration \n" +
                        "A, for the purpose of inducing B to desist from prosecuting a civil suit, threatens to burn " +
                        "B's house. A is guilty of criminal intimidation. ");
                mydb2.addsection("504. Intentional insult with intent to provoke breach of the peace","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"Whoever " +
                        "intentionally insults, and thereby gives provocation to any person, intending or knowing it " +
                        "to be likely that such provocation will cause him to break the public peace, or to commit " +
                        "any other offence, shall be punished with imprisonment of either description for a term " +
                        "which may extend to two years, or with fine, or with both. ");
                mydb2.addsection("505. Statements conducing to public mischief","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"(1) Whoever makes, publishes, or " +
                        "circulates any statement, rumour or report-- \n\n" +
                        "(a) with intent to cause or incite, or which is likely to cause or incite, any officer, soldier, " +
                        "sailor, or airman in the Army, Navy or Air Force of Pakistan to mutiny, offence or otherwise " +
                        "disregard or fail in his duty as such ; or \n\n" +
                        "(b) with intent to cause, or which is likely to cause, fear or alarm to the public or to any " +
                        "section of the public whereby any person may be induced to commit an offence against " +
                        "the State or against the public tranquillity; or \n\n" +
                        "(c) with intent to incite, or which is likely to incite, any class or community of persons to " +
                        "commit any offence against any other class or community, " +
                        "shall be punished with imprisonment for a term which may extend to seven years and with " +
                        "fine. \n\n" +
                        "(2) Whoever makes, publishes or circulates any statement or report containing rumour or " +
                        "alarming news with intent to create or promote, or which is likely to create or promote, on " +
                        "grounds of religion, race, place of birth, residence, language, caste or community or any " +
                        "other ground whatsoever, feelings of enmity, hatred or ill-will between different religious, " +
                        "racial, language or regional groups or castes or communities, shall be punished with " +
                        "imprisonment for a term which may extend to seven years and with fine. \n\n" +
                        "Explanation: It does not amount to an offence within the meaning of this section, when the " +
                        "person making, publishing or circulating any such statement, rumour or report has " +
                        "reasonable grounds for believing that such statement, rumour or report is true and makes, " +
                        "publishes or circulates it in good faith and without any such intent as aforesaid. ");
                mydb2.addsection("506. Punishment for criminal intimidation","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"Whoever commences the offence of criminal " +
                        "intimidation shall be punished with imprisonment of either description for a term which " +
                        "may extend to two years or with fine or with both. If threat be to cause death or grievous hurt, etc.: And if the threat be to cause death or " +
                        "grievous hurt, or to cause the destruction of any property by fire, or to cause an offence " +
                        "punishable with death or imprisonment for life, or with imprisonment for a term which may " +
                        "extend to seven years, or to impute unchastity to a woman, shall be punished with " +
                        "imprisonment of either description for a term which may extend to seven years, or with " +
                        "fine, or with both. ");
                mydb2.addsection("507. Criminal intimidation by an anonymous communication","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"Whoever commits the " +
                        "offence of criminal intimidation by an anonymous communication, or having taken " +
                        "precaution to conceal the name or abode of the person from whom the threat comes, shall " +
                        "be punished with imprisonment of either description for a term which may extend to two " +
                        "years, in addition to the punishment provided for the offence by the last preceding section.");
                mydb2.addsection("508. Act caused by inducing person to believe that he will be rendered an object of " +
                        "Divine displeasure","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"Whoever voluntarily causes or attempts to cause any person to do " +
                        "anything which that person is not legally bound to do or to omit to do anything which he is " +
                        "legally entitled to do, by inducing or attempting to induce that person to believe that he or " +
                        "any person in whom he is interested will become or will be rendered by some act of the " +
                        "offender an object of Divine displeasure if he does not to the thing which it is the object of " +
                        "the offender to cause him to do, or if he does the thing which it is object of the offender to " +
                        "cause to him to omit shall be punished with imprisonment of either description for a term " +
                        "which may extend to one year, or with fine, or with both. \n\n" +
                        "Illustrations \n" +
                        "(a) A suits dhurna at Z's door with the intention of causing it to be believed that, by so " +
                        "sitting, he renders 2 an object of divine displeasure, A has committed the offence defined " +
                        "fn this section. \n\n" +
                        "(b) A threatens Z that, unless Z performs a certain act, A wilt kill one of A's own children, " +
                        "under such circumstances that the killing would be believed to render Z an object of Divine " +
                        "displeasure. A has committed the offence defined in this section. ");
                mydb2.addsection("509. Word, gesture or act intended to insult the modesty of a woman","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"Whoever, " +
                        "intending to insult the modesty of any woman, utters any word, makes any sound or " +
                        "gesture, or exhibits any object, intending that such word or sound shall be heard, or that " +
                        "such gesture or object shall be seen, by such woman, or intrudes upon the privacy of such " +
                        "woman, shall be punished with simple imprisonment for a term which may extend to one " +
                        "year, or with fine, or with both. ");
                mydb2.addsection("510. Misconduct in public by a drunken person","CRIMINAL INTIMIDATION, INSULT AND ANNOYANCE",25,"Whoever, in a, state of intoxication, " +
                        "appears in any public place, or in any place which it is a trespass in him to enter, and " +
                        "there conducts himself in such a manner as to cause annoyance to any person be " +
                        "punished with simple imprisonment for a term which may extend to twenty-four hours, or " +
                        "with fine which may extend to ten rupees, or with both. ");

                mydb2.addchapters("ATTEMPTS TO COMMIT OFFENCES","1","CHAPTER XXIII");

                mydb2.addsection("511. Punishment for attempting to commit offences punishable with imprisonment " +
                        "for life or for a shorter terms","ATTEMPTS TO COMMIT OFFENCES",26,"Whoever attempts to commit an offence punishable by " +
                        "this Code with imprisonment for life or imprisonment, or to cause such an offence to be " +
                        "committed, and in such attempt does any act towards the commission of the offence, shall " +
                        "where no express provision is made by this Code for the punishment bf such attempt, be " +
                        "punished with imprisonment of any description provided for the offence for a term which " +
                        "may extend to one-half of the longest term of imprisonment provided for that offence or " +
                        "with such fine daman as is provided for the offence, or with both.\n\n" +
                        "Illustration \n" +
                        "(a) A makes an attempt to steal some jewels by breaking, open the box, and finds after so " +
                        "opening the box, that there is no jewels in it. He has done an act towards the commission " +
                        "of theft, and therefore is guilty under this section. \n\n" +
                        "(b) A makes an attempt to pick the pocket of Z by thrusting his hand into Z's pocket, A fails " +
                        "in the attempt in consequence of 2's having nothing in his pocket. A is guilty under this " +
                        "section.");


                DisplayStoreddataInArray();
            }
            else{
                while (cursor.moveToNext()){
                    final int id=cursor.getInt(0);
                    final String book_title=cursor.getString(1);
                    final String no_of_sections=cursor.getString(2);
                    final String chapter_no=cursor.getString(3);
                    chapter_model chapter= new chapter_model(id,book_title,no_of_sections,chapter_no);
                    Chapter_array.add(chapter);

                }
            }


    }

    @Override
    public void onBackPressed() {
        if(drawerlayout.isDrawerOpen(GravityCompat.START)){
            drawerlayout.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
            case R.id.home:
                drawerlayout.closeDrawer(GravityCompat.START);
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivity(intent);


                break;
            case R.id.sections:
                drawerlayout.closeDrawer(GravityCompat.START);
                Intent intent1 = new Intent(MainActivity.this, sectionlist.class);
                startActivity(intent1);

                break;
                    case R.id.chapters:
                        drawerlayout.closeDrawer(GravityCompat.START);
                        drawerlayout.closeDrawer(GravityCompat.START);
                        Intent intent2 = new Intent(MainActivity.this, MainActivity.class);
                        startActivity(intent2);

                        break;
        }


        return true;
    }
}