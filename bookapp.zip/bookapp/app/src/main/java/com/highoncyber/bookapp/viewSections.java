package com.highoncyber.bookapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class viewSections extends AppCompatActivity {

    TextView titletxt, sectiontxt, chaptertxt;
    databasehelper mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_sections);

        titletxt = findViewById(R.id.section_title_txt);
        sectiontxt= findViewById(R.id.section_des_txt);
        chaptertxt = findViewById(R.id.chapter_name_txt);

        Intent i = getIntent();
        int id = i.getIntExtra("id",0);

        mydb= new databasehelper(this);

        Cursor cursor= mydb.read_all_sections_data_by_id(id);
        if(cursor.getCount()==0){
            Toast.makeText(this, "No data " +id, Toast.LENGTH_SHORT).show();
        }
        else{
            while (cursor.moveToNext()){
                Toast.makeText(this, "have data " +id, Toast.LENGTH_SHORT).show();
                titletxt.setText(cursor.getString(1));
                chaptertxt.setText(cursor.getString(2));
                sectiontxt.setText(cursor.getString(3));
            }
        }





    }
}