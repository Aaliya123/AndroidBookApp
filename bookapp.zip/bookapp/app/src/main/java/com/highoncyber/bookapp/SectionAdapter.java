package com.highoncyber.bookapp;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SectionAdapter extends RecyclerView.Adapter<SectionAdapter.SectionViewHolder> {


    private Context context;
    private ArrayList<section_model> section_model;

    public SectionAdapter(Context context,ArrayList<section_model> section_model) {
        this.context = context;
        this.section_model=section_model;
    }


    @NonNull
    @Override
    public SectionAdapter.SectionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view2= inflater.inflate(R.layout.sectionrow,parent,false);
        return new SectionViewHolder(view2);
    }

    @Override
    public void onBindViewHolder(@NonNull final SectionAdapter.SectionViewHolder holder, final int position) {
        holder.main_container.setAnimation(AnimationUtils.loadAnimation(context,R.anim.fade_scale_anni));

        final section_model sectionModel=section_model.get(position);

        holder.section_title_txt.setText(sectionModel.getSection_title());
        //holder.section_des_txt.setText(sectionModel.getSection_des());
        holder.chapter_title_txt.setText(sectionModel.getChapter_name());

        holder.main_container.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, viewSections.class);
                Pair[] pairs = new Pair[3];
                pairs[0] = new Pair<View, String>(holder.section_title_txt,"titletransition");
                pairs[1] = new Pair<View, String>(holder.chapter_title_txt,"sectiontransition");
                pairs[2] = new Pair<View, String>(holder.main_container,"containertransition");

                ActivityOptions options =ActivityOptions.makeSceneTransitionAnimation((Activity) context,pairs);
                intent.putExtra("id", sectionModel.getSection_id());

                context.startActivity(intent,options.toBundle());
            }
        });

    }

    @Override
    public int getItemCount() {
        return section_model.size();
    }

    public class SectionViewHolder extends RecyclerView.ViewHolder {

        TextView section_title_txt,section_des_txt,chapter_title_txt;
        ConstraintLayout main_container;
        ImageView book_url_box;

        public SectionViewHolder(@NonNull View itemView) {
            super(itemView);

            section_title_txt= itemView.findViewById(R.id.section_title_txt);
            section_des_txt= itemView.findViewById(R.id.section_des_txt);
            chapter_title_txt= itemView.findViewById(R.id.chapter_name_txt);
            main_container=itemView.findViewById(R.id.view_container);
            book_url_box=itemView.findViewById(R.id.book_url_box);
        }
    }
    public void filterList(ArrayList<section_model> filteredList) {
        section_model = filteredList;
        notifyDataSetChanged();
    }
}
