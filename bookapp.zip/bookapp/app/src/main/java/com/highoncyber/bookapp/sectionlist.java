package com.highoncyber.bookapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class sectionlist extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerlayout;
    NavigationView navigationview;
    ImageView menu;
    EditText sec_search;

    databasehelper secdb;
    RecyclerView recyclerView2;
    private ArrayList<section_model> section_array=new ArrayList<>();
    private SectionAdapter sectionAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sectionlist);

        Intent intent1 = getIntent();
        int id = intent1.getIntExtra("id",-1);

        secdb= new databasehelper(this);
        sec_search=findViewById(R.id.search_box_sec);
        final CharSequence[] search = {""};

        drawerlayout=findViewById(R.id.drawer_layout);
        navigationview=findViewById(R.id.nav_view);
        //toolbar=findViewById(R.id.toolbar);
        menu=findViewById(R.id.menu);
        recyclerView2 = findViewById(R.id.sec_recyclerview);

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerlayout.openDrawer(Gravity.LEFT);
            }
        });
        navigationview.bringToFront();
        ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this,drawerlayout,R.string.open_drawer,R.string.close_drawer);
        drawerlayout.addDrawerListener(toggle);
        toggle.syncState();
        navigationview.setNavigationItemSelectedListener(this);


        sec_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());
            }
        });

        DisplayStoreddataInArray(id);

        sectionAdapter = new SectionAdapter(sectionlist.this,section_array);
        recyclerView2.setAdapter(sectionAdapter);
        recyclerView2.setLayoutManager(new LinearLayoutManager(sectionlist.this));

    }


    private void filter(String text) {
        ArrayList<section_model> filteredList = new ArrayList<>();
        for (section_model item : section_array) {
            if (item.getSection_title().toLowerCase().contains(text.toLowerCase())) {
                filteredList.add(item);
            }
        }
        sectionAdapter.filterList(filteredList);
    }

    void DisplayStoreddataInArray(Integer id){
        Cursor cursor1;
        if(id==-1){
            cursor1 = secdb.read_all_sections_data_to_display();
        }
        else{
        cursor1 = secdb.read_all_sections_data(id);}
        if(cursor1.getCount() == 0){
        }
        else{
            while (cursor1.moveToNext()){
                final int section_id=cursor1.getInt(0);
                final String section_title=cursor1.getString(1);
                final String section_des=cursor1.getString(2);
                final String chapter_name=cursor1.getString(3);
                section_model section= new section_model(section_id,section_title,section_des,chapter_name);
                section_array.add(section);

            }
        }

    }

    @Override
    public void onBackPressed() {
        if(drawerlayout.isDrawerOpen(GravityCompat.START)){
            drawerlayout.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }

    }

    //@Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.home:
                drawerlayout.closeDrawer(GravityCompat.START);
                Intent intent = new Intent(sectionlist.this, MainActivity.class);
                startActivity(intent);

                break;
            case R.id.sections:
                drawerlayout.closeDrawer(GravityCompat.START);
                Intent intent1 = new Intent(sectionlist.this, sectionlist.class);
                startActivity(intent1);


                break;
            case R.id.chapters:
                drawerlayout.closeDrawer(GravityCompat.START);
                Intent intent2 = new Intent(sectionlist.this, MainActivity.class);
                startActivity(intent2);

                break;
        }


        return true;
    }
}