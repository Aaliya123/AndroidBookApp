package com.highoncyber.bookapp;


import android.content.Context;
import android.content.Intent;
import android.service.autofill.UserData;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private ArrayList<chapter_model> chapter_models;
    //private ArrayList<chapter_model> filteruserdatalist;


    CustomAdapter(Context context,ArrayList<chapter_model> chapter_models){
        this.context=context;
        this.chapter_models=chapter_models;
        //this.filteruserdatalist=chapter_models;
    }

    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view= inflater.inflate(R.layout.myrow,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {

        holder.main_container.setAnimation(AnimationUtils.loadAnimation(context,R.anim.fade_scale_anni));

        holder.book_title_txt.setText(chapter_models.get(position).getBook_title());
        holder.book_section_txt.setText(chapter_models.get(position).getNo_of_Sections());
        holder.book_no_txt.setText(chapter_models.get(position).getBook_no());


        holder.main_container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(context,sectionlist.class);
                intent.putExtra("id", chapter_models.get(position).getBook_id());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return chapter_models.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView book_title_txt,book_section_txt,book_chapter_txt,book_no_txt;
        ConstraintLayout main_container;
        ImageView book_url_box;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
           // book_id_txt= itemView.findViewById(R.id.book_id_txt);
            book_title_txt= itemView.findViewById(R.id.section_title_txt);
            book_chapter_txt= itemView.findViewById(R.id.chapter_name_txt);
            book_section_txt= itemView.findViewById(R.id.section_des_txt);
            main_container=itemView.findViewById(R.id.view_container);
            book_no_txt=itemView.findViewById(R.id.chapter_no_txt);
            book_url_box=itemView.findViewById(R.id.book_url_box);

        }
    }

        public void filterList(ArrayList<chapter_model> filteredList) {
            chapter_models = filteredList;
            notifyDataSetChanged();
        }


}

