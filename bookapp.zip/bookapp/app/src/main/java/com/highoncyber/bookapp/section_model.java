package com.highoncyber.bookapp;

import java.util.ArrayList;

public class section_model {
    private String section_title,section_des,chapter_name;
    private int section_id;

    public section_model(int section_id,String section_title, String section_des, String chapter_name) {
        this.section_title = section_title;
        this.section_des = section_des;
        this.chapter_name = chapter_name;
        this.section_id = section_id;
    }

    public String getSection_title() {
        return section_title;
    }

    public void setSection_title(String section_title) {
        this.section_title = section_title;
    }

    public String getSection_des() {
        return section_des;
    }

    public void setSection_des(String section_des) {
        this.section_des = section_des;
    }

    public String getChapter_name() {
        return chapter_name;
    }

    public void setChapter_name(String chapter_name) {
        this.chapter_name = chapter_name;
    }

    public int getSection_id() {
        return section_id;
    }

    public void setSection_id(int section_id) {
        this.section_id = section_id;
    }
}
