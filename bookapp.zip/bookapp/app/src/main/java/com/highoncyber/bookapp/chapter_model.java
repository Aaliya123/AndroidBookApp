package com.highoncyber.bookapp;

import java.util.ArrayList;

public class chapter_model {
    private int book_id;
    private String book_title;
    private String book_no;
    private String no_of_Sections;

    public chapter_model(int book_id, String book_title,String no_of_Sections,String book_no) {
        this.book_id = book_id;
        this.book_title = book_title;
        this.no_of_Sections = no_of_Sections;
        this.book_no=book_no;
    }

    public String getBook_no() {
        return book_no;
    }

    public void setBook_no(String book_no) {
        this.book_no = book_no;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public String getBook_title() {
        return book_title;
    }

    public void setBook_title(String book_title) {
        this.book_title = book_title;
    }

    public String getNo_of_Sections() {
        return no_of_Sections;
    }

    public void setNo_of_Sections(String no_of_Sections) {
        this.no_of_Sections = no_of_Sections;
    }
}
