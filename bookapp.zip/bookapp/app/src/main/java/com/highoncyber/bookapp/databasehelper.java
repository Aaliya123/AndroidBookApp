package com.highoncyber.bookapp;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

public class databasehelper extends SQLiteOpenHelper {

    private static final  String TAG="datahelper";
    private Context context;
    private static final String DATABASE_NAME= "Booklibrary.db";
    private static final int DATABASE_VERSION= 1;
    private static final String TABLE_NAME= "Chapters_table";
    private static final String TABLE_NAME1= "Sections_table";
    //for chapters
    private static final String COLUMN_CHP_ID="chapter_id";
    private static final String COLUMN_CHP_TITLE="chapter_name";
    private static final String COLUMN_CHP_NO="chapter_no";
    private static final String COLUMN_CHP_SECTIONS="chapter_sections";
    //for sections
    private static final String COLUMN_SEC_ID="section_id";
    private static final String COLUMN_SEC_TITLE="section_name";
    private static final String COLUMN_SEC_DES="section_des";
    private static final String COLUMN_CHP_NAME=COLUMN_CHP_TITLE;
    private static final String COLUMN_CHP_ID_FOR="chapter_id_for";


    public databasehelper(@Nullable Context context) {
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String table1 =
                "CREATE TABLE "+  TABLE_NAME  + " (" + COLUMN_CHP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        COLUMN_CHP_TITLE + " TEXT,"+
                        COLUMN_CHP_SECTIONS + " TEXT,"+
                        COLUMN_CHP_NO + " TEXT);";
        String table2 =
                "CREATE TABLE "+  TABLE_NAME1  + " (" + COLUMN_SEC_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        COLUMN_SEC_TITLE + " TEXT,"+
                        COLUMN_SEC_DES + " TEXT,"+
                        COLUMN_CHP_NAME + " TEXT,"+
                        COLUMN_CHP_ID_FOR + " INTEGER );";
        db.execSQL(table1);
        db.execSQL(table2);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME );
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME1 );
        onCreate(db);
    }

      void addchapters(String chapter_title,String chapter_sections,String chapter_no){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        //for chapters
        cv.put(COLUMN_CHP_TITLE,chapter_title);
        cv.put(COLUMN_CHP_SECTIONS,chapter_sections);
          cv.put(COLUMN_CHP_NO,chapter_no);

        long result= db.insert(TABLE_NAME,null,cv);
        if(result == -1){
            Toast.makeText(context, "Failed chapter", Toast.LENGTH_SHORT).show();
        }

    }
    void addsection(String section_title,String chapter_title,int chapter_id,String section_des){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        //for section
        cv.put(COLUMN_SEC_TITLE,section_title);
        cv.put(COLUMN_SEC_DES,section_des);
        cv.put(COLUMN_CHP_NAME,chapter_title);
        cv.put(COLUMN_CHP_ID_FOR,chapter_id);


        long result2= db.insert(TABLE_NAME1,null,cv);

        if(result2 == -1){

            Toast.makeText(context, "Failed section", Toast.LENGTH_SHORT).show();
        }

    }




//    Cursor alldatabyid(int id){
//        String query1 = "SELECT * FROM " + TABLE_NAME + " WHERE "+ COLUMN_ID +" = " + id ;
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor cursor =  cursor= db.rawQuery(query1,null);
//        return cursor;
//
//    }

    Cursor read_all_chapters_data(){
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor =  null;
        if(db != null){
            cursor= db.rawQuery(query,null);
        }

        return cursor;
    }

    Cursor read_all_sections_data(Integer chapter_id){
        String query1 = "SELECT * FROM " + TABLE_NAME1 +" WHERE "+ COLUMN_CHP_ID_FOR+" = "+chapter_id ;
        SQLiteDatabase db1 = this.getReadableDatabase();

        Cursor cursor1 =  null;
        if(db1 != null){
            cursor1= db1.rawQuery(query1,null);
        }

        return cursor1;
    }

    Cursor read_all_sections_data_by_id(int sec_id){
        String query1 = "SELECT * FROM " + TABLE_NAME1 +" WHERE "+ COLUMN_SEC_ID+" = "+sec_id ;
        SQLiteDatabase db1 = this.getReadableDatabase();

        Cursor cursor2 =  null;
        if(db1 != null){
            cursor2= db1.rawQuery(query1,null);
        }

        return cursor2;
    }

    Cursor read_all_sections_data_to_display(){
        String query1 = "SELECT * FROM " + TABLE_NAME1 ;
        SQLiteDatabase db1 = this.getReadableDatabase();

        Cursor cursor2 =  null;
        if(db1 != null){
            cursor2= db1.rawQuery(query1,null);
        }

        return cursor2;
    }
}

